# Evinie app: Android settings for this version (run in the evinie_app folder):
#   powershell -ExecutionPolicy Bypass -File .\update_android.ps1
# Safe to run more than once. Then: flutter clean, flutter pub get, build.
#   - app icon, notification icon (and a rule so release builds keep it)
#   - app settings (AndroidManifest.xml)
#   - "core library desugaring", needed by phone notifications
$ErrorActionPreference = "Stop"
$res = "android\app\src\main\res"
$gradle = "android\app\build.gradle.kts"
if (-not (Test-Path $res) -or -not (Test-Path $gradle)) {
  Write-Host "Run this inside the evinie_app folder (the one with the android folder)." -ForegroundColor Red
  exit 1
}

Write-Host "1/3 Icons..."
Get-ChildItem "platform_setup\android\res" -Directory | ForEach-Object {
  $to = Join-Path $res $_.Name
  New-Item -ItemType Directory -Path $to -Force | Out-Null
  Copy-Item (Join-Path $_.FullName "*") $to -Force
}

Write-Host "2/3 App settings..."
Copy-Item "platform_setup\android\AndroidManifest.xml" "android\app\src\main\AndroidManifest.xml" -Force

Write-Host "3/3 Build settings for notifications..."
$t = Get-Content $gradle -Raw
if ($t -notmatch 'isCoreLibraryDesugaringEnabled') {
  if ($t -match '(?m)^\s*compileOptions\s*\{') {
    $t = [regex]::Replace($t, '(?m)^(\s*)compileOptions\s*\{', '$1compileOptions {' + "`n" + '$1    isCoreLibraryDesugaringEnabled = true', 1)
  } else {
    $t = [regex]::Replace($t, '(?m)^android\s*\{', "android {`n    compileOptions {`n        isCoreLibraryDesugaringEnabled = true`n    }", 1)
  }
}
if ($t -notmatch 'desugar_jdk_libs') {
  $t = $t.TrimEnd() + "`n`ndependencies {`n    coreLibraryDesugaring(`"com.android.tools:desugar_jdk_libs:2.1.4`")`n}`n"
}
Set-Content $gradle $t -NoNewline

Write-Host "Done. Now run: flutter clean, flutter pub get, then build as usual." -ForegroundColor Green
