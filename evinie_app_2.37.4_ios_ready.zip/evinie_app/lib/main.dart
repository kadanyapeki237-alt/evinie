import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'config.dart';
import 'screens/auth_screens.dart';
import 'api/api_client.dart';
import 'screens/feed_screens.dart';
import 'state/cache.dart';
import 'state/session.dart';
import 'state/notifier.dart';
import 'theme/colors.dart';
import 'theme/theme.dart';
import 'widgets/common.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(statusBarColor: Colors.transparent, statusBarIconBrightness: Brightness.dark));
  await LocalCache.init();
  await Notifier.init();
  final session = Session();
  runApp(EvinieApp(session: session));
  await session.load();
}

class EvinieApp extends StatefulWidget {
  final Session session;
  const EvinieApp({super.key, required this.session});
  @override
  State<EvinieApp> createState() => _EvinieAppState();
}

class _EvinieAppState extends State<EvinieApp> {
  final _nav = GlobalKey<NavigatorState>();
  bool _wasSignedIn = false;

  @override
  void initState() {
    super.initState();
    widget.session.addListener(_onSession);
  }

  @override
  void dispose() {
    widget.session.removeListener(_onSession);
    super.dispose();
  }

  // Signing out (or an expired session) closes every open screen.
  void _onSession() {
    final now = widget.session.signedIn;
    if (_wasSignedIn && !now) _nav.currentState?.popUntil((r) => r.isFirst);
    _wasSignedIn = now;
  }

  @override
  Widget build(BuildContext context) => Scope(
        session: widget.session,
        child: MaterialApp(
          title: 'Evinie',
          navigatorKey: _nav,
          debugShowCheckedModeBanner: false,
          theme: evinieTheme(),
          // "Offline · showing saved content" across every screen.
          builder: (context, child) => ValueListenableBuilder<bool>(
            valueListenable: ApiClient.instance.offline,
            builder: (context, off, _) => Column(children: [
              // The text-size MediaQuery is read INSIDE the SafeArea (Builder), so
              // it no longer puts back the bottom inset SafeArea already applied.
              // Before, the phone's button-bar height was added twice, which left
              // a gap and pushed the bottom navigation too high.
              Expanded(
                child: SafeArea(
                  top: false,
                  left: false,
                  right: false,
                  bottom: !off,
                  child: Builder(
                    builder: (inner) => MediaQuery(
                      data: MediaQuery.of(inner).copyWith(textScaler: TextScaler.linear(MediaQuery.textScalerOf(inner).scale(1).clamp(0.85, 1.15) * 0.92)),
                      child: child ?? const SizedBox.shrink(),
                    ),
                  ),
                ),
              ),
              if (off)
                Material(
                  color: EvColors.ink,
                  child: SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: const [
                        Icon(Icons.cloud_off_rounded, color: Colors.white70, size: 15),
                        SizedBox(width: 6),
                        Text('Offline · showing saved content', style: TextStyle(color: Colors.white, fontSize: 12)),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
          home: Builder(builder: (context) {
            final s = Scope.of(context);
            if (!AppConfig.isConfigured) {
              return const Scaffold(body: StateMessage(icon: Icons.settings_rounded, title: 'App not configured', body: 'Build the app with --dart-define=EVINIE_API_KEY=... (see README).'));
            }
            if (!s.ready) return const _Splash();
            return s.signedIn ? const HomeShell() : const SignInScreen();
          }),
        ),
      );
}

class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) => const Scaffold(
        backgroundColor: Colors.white,
        body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Wordmark(size: 60),
          SizedBox(height: 10),
          Text('Connect. Share. Earn.', style: TextStyle(color: EvColors.muted)),
        ])),
      );
}
