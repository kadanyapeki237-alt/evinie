import 'models.dart';

double asDouble(dynamic v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}') ?? 0;

/// ₦1,234 (no decimals unless there are kobo).
String naira(num v) {
  final neg = v < 0;
  final a = v.abs();
  final whole = a.truncate();
  final s = whole.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  final kobo = ((a - whole) * 100).round();
  return '${neg ? '−' : ''}₦$s${kobo > 0 ? '.${kobo.toString().padLeft(2, '0')}' : ''}';
}

/// One Wallet history row. The server returns raw records, so this reads
/// the common field names and works out credit or debit.
class WalletEntry {
  final double amount;
  final bool credit;
  final String title;
  final DateTime time;
  WalletEntry(this.amount, this.credit, this.title, this.time);

  factory WalletEntry.fromJson(Map j) {
    final amt = asDouble(j['amount']);
    final kind = '${j['type'] ?? j['subtype'] ?? j['action'] ?? j['transaction_type'] ?? ''}'.toLowerCase();
    final credit = kind.contains('credit') || kind.contains('deposit') || kind.contains('refund') || (!kind.contains('debit') && amt > 0 && !kind.contains('withdraw'));
    var title = asStr(j['description'] ?? j['title'] ?? j['reason'] ?? j['note']);
    if (title.isEmpty) title = credit ? 'Money in' : 'Money out';
    return WalletEntry(amt.abs(), credit, title, asTime(j['time_created'] ?? j['time']));
  }
}

class Cashout {
  final int guid;
  final double amount, fee, net;
  final String status, bank, accountName, accountNumber, note;
  final DateTime time;
  Cashout({required this.guid, required this.amount, required this.fee, required this.net, required this.status, required this.bank, required this.accountName, required this.accountNumber, required this.note, required this.time});
  factory Cashout.fromJson(Map j) => Cashout(
        guid: asInt(j['guid']),
        amount: asDouble(j['amount']),
        fee: asDouble(j['fee_amount']),
        net: asDouble(j['net_amount']),
        status: asStr(j['status']).isEmpty ? 'pending' : asStr(j['status']),
        bank: asStr(j['bank_name']),
        accountName: asStr(j['account_name']),
        accountNumber: asStr(j['account_number']),
        note: asStr(j['admin_note']),
        time: asTime(j['time']),
      );
}

class Gift {
  final int guid;
  final String title, icon, mode;
  final double price;
  Gift({required this.guid, required this.title, required this.icon, required this.price, required this.mode});
  factory Gift.fromJson(Map j) => Gift(guid: asInt(j['guid']), title: asStr(j['title']), icon: iconUrl(j['icon']), price: asDouble(j['total_price']), mode: asStr(j['payment_mode']));
}

/// A received or sent gift. Raw records, read defensively.
class GiftEntry {
  final String title, icon;
  final double amount;
  final EvUser? other;
  final DateTime time;
  GiftEntry(this.title, this.icon, this.amount, this.other, this.time);
  factory GiftEntry.fromJson(Map j) {
    final u = j['sender'] ?? j['from'] ?? j['user'] ?? j['recipient'] ?? j['to'];
    return GiftEntry(
      asStr(j['title'] ?? j['gift_title'] ?? j['name']).isEmpty ? 'eGift' : asStr(j['title'] ?? j['gift_title'] ?? j['name']),
      iconUrl(j['icon'] ?? j['gift_icon']),
      asDouble(j['amount'] ?? j['total_price'] ?? j['price'] ?? j['net_amount']),
      u is Map ? EvUser.fromJson(u) : null,
      asTime(j['time_created'] ?? j['time']),
    );
  }
}

class PointsActivity {
  final String type;
  final int delta;
  final DateTime time;
  PointsActivity(this.type, this.delta, this.time);
  factory PointsActivity.fromJson(Map j) => PointsActivity(asStr(j['activity_type']), asInt(j['points_delta']), asTime(j['time']));

  /// Plain words for activity codes such as "post_like".
  String get label {
    final t = type.replaceAll(RegExp(r'[_:]+'), ' ').trim();
    return t.isEmpty ? 'Points' : t[0].toUpperCase() + t.substring(1);
  }
}

class VerifyPlan {
  final String plan, period;
  final double price;
  VerifyPlan(this.plan, this.price, this.period);
}

class VerifyStatus {
  final List<VerifyPlan> plans;
  final String currentPlan;
  final double walletBalance;

  /// The server's state: not_subscribed, needs_upload, pending, rejected,
  /// active or lapsed. Only "active" (payment active AND the ID approved
  /// by an admin) means verified.
  final String status;
  final bool paymentActive;
  String idStatus = '', idNote = '';
  DateTime? renews;
  VerifyStatus(this.plans, this.currentPlan, this.walletBalance, this.status, this.paymentActive);

  bool get verified => status == 'active';
  bool get pending => status == 'pending';
  bool get rejected => status == 'rejected';

  /// Paid, but still needs an ID sent (first time, or after a rejection).
  bool get needsId => paymentActive && (status == 'needs_upload' || status == 'rejected');

  /// Has to pay before an ID can be sent.
  bool get needsPayment => !paymentActive || status == 'not_subscribed' || status == 'lapsed';

  factory VerifyStatus.fromJson(Map j) {
    final plans = <VerifyPlan>[];
    if (j['plans'] is List) {
      for (final p in j['plans']) {
        if (p is Map) plans.add(VerifyPlan(asStr(p['plan']), asDouble(p['price']), asStr(p['period'])));
      }
    }
    // Before, having a plan at all counted as verified - so a request that
    // was only paid for, still pending, or rejected showed "You're verified".
    final st = VerifyStatus(plans, asStr(j['plan']), asDouble(j['wallet_balance']), asStr(j['status']).toLowerCase(), asBool(j['payment_active']));
    st.idStatus = asStr(j['id_status']).toLowerCase();
    if (st.idStatus == 'none') st.idStatus = '';
    st.idNote = asStr(j['id_rejection_note']);
    final nc = asInt(j['next_charge_time']);
    st.renews = nc > 0 ? DateTime.fromMillisecondsSinceEpoch(nc * 1000) : null;
    return st;
  }
}

class Tier {
  final int guid;
  final String title;
  final bool monetize;
  Tier(this.guid, this.title, this.monetize);
}

class MyTier {
  final bool active, canMonetize;
  final String name;
  final DateTime? expiry;
  MyTier(this.active, this.canMonetize, this.name, this.expiry);
  factory MyTier.fromJson(Map j) => MyTier(asBool(j['tier_active']), asBool(j['can_monetize']), asStr(j['tier_name']), asInt(j['tier_expiry']) > 0 ? asTime(j['tier_expiry']) : null);
}
