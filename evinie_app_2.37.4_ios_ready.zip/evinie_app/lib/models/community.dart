import 'dart:convert';
import 'models.dart';
import 'money.dart';

class Trend {
  final String tag;
  final int total;
  Trend(this.tag, this.total);
  factory Trend.fromJson(Map j) => Trend(asStr(j['hashtag'] ?? j['label']).replaceFirst('#', ''), asInt(j['total']));
}

class Group {
  final int guid, members;
  final String title, description, cover, privacy, joinStatus, url;
  final bool isMember, isOwner;
  Group({required this.guid, required this.title, required this.description, required this.cover, required this.privacy, required this.members, required this.joinStatus, required this.isMember, required this.isOwner, required this.url});
  factory Group.fromJson(Map j) => Group(
        guid: asInt(j['guid']),
        title: asStr(j['title']),
        description: asStr(j['description']),
        cover: asStr(j['cover_url']),
        privacy: asStr(j['privacy']),
        members: asInt(j['member_count']),
        joinStatus: asStr(j['join_status']),
        isMember: asBool(j['is_member']),
        isOwner: asBool(j['is_owner']),
        url: asStr(j['url']),
      );
}

class GroupPost {
  final int guid, likes, comments;
  final String text;
  final DateTime time;
  final EvUser poster;
  GroupPost(this.guid, this.text, this.time, this.poster, this.likes, this.comments);
  factory GroupPost.fromJson(Map j) {
    final p = j['poster'];
    return GroupPost(asInt(j['guid']), cleanText(asStr(j['message'])), asTime(j['time_created']),
        p is Map ? EvUser.fromJson(p) : EvUser(guid: asInt(p), fullname: asStr(j['fullname']), icon: iconUrl(j['icon'])), asInt(j['total_likes']), asInt(j['total_comments']));
  }
}

class EventItem {
  final int guid;
  final String title, description, location, date, start, end, image, url;
  final double cost;
  final bool finished;
  EventItem({required this.guid, required this.title, required this.description, required this.location, required this.date, required this.start, required this.end, required this.image, required this.url, required this.cost, required this.finished});
  factory EventItem.fromJson(Map j) => EventItem(
        guid: asInt(j['guid']),
        title: asStr(j['title']),
        description: asStr(j['description'] ?? j['info']),
        location: asStr(j['location']),
        date: asStr(j['date']),
        start: asStr(j['start_time']),
        end: asStr(j['end_time']),
        image: asStr(j['icon_url'] ?? j['image']),
        url: asStr(j['url']),
        cost: asDouble(j['event_cost']),
        finished: asBool(j['is_finished']),
      );

  /// Day and short month for the date badge, read from "mm/dd/yyyy" or "yyyy-mm-dd".
  (String day, String month) get badge {
    const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    final parts = date.split(RegExp(r'[/\-.]'));
    if (parts.length == 3) {
      final iso = parts[0].length == 4;
      final mo = int.tryParse(iso ? parts[1] : parts[0]) ?? 0;
      final d = int.tryParse(iso ? parts[2] : parts[1]) ?? 0;
      if (mo >= 1 && mo <= 12 && d > 0) return ('$d', m[mo - 1]);
    }
    return ('', '');
  }
}

class PollOption {
  final String key, title;
  final int votes;

  /// Share of the votes, 0-100, when the server sends percentages
  /// (poll/view and poll/vote send "votes" as {option hash: percent}).
  final double? percent;
  PollOption(this.key, this.title, this.votes, [this.percent]);
}

class Poll {
  final int guid;
  final String title;
  final bool ended;
  final List<PollOption> options;
  final DateTime time;

  /// Whether this member has voted already (from poll/voted or a list).
  final bool hasVoted;

  /// When the poll closes (null: no closing date).
  final DateTime? closesAt;

  /// Who created the poll (0 when the server did not say).
  final int ownerGuid;

  /// The server said this member created the poll.
  final bool mine;
  Poll(this.guid, this.title, this.ended, this.options, this.time, {this.hasVoted = false, this.closesAt, this.ownerGuid = 0, this.mine = false});

  /// Closed by the server, or its closing time has passed.
  bool get closed => ended || (closesAt != null && closesAt!.isBefore(DateTime.now()));

  /// Options arrive as a list or a map ("options", from the poll lists),
  /// or as JSON text in "description" (poll/view and poll/add send the
  /// raw poll object, where the choices live in description). Each may be
  /// text or a map. "votes", when present, is {option hash: percent}.
  factory Poll.fromJson(Map j) {
    dynamic raw = j['options'];
    if ((raw == null || (raw is! Map && raw is! List) || (raw is Map && raw.isEmpty) || (raw is List && raw.isEmpty)) && j['description'] is String) {
      try {
        raw = jsonDecode(j['description'] as String);
      } catch (_) {}
    }
    final votes = j['votes'] is Map ? j['votes'] as Map : const {};
    double? pct(String key) {
      final v = votes[key];
      if (v == null) return votes.isEmpty ? null : 0.0;
      return double.tryParse('$v');
    }

    final out = <PollOption>[];
    void add(String key, dynamic v) {
      if (v is Map) {
        final k = asStr(v['key'] ?? v['id'] ?? key);
        out.add(PollOption(k, asStr(v['title'] ?? v['text'] ?? v['option'] ?? v['name']), asInt(v['votes'] ?? v['count']), pct(k)));
      } else {
        out.add(PollOption(key, asStr(v), 0, pct(key)));
      }
    }

    if (raw is List) {
      for (var i = 0; i < raw.length; i++) {
        add('$i', raw[i]);
      }
    } else if (raw is Map) {
      raw.forEach((k, v) => add('$k', v));
    }
    final closes = asInt(j['closes_at']);
    return Poll(asInt(j['guid']), asStr(j['title']), asBool(j['is_ended']), out, asTime(j['time_created']),
        hasVoted: asBool(j['has_voted']),
        closesAt: closes > 0 ? DateTime.fromMillisecondsSinceEpoch(closes * 1000) : null,
        ownerGuid: asInt(j['owner_guid']),
        mine: asBool(j['is_creator']) || asBool(j['is_owner']));
  }

  Poll copyWith({List<PollOption>? options, bool? hasVoted, String? title}) =>
      Poll(guid, title ?? this.title, ended, options ?? this.options, time, hasVoted: hasVoted ?? this.hasVoted, closesAt: closesAt, ownerGuid: ownerGuid, mine: mine);

  int get totalVotes => options.fold(0, (a, o) => a + o.votes);

  /// Share of the votes for [o], 0-1, from counts or server percentages.
  double share(PollOption o) {
    final total = totalVotes;
    if (total > 0) return o.votes / total;
    return ((o.percent ?? 0) / 100).clamp(0.0, 1.0).toDouble();
  }
}

class BizPage {
  final int guid, likes, owner;
  final String name, description, category, website, phone, address, email, photo, cover, url;
  bool liked;
  BizPage({required this.guid, required this.name, required this.description, required this.category, required this.website, required this.phone, required this.address, required this.email, required this.photo, required this.cover, required this.url, required this.likes, required this.owner, required this.liked});
  factory BizPage.fromJson(Map j) => BizPage(
        guid: asInt(j['guid']),
        name: asStr(j['name'] ?? j['title']),
        description: asStr(j['description']),
        category: asStr(j['category']),
        website: asStr(j['website']),
        phone: asStr(j['phone']),
        address: asStr(j['address']),
        email: asStr(j['email']),
        photo: asStr(j['photo_url']),
        cover: asStr(j['cover_url']),
        url: asStr(j['page_url']),
        likes: asInt(j['likes_count']),
        owner: asInt(j['owner_guid']),
        liked: asBool(j['is_liked']),
      );
}

class Product {
  final int guid, owner;
  final String title, description, currency, location, category, cover, type;
  final double price;
  final bool sold;
  final DateTime time;
  Product({required this.guid, required this.owner, required this.title, required this.description, required this.currency, required this.location, required this.category, required this.cover, required this.type, required this.price, required this.sold, required this.time});

  /// Raw product records: fields may sit at the top level or under "data".
  factory Product.fromJson(Map j) {
    final d = j['data'] is Map ? j['data'] as Map : const {};
    dynamic f(String k) => j[k] ?? d[k];
    return Product(
      guid: asInt(f('guid')),
      owner: asInt(f('owner_guid')),
      title: asStr(f('title')),
      description: asStr(f('description') ?? f('desc')),
      currency: asStr(f('currency')).isEmpty ? 'NGN' : asStr(f('currency')),
      location: asStr(f('location')),
      category: asStr(f('category_title')),
      cover: iconUrl(f('cover') ?? f('cover_url') ?? f('image')),
      type: asStr(f('product_type')),
      price: asDouble(f('price')),
      sold: asBool(f('is_sold') ?? f('sold')) || asStr(f('status')).toLowerCase() == 'sold',
      time: asTime(f('time_created')),
    );
  }
  String get priceText => naira(price); // Evinie shows every price in Naira
}

class Order {
  final int guid, buyer, seller;
  final String title, status, currency, complaint;
  final double amount, net;
  final DateTime time;
  Order({required this.guid, required this.buyer, required this.seller, required this.title, required this.status, required this.currency, required this.complaint, required this.amount, required this.net, required this.time});
  factory Order.fromJson(Map j) => Order(
        guid: asInt(j['guid']),
        buyer: asInt(j['buyer_guid']),
        seller: asInt(j['seller_guid']),
        title: asStr(j['product_title']),
        status: asStr(j['status']),
        currency: asStr(j['currency']),
        complaint: asStr(j['complaint']),
        amount: asDouble(j['amount']),
        net: asDouble(j['net_amount']),
        time: asTime(j['ordered_time']),
      );
}
