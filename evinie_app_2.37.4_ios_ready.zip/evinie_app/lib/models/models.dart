import 'dart:convert';
import '../config.dart';

// The API sends numbers as strings in some places and numbers in others,
// and avatars either as a URL or as a map of sizes. These helpers accept
// both, so a small difference on the server never crashes the app.
int asInt(dynamic v) => v is int ? v : int.tryParse('${v ?? ''}') ?? 0;
bool asBool(dynamic v) => v == true || v == 1 || v == '1' || v == 'true';
String asStr(dynamic v) => v == null ? '' : decodeHtml('$v');

/// The server stores emoji and symbols as HTML codes (&#x1f4f8;, &amp;).
String decodeHtml(String s) {
  if (!s.contains('&')) return s;
  s = s.replaceAllMapped(RegExp(r'&#x([0-9a-fA-F]+);'), (m) {
    final c = int.tryParse(m[1]!, radix: 16);
    return c == null || c > 0x10FFFF ? m[0]! : String.fromCharCode(c);
  });
  s = s.replaceAllMapped(RegExp(r'&#(\d+);'), (m) {
    final c = int.tryParse(m[1]!);
    return c == null || c > 0x10FFFF ? m[0]! : String.fromCharCode(c);
  });
  const named = {'&quot;': '"', '&#039;': "'", '&apos;': "'", '&lt;': '<', '&gt;': '>', '&nbsp;': ' ', '&amp;': '&'};
  named.forEach((k, v) => s = s.replaceAll(k, v));
  return s;
}
DateTime asTime(dynamic v) => DateTime.fromMillisecondsSinceEpoch(asInt(v) * 1000);

/// Relative picture paths from the server become full addresses.
String absUrl(String u) {
  if (u.isEmpty || u.startsWith('http://') || u.startsWith('https://') || u.startsWith('data:')) return u;
  return '${AppConfig.siteUrl}/${u.replaceFirst(RegExp(r'^/+'), '')}';
}

/// An edited post can arrive as its stored JSON ({"post":"..."}): use the text.
String _unwrapPostJson(String t) {
  final s = t.trim();
  if (!s.startsWith('{') || !s.contains('"post"')) return t;
  try {
    final j = jsonDecode(s);
    if (j is Map && j['post'] != null) return '${j['post']}';
  } catch (_) {}
  return t;
}

/// Post text from the server can contain <br />, <p> and other tags.
String cleanText(String s) {
  s = s.replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');
  s = s.replaceAll(RegExp(r'</p>\s*', caseSensitive: false), '\n\n');
  s = s.replaceAll(RegExp(r'<[^>]+>'), '');
  s = s.replaceAll(RegExp(r'\n{3,}'), '\n\n');
  return s.trim();
}

String iconUrl(dynamic icon, {String size = 'large'}) => absUrl(_iconUrl(icon, size));

String _iconUrl(dynamic icon, String size) {
  if (icon is String) return icon;
  if (icon is Map) {
    for (final k in [size, 'large', 'small', 'smaller', 'topbar', 'larger']) {
      final v = icon[k];
      if (v is String && v.isNotEmpty) return v;
    }
  }
  return '';
}

class EvUser {
  final int guid;
  final String fullname;
  final String username;
  final String icon;
  final bool verified;
  EvUser({required this.guid, required this.fullname, this.username = '', this.icon = '', this.verified = false});

  factory EvUser.fromJson(Map json) {
    var name = asStr(json['fullname']);
    if (name.isEmpty) name = '${asStr(json['first_name'])} ${asStr(json['last_name'])}'.trim();
    return EvUser(
      guid: asInt(json['guid']),
      fullname: name.isEmpty ? asStr(json['username']) : name,
      username: asStr(json['username']),
      icon: iconUrl(json['icon'] ?? json['icon_url']),
      verified: asBool(json['verified'] ?? json['is_verified_user']),
    );
  }
  Map<String, Object> toJson() => {'guid': guid, 'fullname': fullname, 'username': username, 'icon': icon, 'verified': verified};
  String get firstName => fullname.split(' ').first;
}

class EvPost {
  final int guid;
  final String text;
  final String image;
  final String location;
  final DateTime time;
  final EvUser poster;
  int likes;
  bool liked;
  int comments;
  final String background;
  final int sharedGuid;
  final String itemType;
  final int itemGuid;
  EvPost({required this.guid, required this.text, required this.image, required this.location, required this.time,
      required this.poster, required this.likes, required this.liked, this.comments = 0, this.background = '', this.sharedGuid = 0, this.itemType = '', this.itemGuid = 0});

  /// One item of wall_list_home / wall_list_user / wall_add.
  factory EvPost.fromJson(Map json) {
    final post = (json['post'] is Map) ? json['post'] as Map : const {};
    var text = asStr(json['text']);
    if (text.isEmpty && post['description'] is String) {
      try {
        final d = jsonDecode(post['description']);
        if (d is Map) text = asStr(d['post']);
      } catch (_) {}
    }
    return EvPost(
      guid: asInt(post['guid']),
      text: cleanText(_unwrapPostJson(text)),
      image: absUrl(asStr(json['image'])),
      location: asStr(json['location']),
      time: asTime(post['time_created']),
      poster: EvUser.fromJson((json['user'] is Map) ? json['user'] : const {}),
      likes: asInt(post['total_likes']),
      liked: asBool(post['is_liked_by_user']),
      comments: asInt(json['total_comments'] ?? json['comments_count'] ?? (json['comments'] is List ? (json['comments'] as List).length : json['comments']) ?? post['total_comments']),
      background: asStr(post['postbackground_type'] ?? json['postbackground_type'] ?? (post['data'] is Map ? (post['data'] as Map)['postbackground_type'] : null)),
      sharedGuid: (asStr(post['item_type'] ?? json['item_type']) == 'post:share:post') ? asInt(post['item_guid'] ?? json['item_guid']) : 0,
      itemType: asStr(post['item_type'] ?? json['item_type']),
      itemGuid: asInt(post['item_guid'] ?? json['item_guid']),
    );
  }
}

class EvComment {
  final int id;
  final String text;
  final DateTime time;
  final EvUser user;
  int likes;
  bool liked;
  EvComment({required this.id, required this.text, required this.time, required this.user, this.likes = 0, this.liked = false});

  factory EvComment.fromJson(Map json, [Map? userOverride]) {
    final c = (json['comment'] is Map) ? json['comment'] as Map : json;
    final type = asStr(c['type']).isEmpty ? 'comments:post' : asStr(c['type']);
    return EvComment(
      id: asInt(c['id']),
      text: json['comment'] is String ? asStr(json['comment']) : asStr(c[type] ?? c['comments:post'] ?? c['comments:entity']),
      time: asTime(c['time_created']),
      user: EvUser.fromJson(userOverride ?? ((json['user'] is Map) ? json['user'] : const {})),
      likes: asInt(json['total_likes']),
      liked: asBool(json['is_liked_by_user']),
    );
  }
}

class EvNotification {
  final int guid;
  final String type;
  final EvUser poster;
  final DateTime time;
  final bool viewed;
  final int subjectGuid;
  EvNotification({required this.guid, required this.type, required this.poster, required this.time, required this.viewed, required this.subjectGuid});

  factory EvNotification.fromJson(Map json) {
    final n = (json['notification'] is Map) ? json['notification'] as Map : const {};
    return EvNotification(
      guid: asInt(n['guid']),
      type: asStr(n['type']),
      poster: EvUser.fromJson((json['poster'] is Map) ? json['poster'] : const {}),
      time: asTime(n['time_created']),
      viewed: asStr(n['viewed']).isNotEmpty && asStr(n['viewed']) != '0',
      subjectGuid: asInt(n['subject_guid']),
    );
  }

  /// Plain words for the notification types this site sends.
  String get action {
    const words = {
      'like:post': 'liked your post',
      'like:annotation': 'liked your comment',
      'like:entity:file:ossn:aphoto': 'liked your photo',
      'comments:post': 'commented on your post',
      'comments:entity:file:ossn:aphoto': 'commented on your photo',
      'wall:friends:tag': 'tagged you in a post',
      'ossnpoke:poke': 'poked you',
      'group:joinrequest': 'asked to join your group',
      'friend:request': 'sent you a friend request',
      'egift:received': 'sent you an eGift',
    };
    return words[type] ?? 'has an update for you';
  }
}

class EvMessage {
  final int id;
  final EvUser from;
  final EvUser to;
  final String text;
  final DateTime time;
  final bool viewed;
  EvMessage({required this.id, required this.from, required this.to, required this.text, required this.time, required this.viewed});

  factory EvMessage.fromJson(Map json) => EvMessage(
        id: asInt(json['id']),
        from: EvUser.fromJson((json['message_from'] is Map) ? json['message_from'] : const {}),
        to: EvUser.fromJson((json['message_to'] is Map) ? json['message_to'] : const {}),
        text: cleanText(asStr(json['message'])),
        time: asTime(json['time']),
        viewed: asBool(json['viewed']),
      );
}

/// Whether [u] is a video file. Looks inside Evinie media links too
/// (evinie-media?u=/stories/.../clip.mp4&t=...), whose address no longer
/// ends in the file name.
bool isVideoUrl(String u) {
  var s = u;
  try {
    s = Uri.decodeFull(u);
  } catch (_) {}
  return RegExp(r'\.(mp4|mov|webm|3gp|m4v)(\?|&|#|$)', caseSensitive: false).hasMatch(s);
}

/// Stories: the list endpoint's response is not documented, so this reads
/// the common shapes (a list of users, each with items that have a URL).
class EvStory {
  final EvUser user;
  final List<String> items;

  /// Picture for each item: the cover image for a video story (the video
  /// file itself can't be shown as a picture, so the tray tile was empty),
  /// otherwise the same as the item.
  final List<String> covers;

  /// Which items are videos (from the server's "type", or the file name).
  final List<bool> videos;
  EvStory(this.user, this.items, [List<String>? covers, List<bool>? videos])
      : covers = covers ?? items,
        videos = videos ?? [for (final i in items) isVideoUrl(i)];

  bool isVideoAt(int i) => i >= 0 && i < videos.length ? videos[i] : (i >= 0 && i < items.length && isVideoUrl(items[i]));

  static List<EvStory> listFrom(dynamic payload) {
    final raw = payload is Map ? (payload['list'] ?? payload['stories'] ?? payload['users']) : payload;
    if (raw is! List) return [];
    final out = <EvStory>[];
    for (final s in raw) {
      if (s is! Map) continue;
      final userMap = (s['user'] ?? s['owner'] ?? s) as Map;
      final itemsRaw = s['files'] ?? s['items'] ?? s['stories'] ?? s['list'] ?? [s];
      final items = <String>[];
      final covers = <String>[];
      final videos = <bool>[];
      if (itemsRaw is List) {
        for (final it in itemsRaw) {
          if (it is Map) {
            final u = absUrl(asStr(it['url'] ?? it['cover'] ?? it['file'] ?? it['media'] ?? it['image']));
            if (u.isNotEmpty) {
              items.add(u);
              final cover = absUrl(asStr(it['cover']));
              final video = asStr(it['type']) == 'video' || isVideoUrl(u);
              covers.add(cover.isNotEmpty ? cover : (video ? '' : u));
              videos.add(video);
            } else if (asStr(it['content'] ?? it['text'] ?? it['title']).isNotEmpty) {
              final t = 'text:${asStr(it['content'] ?? it['text'] ?? it['title'])}';
              items.add(t);
              covers.add(t);
              videos.add(false);
            }
          }
        }
      }
      if (items.isNotEmpty) out.add(EvStory(EvUser.fromJson(userMap), items, covers, videos));
    }
    return out;
  }
}
