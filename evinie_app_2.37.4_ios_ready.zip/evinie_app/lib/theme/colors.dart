import 'package:flutter/material.dart';

/// The Evinie palette (see the design system page of the app design).
class EvColors {
  static const ember1 = Color(0xFFFF7A33);
  static const ember2 = Color(0xFFEE4416);
  static const ink = Color(0xFF1F1A17);
  static const ink2 = Color(0xFF4A423D);
  static const muted = Color(0xFF8C827B);
  static const sand = Color(0xFFF6F3EE);
  static const sand2 = Color(0xFFEFEAE3);
  static const line = Color(0xFFECE5DC);
  static const card = Colors.white;
  static const peach = Color(0xFFFFF1E8);
  static const green = Color(0xFF15A34A);
  static const greenBg = Color(0xFFE7F6EC);
  static const blue = Color(0xFF2D7FF9);
  static const blueBg = Color(0xFFE8F1FF);
  static const gold = Color(0xFFF4A52B);
  static const red = Color(0xFFE5484D);
  static const redBg = Color(0xFFFDECEC);

  static const emberGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [ember1, ember2],
  );
}
