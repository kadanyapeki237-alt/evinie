import 'package:flutter/material.dart';
import 'colors.dart';

ThemeData evinieTheme() {
  const font = 'Poppins';
  final base = ThemeData(useMaterial3: true, fontFamily: font);
  OutlineInputBorder border(Color c, [double w = 1]) =>
      OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: c, width: w));
  return base.copyWith(
    scaffoldBackgroundColor: EvColors.sand,
    colorScheme: ColorScheme.fromSeed(seedColor: EvColors.ember2, primary: EvColors.ember2, surface: EvColors.sand),
    appBarTheme: const AppBarTheme(
      backgroundColor: EvColors.sand,
      foregroundColor: EvColors.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(fontFamily: font, fontSize: 18, fontWeight: FontWeight.w700, color: EvColors.ink),
    ),
    textTheme: base.textTheme.apply(bodyColor: EvColors.ink, displayColor: EvColors.ink, fontFamily: font),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      hintStyle: const TextStyle(color: EvColors.muted, fontSize: 13),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: border(EvColors.line),
      enabledBorder: border(EvColors.line),
      focusedBorder: border(EvColors.ember1, 1.5),
      errorBorder: border(EvColors.red),
      focusedErrorBorder: border(EvColors.red, 1.5),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating, backgroundColor: EvColors.ink),
    dividerColor: EvColors.line,
  );
}
