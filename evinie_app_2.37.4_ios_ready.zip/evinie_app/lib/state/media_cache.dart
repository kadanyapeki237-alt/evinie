import 'package:file/file.dart' as fs;
import 'package:file/local.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:path_provider/path_provider.dart';

/// Pictures and videos stay on the phone for a year (up to 5,000 files),
/// so they show even without a network - also after the phone restarts.
///
/// 2.37.1: the files are kept in the app's permanent folder. They used to
/// sit in the phone's temporary (cache) folder, which Android and phone
/// "cleaner" tools empty, often on restart.
final CacheManager evCache = CacheManager(Config(
  'evinie_media',
  stalePeriod: const Duration(days: 365),
  maxNrOfCacheObjects: 5000,
  fileSystem: _KeptFileSystem('evinie_media'),
));

/// Like the cache manager's own file system, but in the support folder.
class _KeptFileSystem implements FileSystem {
  final String _key;
  late final Future<fs.Directory> _dir = _create();
  _KeptFileSystem(this._key);

  Future<fs.Directory> _create() async {
    final base = await getApplicationSupportDirectory();
    final dir = const LocalFileSystem().directory('${base.path}/$_key');
    await dir.create(recursive: true);
    return dir;
  }

  @override
  Future<fs.File> createFile(String name) async {
    final dir = await _dir;
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir.childFile(name);
  }
}

/// Downloads [url] to the phone in the background if it isn't saved yet.
///
/// 2.37.2: downloads wait in a line and run ONE at a time, and they pause
/// while a video on screen is still loading ([holdDownloads]). Before, the
/// reel being watched shared the connection with full downloads of itself
/// and the next two reels, so it only started once those had loaded.
final List<String> _line = [];
final Set<String> _fetching = {};
bool _running = false;
int _held = 0;

Future<void> prefetchMedia(String url) async {
  if (url.isEmpty || _fetching.contains(url) || _line.contains(url)) return;
  _line.add(url);
  _pump();
}

/// Moves [url] to the front of the line (the next thing to download).
void prefetchFirst(String url) {
  if (url.isEmpty || _fetching.contains(url)) return;
  _line.remove(url);
  _line.insert(0, url);
  _pump();
}

/// While held, background downloads wait so the video on screen gets the
/// whole connection. Every hold must be released once.
void holdDownloads() => _held++;
void releaseDownloads() {
  if (_held > 0) _held--;
}

Future<void> _pump() async {
  if (_running) return;
  _running = true;
  try {
    while (_line.isNotEmpty) {
      var waited = 0;
      while (_held > 0 && waited < 120) {
        await Future.delayed(const Duration(milliseconds: 500));
        waited++; // never wait more than a minute for a stuck hold
      }
      final url = _line.removeAt(0);
      _fetching.add(url);
      try {
        if (await evCache.getFileFromCache(url) == null) await evCache.downloadFile(url);
      } catch (_) {
        // Not downloaded now; the player will try again when it opens.
      } finally {
        _fetching.remove(url);
      }
    }
  } finally {
    _running = false;
  }
}
