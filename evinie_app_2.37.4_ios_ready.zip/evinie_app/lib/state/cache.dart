import 'dart:convert';
import 'dart:io';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';

/// Saved copies of what the app has loaded, kept on the phone until the
/// owner clears them (Settings > Clear saved data, the phone's "Clear
/// storage" for Evinie, or deleting the app). Signing out does NOT clear it.
///
/// - Encrypted (AES-256). The key is kept in the phone's secure storage and
///   in Evinie's private folder, so it survives restarts.
/// - One store per account: another person signing in on the same phone
///   never sees this account's saved data.
/// - Stored in the app's permanent support folder (not the cache folder
///   the system may empty when space runs low).
class LocalCache {
  LocalCache._();
  static const _secure = FlutterSecureStorage();
  static const _keyName = 'cache_key';
  static String? _dir;
  static List<int>? _key;
  static Box<String>? _box;
  static int _owner = 0;

  static Future<void> init() async {
    try {
      final support = await getApplicationSupportDirectory();
      _dir = '${support.path}/evinie_saved';
      await Directory(_dir!).create(recursive: true);
      Hive.init(_dir!);
    } catch (_) {
      _dir = null; // Saving is a convenience: the app works without it.
      return;
    }
    _key = await _loadKey();
  }

  /// 2.37.1: the key is also kept in the app's private folder. After a
  /// restart some phones can't read the secure storage for a moment (or at
  /// all); the app then made a NEW key, and the saved data - locked with
  /// the old one - could no longer be read, so everything showed as empty
  /// and nothing loaded offline. The private folder is only readable by
  /// Evinie and is encrypted by the phone itself.
  static File get _keyFile => File('$_dir/.saved_key');

  static Future<List<int>?> _loadKey() async {
    List<int>? key;
    try {
      if (await _keyFile.exists()) {
        final k = base64Decode((await _keyFile.readAsString()).trim());
        if (k.length == 32) key = k;
      }
    } catch (_) {}
    if (key == null) {
      // Older versions kept the key only in secure storage: read it (try a
      // few times, the phone's key store can be slow right after a restart).
      for (var i = 0; i < 4 && key == null; i++) {
        try {
          final stored = await _secure.read(key: _keyName);
          if (stored != null) {
            final k = base64Decode(stored);
            if (k.length == 32) key = k;
          }
          if (stored == null) break;
        } catch (_) {
          await Future.delayed(const Duration(milliseconds: 500));
        }
      }
    }
    if (key == null) {
      // A brand-new phone (or saved data that can no longer be opened):
      // start a fresh store with a new key.
      key = Hive.generateSecureKey();
      try {
        await for (final f in Directory(_dir!).list()) {
          if (f is File && (f.path.endsWith('.hive') || f.path.endsWith('.lock'))) await f.delete();
        }
      } catch (_) {}
    }
    try {
      await _keyFile.writeAsString(base64Encode(key), flush: true);
    } catch (_) {}
    try {
      await _secure.write(key: _keyName, value: base64Encode(key));
    } catch (_) {}
    return key;
  }

  /// Small plain settings that must survive restarts (not secret).
  static Future<String?> readSetting(String name) async {
    if (_dir == null) return null;
    try {
      final f = File('$_dir/.$name');
      return await f.exists() ? (await f.readAsString()).trim() : null;
    } catch (_) {
      return null;
    }
  }

  static Future<void> writeSetting(String name, String value) async {
    if (_dir == null) return;
    try {
      await File('$_dir/.$name').writeAsString(value, flush: true);
    } catch (_) {}
  }

  /// Switch to the signed-in account's store (0 = nobody signed in).
  static Future<void> useAccount(int guid) async {
    if (_owner == guid && (_box?.isOpen ?? false)) return;
    await _box?.close();
    _box = null;
    _owner = guid;
    if (guid <= 0 || _dir == null || _key == null) return;
    try {
      _box = await Hive.openBox<String>('account_$guid', encryptionCipher: HiveAesCipher(_key!));
    } catch (_) {
      _box = null;
    }
  }

  static Future<void> put(String key, dynamic payload) async {
    final b = _box;
    if (b == null) return;
    try {
      await b.put(key, jsonEncode({'t': DateTime.now().millisecondsSinceEpoch, 'p': payload}));
      // Written to the phone's storage straight away, so a restart or a
      // battery pull doesn't lose it.
      await b.flush();
    } catch (_) {}
  }

  /// The saved payload and when it was saved, or null.
  static (dynamic, DateTime)? get(String key) {
    final raw = _box?.get(key);
    if (raw == null) return null;
    try {
      final m = jsonDecode(raw) as Map;
      return (m['p'], DateTime.fromMillisecondsSinceEpoch(m['t'] as int));
    } catch (_) {
      return null;
    }
  }

  /// Settings > Clear saved data: removes every account's saved data on
  /// this phone. The encryption key is replaced too.
  static Future<void> clearAll() async {
    final owner = _owner;
    await Hive.close();
    _box = null;
    _owner = 0;
    if (_dir != null) {
      try {
        await Directory(_dir!).delete(recursive: true);
      } catch (_) {}
    }
    try {
      await _secure.delete(key: _keyName);
    } catch (_) {}
    await init();
    await useAccount(owner);
  }

  /// Rough size of saved data, for Settings.
  static Future<int> sizeInBytes() async {
    if (_dir == null) return 0;
    var total = 0;
    try {
      await for (final f in Directory(_dir!).list(recursive: true)) {
        if (f is File) total += await f.length();
      }
    } catch (_) {}
    return total;
  }
}
