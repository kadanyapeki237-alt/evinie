import 'dart:convert';
import 'dart:io';
import 'package:flutter/widgets.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../api/api_client.dart';
import '../api/evinie_api.dart';
import '../models/models.dart';
import 'cache.dart';

/// Who is signed in. The token lives in the phone's secure storage
/// (Keychain on iOS, encrypted storage on Android), never in plain files.
class Session extends ChangeNotifier {
  static const _storage = FlutterSecureStorage();
  EvUser? me;
  bool ready = false;
  EvUser _last = EvUser(guid: 0, fullname: '');

  /// The signed-in member. While screens close after signing out they
  /// still rebuild once, so this keeps the last known member for them.
  EvUser get current => me ?? _last;

  bool get signedIn => me != null;

  Future<void> load() async {
    ApiClient.instance.onSessionExpired = () => _clear(notify: true);
    try {
      // Right after a phone restart the secure storage can fail for a
      // moment: try again before deciding nobody is signed in.
      Future<String?> read(String k) async {
        for (var i = 0; i < 3; i++) {
          try {
            return await _storage.read(key: k);
          } catch (_) {
            await Future.delayed(const Duration(milliseconds: 600));
          }
        }
        return await _storage.read(key: k);
      }

      final token = await read('token');
      var user = await read('user');
      // The last signed-in member is also kept with the saved data, so the
      // app opens straight to the saved feed even offline.
      user ??= token != null ? await LocalCache.readSetting('last_user') : null;
      if (token != null && user != null) {
        ApiClient.instance.token = token;
        me = _last = EvUser.fromJson(jsonDecode(user) as Map);
        await LocalCache.useAccount(me!.guid);
        // Refresh the profile in the background; an expired token signs out.
        EvinieApi.instance.me().then((u) {
          me = _last = u;
          _storage.write(key: 'user', value: jsonEncode(u.toJson()));
          LocalCache.writeSetting('last_user', jsonEncode(u.toJson()));
          notifyListeners();
        }).catchError((_) {});
      }
    } catch (_) {
      await _clear();
    }
    ready = true;
    notifyListeners();
  }

  Future<void> signIn(String username, String password, {String challenge = '', String code = ''}) async {
    final device = Platform.isIOS ? 'iPhone' : (Platform.isAndroid ? 'Android phone' : 'Phone');
    final (token, _, user) = await EvinieApi.instance.signIn(username, password, device, challenge: challenge, code: code);
    ApiClient.instance.token = token;
    me = _last = user;
    await LocalCache.useAccount(user.guid);
    await _storage.write(key: 'token', value: token);
    await _storage.write(key: 'user', value: jsonEncode(user.toJson()));
    await LocalCache.writeSetting('last_user', jsonEncode(user.toJson()));
    notifyListeners();
  }

  Future<void> signOut() async {
    await EvinieApi.instance.signOut();
    await _clear(notify: true);
  }

  Future<void> _clear({bool notify = false}) async {
    ApiClient.instance.token = null;
    me = null;
    // Only the sign-in is removed. Saved data (and its key) stays until the
    // owner clears it in Settings or in the phone's app settings.
    await _storage.delete(key: 'token');
    await _storage.delete(key: 'user');
    await LocalCache.useAccount(0);
    if (notify) notifyListeners();
  }
}

/// Makes the session available to every screen: Scope.of(context).
class Scope extends InheritedNotifier<Session> {
  const Scope({super.key, required Session session, required super.child}) : super(notifier: session);
  static Session of(BuildContext context) => context.dependOnInheritedWidgetOfExactType<Scope>()!.notifier!;
  static Session read(BuildContext context) => context.getInheritedWidgetOfExactType<Scope>()!.notifier!;
}
