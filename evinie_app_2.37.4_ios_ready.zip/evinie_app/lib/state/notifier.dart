import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

/// Phone notifications (with the phone's notification tone and vibration)
/// for new notifications and chat messages.
///
/// They work while Evinie is open or running in the background. Before,
/// the app only drew its own pop-up inside the app (invisible when you were
/// in another app) and played an "alert" sound that Android does not
/// support, so nothing was heard.
class Notifier {
  Notifier._();
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;
  static int _id = 0;

  /// Called with the notification's payload ("notifications" or
  /// "chat:<guid>") when the person taps it.
  static void Function(String payload)? onTap;

  static const _channel = AndroidNotificationChannel(
    'evinie_alerts',
    'Notifications and messages',
    description: 'New notifications and chat messages on Evinie',
    importance: Importance.high,
  );

  static Future<void> init() async {
    if (_ready) return;
    try {
      await _plugin.initialize(
        const InitializationSettings(
          android: AndroidInitializationSettings('ic_stat_evinie'),
          iOS: DarwinInitializationSettings(requestAlertPermission: false, requestBadgePermission: false, requestSoundPermission: false),
        ),
        onDidReceiveNotificationResponse: (r) => onTap?.call(r.payload ?? 'notifications'),
      );
      await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(_channel);
      _ready = true;
    } catch (_) {
      // Notifications unavailable on this device; the app works without them.
    }
  }

  /// Asks for permission to show notifications (Android 13+ and iPhone).
  static Future<void> askPermission() async {
    await init();
    try {
      await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
      await _plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()?.requestPermissions(alert: true, badge: true, sound: true);
    } catch (_) {}
  }

  static Future<void> show(String title, String body, {String payload = 'notifications'}) async {
    await init();
    if (!_ready) return;
    try {
      _id = (_id + 1) % 100000;
      await _plugin.show(
        _id,
        title,
        body,
        NotificationDetails(
          android: AndroidNotificationDetails(
            _channel.id,
            _channel.name,
            channelDescription: _channel.description,
            importance: Importance.high,
            priority: Priority.high,
            playSound: true,
            enableVibration: true,
            color: const Color(0xFFFF5A02),
            category: AndroidNotificationCategory.social,
            styleInformation: BigTextStyleInformation(body),
          ),
          iOS: const DarwinNotificationDetails(presentAlert: true, presentSound: true, presentBadge: true),
        ),
        payload: payload,
      );
    } catch (_) {}
  }
}
