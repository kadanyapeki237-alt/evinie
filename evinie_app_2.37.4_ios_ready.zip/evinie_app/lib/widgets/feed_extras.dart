import '../screens/market_screens.dart';
import '../screens/grow_screens.dart';
import '../state/media_cache.dart';
import 'package:share_plus/share_plus.dart';
import '../screens/money_screens.dart';
import '../models/money.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:video_player/video_player.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api/api_client.dart';
import '../api/community_api.dart';
import '../api/more_api.dart';
import '../models/community.dart';
import '../models/models.dart';
import '../screens/discover_screens.dart';
import '../screens/feed_screens.dart';
import '../theme/colors.dart';
import 'common.dart';

/// Sections shown between posts in the home feed, like the website.
/// Each loads its own data and hides itself when there is nothing to show.

class _Section extends StatelessWidget {
  final String title;
  final Widget child;
  const _Section(this.title, this.child);
  @override
  Widget build(BuildContext context) => Container(
        color: Colors.white,
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(vertical: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 10), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
          child,
        ]),
      );
}

/// [fixed]: exactly w x h (thumbnails inside a row). Without it the picture
/// fills its card's width at 200 high, as the page, reel and product cards
/// use it. A row thumbnail without [fixed] could not be laid out, which
/// left the whole campaign card on My Ads blank.
Widget _img(String url, double w, double h, {double r = 16, bool fixed = false}) => SizedBox(height: fixed ? h : 200, width: fixed ? w : double.infinity, child: ClipRRect(
      borderRadius: BorderRadius.circular(r),
      child: url.isEmpty
          ? Container(width: w, height: h, color: EvColors.sand2)
          : CachedNetworkImage(cacheManager: evCache, imageUrl: url, width: w, height: h, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(width: w, height: h, color: EvColors.sand2)),
    ));

class BirthdaysSection extends StatefulWidget {
  const BirthdaysSection({super.key});
  @override
  State<BirthdaysSection> createState() => _BirthdaysSectionState();
}

class _BirthdaysSectionState extends State<BirthdaysSection> {
  List<Map> _list = [];
  @override
  void initState() {
    super.initState();
    ApiClient.instance.post('birthday/upcoming').then((p) {
      if (mounted) setState(() => _list = listOf(mapOf(p)['birthdays'] ?? p));
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    if (_list.isEmpty) return const SizedBox.shrink();
    return _Section(
      'Birthdays',
      SizedBox(
        height: 196,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _list.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, i) {
            final b = _list[i];
            final u = EvUser.fromJson(mapOf(b['user']).isNotEmpty ? mapOf(b['user']) : b);
            return Container(
              width: 140,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFFFF8EC), borderRadius: BorderRadius.circular(18)),
              child: Column(children: [
                Container(padding: const EdgeInsets.all(2.5), decoration: const BoxDecoration(shape: BoxShape.circle, color: EvColors.gold), child: Avatar(u, size: 58)),
                const SizedBox(height: 6),
                Text(u.fullname, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
                Text(str(b, 'birthdate'), maxLines: 1, style: const TextStyle(color: Color(0xFFB36F00), fontSize: 11, fontWeight: FontWeight.w600)),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  height: 32,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CreatePostScreen(initialText: 'Happy birthday ${u.fullname}! 🎉🎂 '), fullscreenDialog: true)),
                    style: ElevatedButton.styleFrom(backgroundColor: EvColors.ember2, foregroundColor: Colors.white, elevation: 0, padding: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                    child: const Text('Wish 🎉', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ),
              ]),
            );
          },
        ),
      ),
    );
  }
}

/// One sponsored ad (offset picks which, so different slots show different ads).
class AdSection extends StatefulWidget {
  final int offset;
  const AdSection({super.key, this.offset = 1});
  @override
  State<AdSection> createState() => _AdSectionState();
}

class _AdSectionState extends State<AdSection> {
  /// Ads already shown in this app session: the server picks a different
  /// one (at random, newer ads more often) until all have been seen.
  static final List<int> _shown = [];
  Map? _ad;
  @override
  void initState() {
    super.initState();
    final recent = _shown.length > 50 ? _shown.sublist(_shown.length - 50) : _shown;
    ApiClient.instance.post('adsinserter/ad', {'offset': widget.offset, if (recent.isNotEmpty) 'exclude': recent.join(',')}).then((p) {
      final m = mapOf(p);
      if (!asBool(m['has_ad'])) return;
      final ad = mapOf(m['ad']);
      final g = asInt(ad['guid']);
      if (g > 0) {
        _shown.remove(g);
        _shown.add(g);
      }
      if (mounted) setState(() => _ad = ad);
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final a = _ad;
    if (a == null || a.isEmpty) return const SizedBox.shrink();
    final link = str(a, 'link');
    final image = absUrl(str(a, 'image'));
    return _Section(
      'Sponsored',
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (str(a, 'title').isNotEmpty) Text(str(a, 'title'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
          if (str(a, 'description').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4, bottom: 10), child: Text(cleanText(str(a, 'description')), style: const TextStyle(height: 1.45))),
          if (image.isNotEmpty)
            GestureDetector(
              // Tapping the picture counts as a click too, like on the website.
              onTap: link.isEmpty ? null : () => openAdLink(asInt(a['guid']), 'feed', link),
              child: ClipRRect(borderRadius: BorderRadius.circular(16), child: CachedNetworkImage(cacheManager: evCache, imageUrl: image, width: double.infinity, fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox.shrink())),
            ),
          if (link.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: SizedBox(width: double.infinity, child: EmberButton('Learn more', onPressed: () => openAdLink(asInt(a['guid']), 'feed', link))),
            ),
        ]),
      ),
    );
  }
}

class GroupsSection extends StatefulWidget {
  const GroupsSection({super.key});
  @override
  State<GroupsSection> createState() => _GroupsSectionState();
}

class _GroupsSectionState extends State<GroupsSection> {
  List<Group> _list = [];
  @override
  void initState() {
    super.initState();
    CommunityApi.instance.groups().then((g) {
      if (mounted) setState(() => _list = g.where((x) => !x.isMember).take(10).toList());
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    if (_list.isEmpty) return const SizedBox.shrink();
    return _Section(
      'Groups you may like',
      SizedBox(
        height: 150,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _list.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, i) {
            final g = _list[i];
            return Container(
              width: 150,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(18), border: const Border(top: BorderSide(color: EvColors.ember1, width: 3))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(g.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text('${g.members} members', style: const TextStyle(color: EvColors.ember2, fontSize: 12, fontWeight: FontWeight.w600)),
                const Spacer(),
                SizedBox(
                  width: double.infinity,
                  height: 34,
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupScreen(group: g))),
                    style: ElevatedButton.styleFrom(backgroundColor: EvColors.ink, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                    child: const Text('View group', style: TextStyle(fontSize: 12)),
                  ),
                ),
              ]),
            );
          },
        ),
      ),
    );
  }
}

/// People you may know, on the home feed (same cards as Discover).
class PeopleSection extends StatefulWidget {
  const PeopleSection({super.key});
  @override
  State<PeopleSection> createState() => _PeopleSectionState();
}

class _PeopleSectionState extends State<PeopleSection> {
  /// Loaded once per app session and shared by every strip in the feed.
  static List<EvUser>? _cache;
  List<EvUser> _list = _cache ?? const [];
  @override
  void initState() {
    super.initState();
    if (_cache != null) return;
    CommunityApi.instance.suggestions().then((u) {
      _cache = u;
      if (mounted) setState(() => _list = u);
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    if (_list.isEmpty) return const SizedBox.shrink();
    return _Section(
      'People you may know',
      SizedBox(
        height: 150,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _list.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, i) => GestureDetector(
            onTap: () => openProfile(context, _list[i]),
            child: SizedBox(width: 118, child: EvCard(padding: const EdgeInsets.all(12), child: Column(children: [Avatar(_list[i], size: 56), const SizedBox(height: 8), Text(_list[i].fullname, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)), const Text('View profile', style: TextStyle(color: EvColors.ember2, fontSize: 11.5, fontWeight: FontWeight.w600))]))),
          ),
        ),
      ),
    );
  }
}

class PagesSection extends StatefulWidget {
  const PagesSection({super.key});
  @override
  State<PagesSection> createState() => _PagesSectionState();
}

class _PagesSectionState extends State<PagesSection> {
  List<BizPage> _list = [];
  @override
  void initState() {
    super.initState();
    CommunityApi.instance.pages().then((p) {
      if (mounted) setState(() => _list = p.take(10).toList());
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    if (_list.isEmpty) return const SizedBox.shrink();
    return _Section(
      'Pages you may like',
      SizedBox(
        height: 204,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _list.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, i) {
            final p = _list[i];
            return GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PageScreen(page: p))),
              child: Container(
                width: 140,
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: EvColors.line)),
                child: Column(children: [
                  _img(absUrl(p.photo), 140, 120, r: 17),
                  Padding(padding: const EdgeInsets.fromLTRB(8, 8, 8, 6), child: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5))),
                  Container(
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    height: 30,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(color: p.liked ? EvColors.green : EvColors.ember2, borderRadius: BorderRadius.circular(10)),
                    child: Text(p.liked ? 'Liked' : 'View page', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
    );
  }
}

/// Opens an advert's link and counts the click on the server
/// (EndPoints 4.44 ads/click). The link opens straight away; the count is
/// sent alongside, so a slow network never delays the advertiser's page.
void openAdLink(int guid, String kind, String link) {
  if (guid > 0) {
    ApiClient.instance.post('ads/click', {'guid': guid, 'kind': kind}).then((_) {}, onError: (_) {});
  }
  final uri = Uri.tryParse(link.startsWith('http') ? link : 'https://$link');
  if (uri != null) launchUrl(uri, mode: LaunchMode.externalApplication);
}

/// Menu > Ads: your campaigns, with spend, impressions and clicks.
class AdsScreen extends StatefulWidget {
  const AdsScreen({super.key});
  @override
  State<AdsScreen> createState() => _AdsScreenState();
}

class _AdsScreenState extends State<AdsScreen> {
  Map? _d;
  String? _error;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = mapOf(await ApiClient.instance.post('ads/campaigns'));
      if (mounted) setState(() => _d = d);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  Future<void> _create() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CreateAdScreen()));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final list = listOf(_d?['list']);
    final active = list.where((c) => str(c, 'status') == 'active').length;
    final views = list.fold<int>(0, (a, c) => a + asInt(c['views']));
    final clicks = list.fold<int>(0, (a, c) => a + asInt(c['clicks']));
    return Scaffold(
      appBar: AppBar(title: const Text('My Ads')),
      body: _error != null
          ? StateMessage(icon: Icons.campaign_outlined, title: 'Ads are not available', body: _error!, action: 'Try again', onAction: _load)
          : _d == null
              ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(padding: const EdgeInsets.all(16), children: [
                    EmberButton('Create Ad', icon: Icons.add_rounded, onPressed: _create),
                    const SizedBox(height: 14),
                    if (list.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: EvColors.ink, borderRadius: BorderRadius.circular(18)),
                        child: Row(children: [
                          for (final x in [('Spent', naira(asDouble(_d!['spent']))), ('Active', '$active'), ('Impressions', '$views'), ('Clicks', '$clicks')])
                            Expanded(child: Column(children: [Text(x.$2, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)), Text(x.$1, style: const TextStyle(color: Colors.white60, fontSize: 11))])),
                        ]),
                      ),
                    const SizedBox(height: 14),
                    Row(children: [const Text('Campaigns', style: TextStyle(fontWeight: FontWeight.w700)), const Spacer(), Text('$active active · ${list.length} total', style: const TextStyle(color: EvColors.muted, fontSize: 12))]),
                    const SizedBox(height: 8),
                    if (list.isEmpty)
                      const Padding(padding: EdgeInsets.all(30), child: Text('No campaigns yet. Create your first ad to reach people on the newsfeed.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))),
                    for (final c in list)
                      GestureDetector(
                        onTap: () async {
                          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => CampaignScreen(guid: asInt(c['guid']))));
                          _load();
                        },
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: EvColors.line)),
                          child: Column(children: [
                            Row(children: [
                              _img(absUrl(str(c, 'image')), 46, 46, r: 10, fixed: true),
                              const SizedBox(width: 10),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(str(c, 'title'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)), Text('${asInt(c['days'])} days · ${naira(asDouble(c['per_day']))}/day', style: const TextStyle(color: EvColors.muted, fontSize: 12))])),
                              _statusChip(str(c, 'status')),
                            ]),
                            const Divider(height: 18),
                            Row(children: [
                              Expanded(child: _stat(naira(asDouble(c['charged'])), 'spent')),
                              Expanded(child: _stat('${asInt(c['views'])}', 'impressions')),
                              Expanded(child: _stat('${asInt(c['clicks'])}', 'clicks')),
                              const Icon(Icons.chevron_right_rounded, color: EvColors.muted),
                            ]),
                          ]),
                        ),
                      ),
                  ]),
                ),
    );
  }
}

Widget _stat(String v, String l) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(v, style: const TextStyle(fontWeight: FontWeight.w700)), Text(l, style: const TextStyle(color: EvColors.muted, fontSize: 11))]);

Widget _statusChip(String s) {
  final c = switch (s) { 'active' => EvColors.green, 'paused' => EvColors.gold, _ => EvColors.muted };
  return Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3), decoration: BoxDecoration(color: c.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)), child: Text(s.isEmpty ? '' : s[0].toUpperCase() + s.substring(1), style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w700)));
}

/// One campaign: preview, 7-day impressions chart, pause switch and options.
class CampaignScreen extends StatefulWidget {
  final int guid;
  const CampaignScreen({super.key, required this.guid});
  @override
  State<CampaignScreen> createState() => _CampaignScreenState();
}

class _CampaignScreenState extends State<CampaignScreen> {
  Map? _c;
  bool _busy = false;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final c = mapOf(await ApiClient.instance.post('ads/campaign', {'guid': widget.guid}));
      if (mounted) setState(() => _c = c);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  Future<void> _run(String method, Map<String, Object?> f, String done) async {
    setState(() => _busy = true);
    try {
      final r = mapOf(await ApiClient.instance.post(method, {'guid': widget.guid, ...f}));
      if (mounted) {
        showMessage(context, done);
        if (r.containsKey('status')) setState(() => _c = r);
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _edit() async {
    final c = _c!;
    final t = TextEditingController(text: str(c, 'title')), d = TextEditingController(text: str(c, 'description')), l = TextEditingController(text: str(c, 'link'));
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (s) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(s).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Edit ad', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 10),
          TextField(controller: t, decoration: const InputDecoration(hintText: 'Headline')),
          const SizedBox(height: 8),
          TextField(controller: d, maxLines: 3, decoration: const InputDecoration(hintText: 'Ad copy')),
          const SizedBox(height: 8),
          TextField(controller: l, decoration: const InputDecoration(hintText: 'https://')),
          const SizedBox(height: 12),
          EmberButton('Save changes', onPressed: () => Navigator.pop(s, true)),
        ]),
      ),
    );
    if (ok == true) await _run('ads/edit', {'title': t.text.trim(), 'description': d.text.trim(), 'link': l.text.trim()}, 'Ad updated.');
    t.dispose();
    d.dispose();
    l.dispose();
  }

  Future<void> _delete() async {
    final c = _c!;
    final left = ((asInt(c['ends']) - DateTime.now().millisecondsSinceEpoch ~/ 1000) / 86400).floor().clamp(0, 999);
    final refund = left * asInt(c['per_day']);
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: const Text('Delete this campaign?'), content: Text(refund > 0 ? 'The ad stops at once. About ${naira(refund.toDouble())} for $left unused day(s) goes back to your Wallet.' : 'The ad stops at once. This cannot be undone.'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete', style: TextStyle(color: EvColors.red)))]));
    if (ok != true) return;
    try {
      final r = mapOf(await ApiClient.instance.post('ads/delete', {'guid': widget.guid}));
      if (!mounted) return;
      showMessage(context, asDouble(r['refunded']) > 0 ? 'Deleted. ${naira(asDouble(r['refunded']))} refunded to your Wallet.' : 'Campaign deleted.');
      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = _c;
    if (c == null) return Scaffold(appBar: AppBar(title: const Text('Campaign')), body: const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    final daily = listOf(c['daily']);
    final top = daily.fold<int>(1, (a, d) => asInt(d['views']) > a ? asInt(d['views']) : a);
    final views = asInt(c['views']), clicks = asInt(c['clicks']);
    final ctr = views == 0 ? 0.0 : clicks * 100 / views;
    final status = str(c, 'status');
    final ends = DateTime.fromMillisecondsSinceEpoch(asInt(c['ends']) * 1000);
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return Scaffold(
      appBar: AppBar(title: const Text('My Ads')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Row(children: [_img(absUrl(str(c, 'image')), 52, 52, r: 12, fixed: true), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(str(c, 'title'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)), Text(str(c, 'description'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: EvColors.muted, fontSize: 12))])), _statusChip(status)]),
          const SizedBox(height: 14),
          EvCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [Text('Daily impressions', style: TextStyle(fontWeight: FontWeight.w700)), Spacer(), Text('Last 7 days', style: TextStyle(color: EvColors.muted, fontSize: 12))]),
              const SizedBox(height: 12),
              SizedBox(
                height: 140,
                child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  for (final d in daily)
                    Expanded(
                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                        Text('${asInt(d['views'])}', style: const TextStyle(fontSize: 10, color: EvColors.muted)),
                        const SizedBox(height: 3),
                        Container(height: 6 + 96 * asInt(d['views']) / top, margin: const EdgeInsets.symmetric(horizontal: 5), decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(6))),
                        const SizedBox(height: 5),
                        Text(days[(DateTime.tryParse(str(d, 'date')) ?? DateTime.now()).weekday - 1], style: const TextStyle(fontSize: 11, color: EvColors.muted)),
                      ]),
                    ),
                ]),
              ),
            ]),
          ),
          const SizedBox(height: 12),
          Row(children: [
            for (final x in [(naira(asDouble(c['charged'])), 'Spent'), ('$views', 'Impressions'), ('$clicks', 'Clicks'), ('${ctr.toStringAsFixed(1)}%', 'Click rate')])
              Expanded(child: Container(margin: const EdgeInsets.symmetric(horizontal: 3), padding: const EdgeInsets.symmetric(vertical: 10), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)), child: Column(children: [Text(x.$1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)), Text(x.$2, style: const TextStyle(color: EvColors.muted, fontSize: 10.5))]))),
          ]),
          const SizedBox(height: 12),
          EvCard(
            padding: EdgeInsets.zero,
            child: Column(children: [
              SwitchListTile(
                value: status == 'paused',
                activeColor: EvColors.ember2,
                onChanged: status == 'ended' || _busy ? null : (v) => _run('ads/pause', {'paused': v ? 1 : 0}, v ? 'Campaign paused.' : 'Campaign resumed. Paused days were added back.'),
                title: const Text('Pause campaign', style: TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(status == 'ended' ? 'This campaign has ended.' : 'Ends ${ends.day}/${ends.month}/${ends.year}. Paused days are added back when you resume.', style: const TextStyle(fontSize: 12)),
              ),
            ]),
          ),
          const SizedBox(height: 14),
          OutlineEmberButton('Manage campaign options', onPressed: () => showModalBottomSheet<void>(
                context: context,
                backgroundColor: Colors.white,
                builder: (s) => SafeArea(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Padding(padding: EdgeInsets.all(14), child: Text('Ad campaign options', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                    ListTile(leading: const Tile(Icons.edit_rounded, EvColors.ember2), title: const Text('Edit campaign'), subtitle: const Text('Headline, ad copy and link'), onTap: () {
                      Navigator.pop(s);
                      _edit();
                    }),
                    if (status != 'ended')
                      ListTile(leading: const Tile(Icons.pause_rounded, EvColors.gold), title: Text(status == 'paused' ? 'Resume campaign' : 'Pause campaign'), onTap: () {
                        Navigator.pop(s);
                        _run('ads/pause', {'paused': status == 'paused' ? 0 : 1}, status == 'paused' ? 'Campaign resumed.' : 'Campaign paused.');
                      }),
                    ListTile(leading: const Tile(Icons.delete_outline_rounded, EvColors.red), title: const Text('Delete campaign', style: TextStyle(color: EvColors.red)), subtitle: const Text('Unused days are refunded to your Wallet'), onTap: () {
                      Navigator.pop(s);
                      _delete();
                    }),
                  ]),
                ),
              )),
        ]),
      ),
    );
  }
}

/// Reels in the feed: a row of covers; tapping opens a full-screen player.
class ReelsSection extends StatefulWidget {
  const ReelsSection({super.key});
  @override
  State<ReelsSection> createState() => _ReelsSectionState();
}

class _ReelsSectionState extends State<ReelsSection> {
  /// Reels already shown in this app session, so the next "Reels for you"
  /// row asks the server for different ones (old and new, at random).
  static final Set<int> _shown = {};
  List<Map> _reels = [];
  @override
  void initState() {
    super.initState();
    final exclude = _shown.length > 200 ? _shown.skip(_shown.length - 200) : _shown;
    ApiClient.instance.post('reelsnewsfeed/feed', {'limit': 20, if (exclude.isNotEmpty) 'exclude': exclude.join(',')}).then((p) {
      final m = mapOf(p);
      final list = listOf(m['feed'] ?? m['list'] ?? p).where((r) => str(r, 'video_src').isNotEmpty || asBool(r['is_ad'])).toList();
      // Ad videos and covers come from the website's ad page, which only
      // serves logged-in members. The app signs in with a token, so it adds
      // that token to the link - the same files the website shows.
      final tok = ApiClient.instance.token;
      String withToken(String u) => (tok == null || tok.isEmpty || !u.contains('reelsnewsfeed-media') || u.contains('t=')) ? u : '$u${u.contains('?') ? '&' : '?'}t=${Uri.encodeQueryComponent(tok)}';
      for (final r in list) {
        if (asBool(r['is_ad'])) {
          r['video_src'] = withToken(str(r, 'video_src'));
          r['cover_src'] = withToken(str(r, 'cover_src'));
        }
        if (!asBool(r['is_ad']) && asInt(r['guid']) > 0) _shown.add(asInt(r['guid']));
        // Sponsored reels are downloaded to the phone now, so they open
        // instantly from the saved copy.
        if (asBool(r['is_ad']) && str(r, 'video_src').isNotEmpty) prefetchMedia(absUrl(str(r, 'video_src')));
      }
      if (mounted) setState(() => _reels = list);
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    if (_reels.isEmpty) return const SizedBox.shrink();
    return _Section(
      'Reels for you',
      SizedBox(
        height: 300,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: _reels.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, i) {
            final r = _reels[i];
            return GestureDetector(
              // When the player closes, redraw the tiles with the counts it learned.
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReelPlayerScreen(reels: _reels, start: i))).then((_) {
                if (mounted) setState(() {});
              }),
              child: SizedBox(
                width: 168,
                child: Stack(fit: StackFit.expand, children: [
                  _img(absUrl(str(r, 'cover_src')), 168, 300),
                  const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 40)),
                  Positioned(left: 8, bottom: 8, right: 8, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (asBool(r['is_ad'])) Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1), decoration: BoxDecoration(color: EvColors.gold, borderRadius: BorderRadius.circular(6)), child: const Text('Sponsored', style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w700))),
                    Text(str(r, 'owner_fullname', str(r, 'sponsor')), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 11.5, fontWeight: FontWeight.w700, shadows: [Shadow(blurRadius: 4)])),
                    Row(children: [const Icon(Icons.visibility_outlined, color: Colors.white, size: 12), const SizedBox(width: 3), Text('${asInt(r['views_count'])}', style: const TextStyle(color: Colors.white, fontSize: 11, shadows: [Shadow(blurRadius: 4)]))]),
                  ])),
                ]),
              ),
            );
          },
        ),
      ),
    );
  }
}

class ReelPlayerScreen extends StatefulWidget {
  final List<Map> reels;
  final int start;
  const ReelPlayerScreen({super.key, required this.reels, this.start = 0});
  @override
  State<ReelPlayerScreen> createState() => _ReelPlayerScreenState();
}

class _ReelPlayerScreenState extends State<ReelPlayerScreen> {
  late final PageController _pages = PageController(initialPage: widget.start);

  /// Reels whose view was already sent while this player is open, so
  /// scrolling back to one doesn't send it again (same as the website).
  final Set<int> _viewSent = {};
  @override
  void dispose() {
    _pages.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        extendBodyBehindAppBar: true,
        appBar: AppBar(backgroundColor: Colors.transparent, foregroundColor: Colors.white, elevation: 0),
        body: PageView.builder(
          controller: _pages,
          scrollDirection: Axis.vertical,
          itemCount: widget.reels.length,
          onPageChanged: (i) {
            // Save the next reel to the phone - in the background, after
            // the one on screen has loaded (see holdDownloads).
            for (final r in widget.reels.skip(i + 1).take(1)) {
              final u = absUrl(str(r, 'video_src'));
              if (u.isNotEmpty) prefetchFirst(u);
            }
          },
          itemBuilder: (_, i) => _Reel(reel: widget.reels[i], viewSent: _viewSent),
        ),
      );
}

class _Reel extends StatefulWidget {
  final Map reel;
  final Set<int> viewSent;
  const _Reel({required this.reel, required this.viewSent});
  @override
  State<_Reel> createState() => _ReelState();
}

class _ReelState extends State<_Reel> {
  VideoPlayerController? _c;
  late int _views = asInt(widget.reel['views_count']);
  late int _likes = asInt(widget.reel['likes_count']);
  late int _comments = asInt(widget.reel['comments_count']);
  late int _shares = asInt(widget.reel['shares_count']);
  late bool _liked = asBool(widget.reel['is_liked']);
  bool _counted = false, _saved = false, _failed = false;

  int get _id => asInt(widget.reel['guid']);
  bool get _isAd => asBool(widget.reel['is_ad']);

  @override
  void initState() {
    super.initState();
    _open();
  }

  /// Plays from the phone when the reel was downloaded before (works offline);
  /// otherwise streams it and saves it for next time.
  /// Sponsored reels always play from the saved copy on the phone
  /// (downloaded when the reels row loaded, or now).
  /// Whether this reel is holding background downloads (see _open).
  bool _holding = false;
  void _hold(bool on) {
    if (on == _holding) return;
    _holding = on;
    on ? holdDownloads() : releaseDownloads();
  }

  Future<void> _open() async {
    if (str(widget.reel, 'video_src').isEmpty) return;
    final url = absUrl(str(widget.reel, 'video_src'));
    if (mounted && _failed) setState(() => _failed = false);
    try {
      var cached = await evCache.getFileFromCache(url);
      if (cached == null && _isAd) {
        cached = await evCache.downloadFile(url);
      }
      if (!mounted) return;
      // Streamed from the server: background downloads wait until it plays,
      // so this reel gets the whole connection and starts quickly.
      if (cached == null) _hold(true);
      final c = cached != null ? VideoPlayerController.file(cached.file) : VideoPlayerController.networkUrl(Uri.parse(url));
      _c = c
        ..setLooping(true)
        ..addListener(_watch);
      await c.initialize();
      if (!mounted) return;
      setState(() {});
      c.play();
      if (_holding) {
        // A few seconds of playing, then let the line move again and keep
        // this reel on the phone for next time (and offline).
        Future.delayed(const Duration(seconds: 4), () {
          _hold(false);
          prefetchMedia(url);
        });
      }
    } catch (_) {
      _hold(false);
      // Before, a video that couldn't load left the spinner turning forever.
      final old = _c;
      _c = null;
      old?.removeListener(_watch);
      old?.dispose();
      if (_isAd) evCache.removeFile(url).then((_) {}, onError: (_) {});
      if (mounted) setState(() => _failed = true);
    }
  }

  Duration _lastPos = Duration.zero;

  /// A view is sent once the reel has played for 5 seconds - or, for a
  /// reel shorter than that, once most of it has played or it loops.
  void _watch() {
    final c = _c;
    if (_counted || c == null || !c.value.isInitialized || _isAd || _id == 0) return;
    final pos = c.value.position;
    final len = c.value.duration;
    final need = (len > Duration.zero && len < const Duration(seconds: 6)) ? len * 0.8 : const Duration(seconds: 5);
    final looped = pos < _lastPos && _lastPos > const Duration(milliseconds: 500);
    _lastPos = pos;
    if (pos >= need || looped) {
      _counted = true;
      _sendView();
    }
  }

  /// The server decides whether this view counts (Admin > ReelsNewsfeed
  /// view rules: once per person per window, creator's own views not
  /// counted) and sends back the reel's real total, which is what we show.
  /// Before, the app added 1 on screen whatever the server did, then the
  /// real (lower) number came back when the feed reloaded - so views
  /// looked like they reset after closing a reel.
  Future<void> _sendView() async {
    if (widget.viewSent.contains(_id)) return;
    widget.viewSent.add(_id);
    final secs = _c?.value.duration.inMilliseconds ?? 0;
    try {
      final r = mapOf(await ApiClient.instance.post('reelsnewsfeed/view', {'guid': _id, if (secs > 0) 'duration': (secs / 1000).toStringAsFixed(2)}));
      if (r['views_count'] != null) {
        final n = asInt(r['views_count']);
        widget.reel['views_count'] = n;
        if (mounted) setState(() => _views = n);
      }
    } catch (_) {
      // Not sent (offline): it will be tried again the next time the reel is opened.
      widget.viewSent.remove(_id);
    }
  }

  Future<void> _like() async {
    final want = !_liked;
    setState(() {
      _liked = want;
      _likes += want ? 1 : -1;
    });
    try {
      final r = mapOf(await ApiClient.instance.post('reelsnewsfeed/like', {'guid': _id, 'like': want ? 1 : 0}));
      if (mounted) {
        setState(() {
          _liked = asBool(r['is_liked']);
          _likes = asInt(r['likes_count']);
        });
        widget.reel['is_liked'] = _liked;
        widget.reel['likes_count'] = _likes;
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _liked = !want;
          _likes += want ? -1 : 1;
        });
        showMessage(context, '$e');
      }
    }
  }

  Future<void> _save() async {
    try {
      await ApiClient.instance.post(_saved ? 'bookmarks/remove' : 'bookmarks/save', {'guid': _id});
      if (mounted) {
        setState(() => _saved = !_saved);
        showMessage(context, _saved ? 'Saved.' : 'Removed from Saved.');
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  Future<void> _share() async {
    await Share.share('${str(widget.reel, 'title', 'Watch this reel on Evinie')}\n${absUrl('video/view/$_id')}');
    if (mounted) setState(() => _shares++);
  }

  Future<void> _openComments() async {
    _c?.pause();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (_) => _ReelComments(guid: _id, onCount: (n) => setState(() => _comments = n)),
    );
    _c?.play();
  }

  @override
  void dispose() {
    _hold(false);
    _c?.removeListener(_watch);
    _c?.dispose();
    super.dispose();
  }

  Widget _action(IconData icon, String label, VoidCallback onTap, {Color color = Colors.white}) => GestureDetector(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 18),
          child: Column(children: [
            Icon(icon, color: color, size: 31, shadows: const [Shadow(blurRadius: 6)]),
            const SizedBox(height: 3),
            Text(label, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600, shadows: [Shadow(blurRadius: 6)])),
          ]),
        ),
      );

  String _n(int v) => v >= 1000000 ? '${(v / 1000000).toStringAsFixed(1)}M' : v >= 1000 ? '${(v / 1000).toStringAsFixed(1)}K' : '$v';

  @override
  Widget build(BuildContext context) {
    final c = _c;
    final r = widget.reel;
    final link = str(r, 'click_url');
    final bottom = MediaQuery.of(context).padding.bottom;
    return GestureDetector(
      onTap: () {
        if (c == null || !c.value.isInitialized) return;
        setState(() => c.value.isPlaying ? c.pause() : c.play());
      },
      onDoubleTap: _isAd || _liked ? null : _like,
      child: Stack(fit: StackFit.expand, children: [
        if (str(r, 'video_src').isEmpty)
          Center(child: CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(str(r, 'cover_src', str(r, 'image'))), fit: BoxFit.contain, errorWidget: (_, __, ___) => const SizedBox.shrink()))
        else if (c != null && c.value.isInitialized)
          Center(child: AspectRatio(aspectRatio: c.value.aspectRatio, child: VideoPlayer(c)))
        else if (_failed)
          Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.wifi_off_rounded, color: Colors.white70, size: 40),
              const SizedBox(height: 8),
              const Text("Couldn't play this video", style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
              TextButton(onPressed: _open, child: const Text('Try again', style: TextStyle(color: EvColors.ember1, fontWeight: FontWeight.w700))),
            ]),
          )
        else
          const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4)),
        if (!_isAd)
          Positioned(
            top: MediaQuery.of(context).padding.top + 14,
            right: 16,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
              child: Row(children: [const Icon(Icons.visibility_rounded, color: Colors.white, size: 22), const SizedBox(width: 6), Text('${_n(_views)} views', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800))]),
            ),
          ),
        if (!_isAd)
          Positioned(
            right: 10,
            bottom: 40 + bottom,
            child: Column(children: [
              _action(_liked ? Icons.favorite_rounded : Icons.favorite_border_rounded, _n(_likes), _like, color: _liked ? EvColors.red : Colors.white),
              _action(Icons.chat_bubble_outline_rounded, _n(_comments), _openComments),
              _action(_saved ? Icons.bookmark_rounded : Icons.bookmark_border_rounded, _saved ? 'Saved' : 'Save', _save, color: _saved ? EvColors.gold : Colors.white),
              _action(Icons.share_rounded, _shares > 0 ? _n(_shares) : 'Share', _share),
            ]),
          ),
        Positioned(
          left: 16,
          right: 76,
          bottom: 30 + bottom,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // The poster's picture and name: tap to open their profile.
            if (!_isAd && asInt(r['owner_guid']) > 0)
              Builder(builder: (_) {
                final owner = EvUser.fromJson({'guid': asInt(r['owner_guid']), 'fullname': str(r, 'owner_fullname'), 'username': str(r, 'owner_username'), 'icon': str(r, 'owner_icon')});
                return GestureDetector(
                  onTap: () {
                    _c?.pause();
                    openProfile(context, owner);
                  },
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      padding: const EdgeInsets.all(1.5),
                      decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
                      child: Avatar(owner, size: 38),
                    ),
                    const SizedBox(width: 10),
                    Flexible(child: Text(owner.fullname, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15, shadows: [Shadow(blurRadius: 6)]))),
                  ]),
                );
              })
            else
              Text(str(r, 'owner_fullname', str(r, 'sponsor')), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15, shadows: [Shadow(blurRadius: 6)])),
            if (str(r, 'title').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(cleanText(str(r, 'title')), maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, shadows: [Shadow(blurRadius: 6)]))),
            if (_isAd && link.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: EmberButton('Learn more', onPressed: () => openAdLink(asInt(r['ad_guid']) > 0 ? asInt(r['ad_guid']) : asInt(r['guid']), 'reel', link))),
          ]),
        ),
        if (c != null && c.value.isInitialized && !c.value.isPlaying) const Center(child: Icon(Icons.play_arrow_rounded, color: Colors.white70, size: 72)),
      ]),
    );
  }
}

/// Comments on a reel: read and add, in a bottom sheet.
class _ReelComments extends StatefulWidget {
  final int guid;
  final void Function(int count) onCount;
  const _ReelComments({required this.guid, required this.onCount});
  @override
  State<_ReelComments> createState() => _ReelCommentsState();
}

class _ReelCommentsState extends State<_ReelComments> {
  List<Map>? _list;
  final _text = TextEditingController();
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = mapOf(await ApiClient.instance.post('reelsnewsfeed/comments', {'guid': widget.guid}));
      final l = listOf(r['list'] ?? r['comments']);
      if (mounted) setState(() => _list = l);
      widget.onCount(r['count'] != null ? asInt(r['count']) : l.length);
    } catch (_) {
      if (mounted) setState(() => _list = []);
    }
  }

  Future<void> _send() async {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    setState(() => _sending = true);
    try {
      await ApiClient.instance.post('reelsnewsfeed/comment', {'guid': widget.guid, 'comment': t});
      _text.clear();
      await _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.6,
          child: Column(children: [
            const Padding(padding: EdgeInsets.all(14), child: Text('Comments', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
            Expanded(
              child: _list == null
                  ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
                  : _list!.isEmpty
                      ? const Center(child: Text('No comments yet. Be the first.', style: TextStyle(color: EvColors.muted)))
                      : ListView(padding: const EdgeInsets.symmetric(horizontal: 14), children: [
                          for (final m in _list!)
                            Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Avatar(EvUser.fromJson(mapOf(m['user']).isNotEmpty ? mapOf(m['user']) : m), size: 32),
                                const SizedBox(width: 8),
                                Flexible(
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                                    decoration: BoxDecoration(color: EvColors.sand, borderRadius: BorderRadius.circular(14)),
                                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                      Text(str(mapOf(m['user']), 'fullname', str(m, 'fullname')), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                                      Text(cleanText(str(m, 'value', str(m, 'comment'))), style: const TextStyle(fontSize: 13, height: 1.35)),
                                    ]),
                                  ),
                                ),
                              ]),
                            ),
                        ]),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 6, 8),
                child: Row(children: [
                  Expanded(child: TextField(controller: _text, textInputAction: TextInputAction.send, onSubmitted: (_) => _send(), decoration: const InputDecoration(hintText: 'Add a comment…'))),
                  IconButton(onPressed: _sending ? null : _send, icon: const Icon(Icons.send_rounded, color: EvColors.ember2)),
                ]),
              ),
            ),
          ]),
        ),
      );
}


/// Menu > Ads > Create an ad: paid from the Wallet (price per day set by the admin).
class CreateAdScreen extends StatefulWidget {
  const CreateAdScreen({super.key});
  @override
  State<CreateAdScreen> createState() => _CreateAdScreenState();
}

class _CreateAdScreenState extends State<CreateAdScreen> {
  final _title = TextEditingController(), _desc = TextEditingController(), _link = TextEditingController(text: 'https://');
  File? _image;
  int _days = 7;
  String _gender = 'all';
  Map? _price;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    ApiClient.instance.post('ads/pricing').then((p) {
      if (mounted) setState(() => _price = mapOf(p));
    }).catchError((e) {
      if (mounted) setState(() => _price = {'available': false, 'error': '$e'});
    });
  }

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    _link.dispose();
    super.dispose();
  }

  Future<void> _pay(int total) async {
    if (_image == null) return showMessage(context, 'Add a picture for your ad.');
    if (_title.text.trim().isEmpty || _desc.text.trim().isEmpty) return showMessage(context, 'Add a title and a description.');
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: const Text('Pay from Wallet?'), content: Text('${naira(total.toDouble())} will be taken from your Wallet for $_days days of advertising.'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Pay'))]));
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await ApiClient.instance.upload('ads/create', {'title': _title.text.trim(), 'description': _desc.text.trim(), 'link': _link.text.trim(), 'days': _days, 'gender': _gender}, 'ossn_ads', _image!);
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (d) => AlertDialog(icon: const Icon(Icons.check_circle_rounded, color: EvColors.green, size: 46), title: const Text('Your ad is live'), content: Text('It runs on the newsfeed for $_days days. ${naira(total.toDouble())} was paid from your Wallet.', textAlign: TextAlign.center), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('OK'))]));
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = _price;
    if (p == null) return Scaffold(appBar: AppBar(title: const Text('Create an ad')), body: const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    if (!asBool(p['available'])) {
      return Scaffold(appBar: AppBar(title: const Text('Create an ad')), body: StateMessage(icon: Icons.campaign_outlined, title: 'Advertising opens soon', body: str(p, 'reason').isNotEmpty ? str(p, 'reason') : (p['error'] != null ? '${p['error']}' : 'Members will be able to create ads here once pricing is set.')));
    }
    final perDay = asInt(p['price_per_day']);
    final total = perDay * _days;
    final balance = asDouble(p['balance']);
    final enough = balance >= total;
    return Scaffold(
      appBar: AppBar(title: const Text('Create an ad')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        GestureDetector(
          onTap: () async {
            final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
            if (x != null) setState(() => _image = File(x.path));
          },
          child: Container(
            height: 180,
            decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(18)),
            clipBehavior: Clip.antiAlias,
            child: _image != null ? Image.file(_image!, fit: BoxFit.cover, width: double.infinity) : const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.add_photo_alternate_outlined, color: EvColors.ember2, size: 32), Text('Add ad picture', style: TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w600))])),
          ),
        ),
        const SizedBox(height: 12),
        TextField(controller: _title, maxLength: 80, decoration: const InputDecoration(hintText: 'Headline, e.g. 20% off this week')),
        TextField(controller: _desc, maxLines: 3, maxLength: 300, decoration: const InputDecoration(hintText: 'Describe your offer')),
        TextField(controller: _link, keyboardType: TextInputType.url, decoration: const InputDecoration(hintText: 'https://your-website.com', prefixIcon: Icon(Icons.link_rounded))),
        const SizedBox(height: 14),
        const Text('Audience', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'all', label: Text('Everyone')), ButtonSegment(value: 'male', label: Text('Men')), ButtonSegment(value: 'female', label: Text('Women'))], selected: {_gender}, onSelectionChanged: (v) => setState(() => _gender = v.first)),
        const SizedBox(height: 14),
        Row(children: [
          const Expanded(child: Text('Days', style: TextStyle(fontWeight: FontWeight.w700))),
          IconButton(onPressed: _days > 1 ? () => setState(() => _days--) : null, icon: const Icon(Icons.remove_circle_outline)),
          Text('$_days', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          IconButton(onPressed: _days < asInt(p['max_days']) ? () => setState(() => _days++) : null, icon: const Icon(Icons.add_circle_outline)),
        ]),
        const SizedBox(height: 8),
        EvCard(
          child: Column(children: [
            Row(children: [const Expanded(child: Text('Price per day')), Text(naira(perDay.toDouble()))]),
            const SizedBox(height: 6),
            Row(children: [Expanded(child: Text('Total for $_days days', style: const TextStyle(fontWeight: FontWeight.w700))), Text(naira(total.toDouble()), style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 17))]),
            const SizedBox(height: 6),
            Row(children: [const Expanded(child: Text('Wallet balance', style: TextStyle(color: EvColors.muted))), Text(naira(balance), style: TextStyle(color: enough ? EvColors.green : EvColors.red, fontWeight: FontWeight.w600))]),
          ]),
        ),
        const SizedBox(height: 16),
        EmberButton(enough ? 'Pay ${naira(total.toDouble())} from Wallet' : 'Top up your Wallet first', loading: _busy, onPressed: enough ? () => _pay(total) : null),
        const SizedBox(height: 8),
        const Text('Your ad shows on the newsfeed until the end of the last day. If it cannot be created, your Wallet is refunded automatically.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontSize: 12)),
      ]),
    );
  }
}


/// The section to show after post number [i] (0-based) in any timeline:
/// ads, reels, groups and pages, every few posts, like the home feed.
/// Same pattern as the home feed: an ad after every 4th post, other
/// sections in between.
Widget? feedExtra(int i) {
  final n = i + 1;
  if (n % 4 == 0) return AdSection(key: ValueKey('ad$n'), offset: n ~/ 4);
  if (n % 4 == 2 && n > 2) {
    return switch (((n - 6) ~/ 4) % 5) {
      0 => const BirthdaysSection(),
      1 => const ReelsSection(),
      2 => const GroupsSection(),
      3 => const PagesSection(),
      _ => const ProductsSection(),
    };
  }
  return null;
}


/// Discover: top earners this month and ways to earn, to motivate members.
class EarnHighlights extends StatefulWidget {
  const EarnHighlights({super.key});
  @override
  State<EarnHighlights> createState() => _EarnHighlightsState();
}

class _EarnHighlightsState extends State<EarnHighlights> {
  List<Map> _top = [];
  @override
  void initState() {
    super.initState();
    ApiClient.instance.post('topearners/list', {'limit': 10, 'period': 'month'}).then((p) {
      final m = mapOf(p);
      if (mounted) setState(() => _top = listOf(m['list'] ?? m['users'] ?? p));
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (_top.isNotEmpty)
          _Section(
            'Top earners this month 🏆',
            SizedBox(
              height: 150,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: _top.length,
                separatorBuilder: (_, __) => const SizedBox(width: 10),
                itemBuilder: (_, i) {
                  final m = _top[i];
                  final u = EvUser.fromJson({...m, if (m['user'] is Map) ...m['user'] as Map});
                  return GestureDetector(
                    onTap: () => openProfile(context, u),
                    child: Container(
                      width: 116,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(gradient: i < 3 ? const LinearGradient(colors: [Color(0xFFFFF4D6), Color(0xFFFFE2A8)]) : null, color: i < 3 ? null : EvColors.sand, borderRadius: BorderRadius.circular(16)),
                      child: Column(children: [
                        Text(i == 0 ? '🥇' : i == 1 ? '🥈' : i == 2 ? '🥉' : '#${i + 1}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Avatar(u, size: 42),
                        const SizedBox(height: 4),
                        Text(u.fullname, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
                        Text(naira(asDouble(m['total'] ?? m['amount'] ?? m['earned'])), style: const TextStyle(color: EvColors.green, fontWeight: FontWeight.w700, fontSize: 12)),
                      ]),
                    ),
                  );
                },
              ),
            ),
          ),
        _Section(
          'Earn on Evinie',
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(children: [
              for (final x in [
                (Icons.workspace_premium_rounded, EvColors.ember2, 'Become an EviEarner', 'Sell, earn from your activity and cash out', () => push(context, const MembershipScreen())),
                (Icons.card_giftcard_rounded, EvColors.green, 'Refer & earn', 'Invite friends and earn points', () => push(context, const ReferralScreen())),
                (Icons.auto_graph_rounded, const Color(0xFF7C4DFF), 'Grow as a creator', 'Earn from the monthly creator pool', () => push(context, const CreatorsScreen())),
              ])
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    onTap: x.$5,
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: x.$2.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14)),
                      child: Row(children: [Tile(x.$1, x.$2, size: 36), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(x.$3, style: const TextStyle(fontWeight: FontWeight.w700)), Text(x.$4, style: const TextStyle(color: EvColors.muted, fontSize: 12))])), const Icon(Icons.chevron_right_rounded, color: EvColors.muted)]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ]);
}


/// Marketplace products in the feed: a swipeable row of the newest 10.
class ProductsSection extends StatefulWidget {
  const ProductsSection({super.key});
  @override
  State<ProductsSection> createState() => _ProductsSectionState();
}

class _ProductsSectionState extends State<ProductsSection> {
  List<Product> _items = [];
  @override
  void initState() {
    super.initState();
    ApiClient.instance.post('marketplace/list', {'sort_by': 'latest', 'offset': 1}).then((p) {
      final m = mapOf(p);
      final l = listOf(m['list'] ?? m['products'] ?? p).map(Product.fromJson).where((x) => x.guid > 0 && !x.sold).take(10).toList();
      if (mounted) setState(() => _items = l);
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    if (_items.isEmpty) return const SizedBox.shrink();
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(vertical: 14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 8, 10),
          child: Row(children: [
            const Expanded(child: Text('From the Marketplace 🛍️', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
            TextButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MarketplaceScreen())), child: const Text('See all')),
          ]),
        ),
        SizedBox(
          height: 262,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: _items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) {
              final p = _items[i];
              return GestureDetector(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductScreen(product: p))),
                child: Container(
                  width: 160,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: EvColors.line)),
                  clipBehavior: Clip.antiAlias,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _img(absUrl(p.cover), 160, 170, r: 0),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 7, 8, 0),
                      child: Text(p.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12, height: 1.25)),
                    ),
                    Padding(padding: const EdgeInsets.fromLTRB(8, 2, 8, 0), child: Text(p.priceText, style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w800, fontSize: 13))),
                  ]),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}
