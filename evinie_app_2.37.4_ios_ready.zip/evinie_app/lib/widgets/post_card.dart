import '../state/media_cache.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import '../config.dart';
import 'post_extras.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../api/evinie_api.dart';
import '../models/models.dart';
import '../screens/create_screens.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import 'common.dart';

/// A post in the feed or on a profile. Likes update at once and roll
/// back if the server says no.
class PostCard extends StatefulWidget {
  final EvPost post;
  final VoidCallback? onOpen;
  final void Function(EvUser user)? onOpenUser;
  final VoidCallback? onChanged;
  final bool showComments;
  const PostCard(this.post, {super.key, this.onOpen, this.onOpenUser, this.onChanged, this.showComments = true});
  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> {
  bool _expanded = false;

  bool? _serverLiked;
  Timer? _likeTimer;

  /// The heart changes at once; the server is updated a moment later
  /// (quick repeated taps send one final update).
  void _toggleLike() {
    final p = widget.post;
    _serverLiked ??= p.liked;
    HapticFeedback.selectionClick();
    setState(() {
      p.likes += p.liked ? -1 : 1;
      p.liked = !p.liked;
    });
    _likeTimer?.cancel();
    _likeTimer = Timer(const Duration(milliseconds: 350), _syncLike);
  }

  Future<void> _syncLike() async {
    final p = widget.post;
    final want = p.liked;
    if (want == _serverLiked) return;
    final me = Scope.read(context).current;
    try {
      want ? await EvinieApi.instance.like(me.guid, p.guid) : await EvinieApi.instance.unlike(me.guid, p.guid);
      _serverLiked = want;
    } catch (e) {
      if (!mounted) return;
      setState(() {
        p.liked = _serverLiked!;
        p.likes += want ? -1 : 1;
      });
      showMessage(context, '$e');
    }
  }

  @override
  void dispose() {
    _likeTimer?.cancel();
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    final p = widget.post;
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.only(top: 14, bottom: 6),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            GestureDetector(onTap: () => widget.onOpenUser?.call(p.poster), child: Avatar(p.poster, size: 42)),
            const SizedBox(width: 10),
            Expanded(
              child: GestureDetector(
                onTap: () => widget.onOpenUser?.call(p.poster),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  NameLine(p.poster),
                  Text([timeAgo(p.time), if (p.location.isNotEmpty) p.location].join(' · '), style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
                ]),
              ),
            ),
            PostMenuButton(post: p, onChanged: widget.onChanged),
          ]),
        ),
        if (p.text.isNotEmpty && p.background.startsWith('pbg') && p.image.isEmpty)
          Container(
            margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
            constraints: const BoxConstraints(minHeight: 220),
            padding: const EdgeInsets.all(22),
            alignment: Alignment.center,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), image: DecorationImage(fit: BoxFit.cover, image: CachedNetworkImageProvider('${AppConfig.siteUrl}/components/OssnPostBackground/images/${p.background.replaceFirst('pbg', '')}.jpg', cacheManager: evCache))),
            child: Text(p.text, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700, height: 1.35, shadows: [Shadow(blurRadius: 6, color: Colors.black38)])),
          )
        else if (p.text.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              GestureDetector(
                onTap: widget.onOpen,
                child: MentionText(p.text, maxLines: _expanded ? null : 6, style: const TextStyle(fontSize: 14, height: 1.5, color: EvColors.ink)),
              ),
              if (!_expanded && (p.text.length > 280 || '\n'.allMatches(p.text).length > 5))
                GestureDetector(
                  onTap: () => setState(() => _expanded = true),
                  child: const Padding(padding: EdgeInsets.only(top: 4), child: Text('Read more', style: TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700))),
                ),
            ]),
          ),
        if (p.image.isNotEmpty)
          GestureDetector(
            onTap: widget.onOpen,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: GestureDetector(onTap: () => openImageViewer(context, p.image), child: AspectRatio(aspectRatio: 1, child: CachedNetworkImage(cacheManager: evCache, alignment: Alignment.topCenter, 
                  imageUrl: p.image,
                  fit: BoxFit.cover,
                  width: double.infinity,
                  placeholder: (_, __) => const AspectRatio(aspectRatio: 4 / 3, child: Skeleton(radius: 18)),
                  errorWidget: (_, __, ___) => const SizedBox.shrink(),
                ))),
              ),
            ),
          ),
        // Videos, polls, events, products and shared posts come before the
        // like / comment / share row, so the buttons always sit under them.
        if (p.sharedGuid > 0) SharedOriginal(p.sharedGuid),
        if (p.sharedGuid == 0 && p.itemGuid > 0) ItemEmbed(type: p.itemType, guid: p.itemGuid),
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
          child: Row(children: [
            _Action(icon: p.liked ? Icons.favorite_rounded : Icons.favorite_border_rounded, label: p.likes > 0 ? '${p.likes}' : 'Like', color: p.liked ? EvColors.red : EvColors.ink2, onTap: _toggleLike),
            _Action(icon: Icons.chat_bubble_outline_rounded, label: p.comments > 0 ? '${p.comments}' : 'Comment', onTap: widget.onOpen),
            _Action(icon: Icons.reply_rounded, label: 'Share', onTap: () => showShareSheet(context, p)),
          ]),
        ),
        if (widget.showComments) PostComments(post: p, onOpen: widget.onOpen, onTotal: (n) => setState(() => p.comments = n)),
      ]),
    );
  }
}

class _Action extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onTap;
  const _Action({required this.icon, required this.label, this.color = EvColors.ink2, this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Row(children: [Icon(icon, size: 20, color: color), const SizedBox(width: 6), Text(label, style: TextStyle(color: color, fontSize: 12.5, fontWeight: FontWeight.w500))]),
        ),
      );
}
