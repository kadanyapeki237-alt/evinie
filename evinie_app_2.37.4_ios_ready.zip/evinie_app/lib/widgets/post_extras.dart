import '../state/media_cache.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'feed_extras.dart';
import '../screens/market_screens.dart';
import '../screens/discover_screens.dart';
import '../models/community.dart';
import '../api/community_api.dart';
import '../api/money_api.dart';
import '../api/more_api.dart';
import '../screens/feed_screens.dart';
import '../screens/money_screens.dart' show StatusChip;
import 'package:http/http.dart' as http;
import 'dart:io';
import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../api/api_client.dart';
import '../api/evinie_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import 'common.dart';

/// The ⋯ menu on every post: Report, Copy link, Edit, Delete.
/// The server only lets the author (or an admin) edit or delete.
class PostMenuButton extends StatelessWidget {
  final EvPost post;
  final VoidCallback? onChanged;
  const PostMenuButton({super.key, required this.post, this.onChanged});

  Future<String?> _ask(BuildContext context, String title, String hint, {String initial = '', String action = 'Send'}) async {
    final c = TextEditingController(text: initial);
    final r = await showDialog<String>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(title),
        content: TextField(controller: c, autofocus: true, minLines: 2, maxLines: 6, decoration: InputDecoration(hintText: hint)),
        actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: Text(action))],
      ),
    );
    c.dispose();
    return r;
  }

  Future<void> _run(BuildContext context, Future<void> Function() f, String done) async {
    try {
      await f();
      if (context.mounted) showMessage(context, done);
      onChanged?.call();
    } catch (e) {
      if (context.mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) => PopupMenuButton<String>(
        icon: const Icon(Icons.more_horiz_rounded, color: EvColors.muted),
        onSelected: (v) async {
          final api = ApiClient.instance;
          switch (v) {
            case 'link':
              await Clipboard.setData(ClipboardData(text: '${AppConfig.siteUrl}/post/view/${post.guid}'));
              if (context.mounted) showMessage(context, 'Link copied.');
            case 'report':
              final reason = await _ask(context, 'Report post', 'Tell us what is wrong with this post');
              if (reason != null && reason.isNotEmpty && context.mounted) {
                await _run(context, () => api.post('report/file', {'guid': post.guid, 'type': 'post', 'reason': reason}), 'Thanks. Our team will review it.');
              }
            case 'edit':
              final text = await _ask(context, 'Edit post', 'Your post', initial: post.text, action: 'Save');
              if (text != null && text.isNotEmpty && context.mounted) {
                await _run(context, () => api.post('wall/edit', {'guid': post.guid, 'post': text}), 'Post updated.');
              }
            case 'delete':
              final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: const Text('Delete this post?'), content: const Text('This cannot be undone.'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete', style: TextStyle(color: EvColors.red)))]));
              if (ok == true && context.mounted) {
                final me = Scope.read(context).current.guid;
                await _run(context, () => api.post('wall_delete', {'post_guid': post.guid, 'guid': me}), 'Post deleted.');
              }
          }
        },
        itemBuilder: (_) => const [
          PopupMenuItem(value: 'report', child: ListTile(dense: true, leading: Icon(Icons.flag_outlined, color: EvColors.red), title: Text('Report post'))),
          PopupMenuItem(value: 'link', child: ListTile(dense: true, leading: Icon(Icons.link_rounded), title: Text('Copy link'))),
          PopupMenuItem(value: 'edit', child: ListTile(dense: true, leading: Icon(Icons.edit_outlined), title: Text('Edit post'))),
          PopupMenuItem(value: 'delete', child: ListTile(dense: true, leading: Icon(Icons.delete_outline_rounded, color: EvColors.red), title: Text('Delete post'))),
        ],
      );
}

/// Up to 6 latest comments under a post in the feed, plus a comment box.
class PostComments extends StatefulWidget {
  final EvPost post;
  final VoidCallback? onOpen;
  final void Function(int total)? onTotal;
  const PostComments({super.key, required this.post, this.onOpen, this.onTotal});
  @override
  State<PostComments> createState() => _PostCommentsState();
}

class _PostCommentsState extends State<PostComments> {
  List<EvComment> _list = [];
  List<Map> _raw = [];
  final _text = TextEditingController();
  final _focus = FocusNode();
  bool _sending = false, _emoji = false;

  /// Replies to comments (OssnCommentReplies): loaded per comment when
  /// opened. [_replyTo] is the comment (or reply) being answered.
  final Map<int, List<Map>> _replies = {};
  final Set<int> _openReplies = {};
  int? _replyTo, _replyRoot;
  String _replyName = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(PostComments old) {
    super.didUpdateWidget(old);
    // A list reused this section for a different post: start fresh.
    if (old.post.guid != widget.post.guid) {
      setState(() {
        _list = [];
        _raw = [];
      });
      _load();
    }
  }

  @override
  void dispose() {
    _mentionTimer?.cancel();
    _text.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _loadReplies(int commentId) async {
    try {
      final r = mapOf(await ApiClient.instance.post('comments/replies', {'id': commentId}));
      if (mounted) setState(() => _replies[commentId] = listOf(r['replies']));
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  /// Reply to a comment, or to a reply (it goes under the same comment,
  /// starting with @their-username, like the website).
  void _startReply(int target, int root, EvUser to) {
    final me = Scope.read(context).current.guid;
    setState(() {
      _replyTo = target;
      _replyRoot = root;
      _replyName = to.firstName;
    });
    if (target != root && to.guid != me && to.username.isNotEmpty && !_text.text.contains('@${to.username}')) {
      _text.text = '@${to.username} ${_text.text}';
      _text.selection = TextSelection.collapsed(offset: _text.text.length);
    }
    _focus.requestFocus();
  }

  void _cancelReply() => setState(() {
        _replyTo = null;
        _replyRoot = null;
        _replyName = '';
      });

  Future<void> _sendReply(String t) async {
    final target = _replyTo!, root = _replyRoot ?? target;
    setState(() => _sending = true);
    try {
      await ApiClient.instance.post('comments/reply_add', {'parent': target, 'comment': t});
      _text.clear();
      _cancelReply();
      _openReplies.add(root);
      await _loadReplies(root);
      for (final r in _raw) {
        if (asInt(r['id']) == root) r['reply_count'] = (_replies[root] ?? const []).length;
      }
    } catch (e) {
      if (mounted) showMessage(context, 'Your reply was not sent: $e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  /// The replies under one comment, plus "View N replies".
  Widget _repliesFor(EvComment c) {
    final count = asInt(_rowFor(c)['reply_count']);
    final list = _replies[c.id];
    final open = _openReplies.contains(c.id);
    if (count == 0 && (list == null || list.isEmpty)) return const SizedBox.shrink();
    const st = TextStyle(fontSize: 11, color: EvColors.muted, fontWeight: FontWeight.w600);
    if (!open) {
      return Padding(
        padding: const EdgeInsets.only(left: 44, bottom: 8),
        child: GestureDetector(
          onTap: () {
            setState(() => _openReplies.add(c.id));
            _loadReplies(c.id);
          },
          child: Text('— View ${count == 1 ? '1 reply' : '$count replies'}', style: st.copyWith(color: EvColors.ink2)),
        ),
      );
    }
    if (list == null) return const Padding(padding: EdgeInsets.only(left: 44, bottom: 8), child: SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: EvColors.ember2)));
    final me = Scope.read(context).current.guid;
    return Padding(
      padding: const EdgeInsets.only(left: 36),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final r in list) ...[
          Builder(builder: (context) {
            final u = EvUser.fromJson(mapOf(r['user']));
            final id = asInt(r['id']);
            final liked = asBool(r['is_liked_by_user']);
            final likes = asInt(r['total_likes']);
            final mine = asBool(r['is_mine']) || u.guid == me;
            Future<void> act(String m, Map<String, Object?> f) async {
              try {
                await ApiClient.instance.post(m, {'id': id, ...f});
                await _loadReplies(c.id);
              } catch (e) {
                if (mounted) showMessage(context, '$e');
              }
            }

            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Avatar(u, size: 24),
                const SizedBox(width: 6),
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(color: EvColors.sand, borderRadius: BorderRadius.circular(12)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(u.fullname, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                      if (str(r, 'comment').isNotEmpty) MentionText(cleanText(str(r, 'comment')), style: const TextStyle(fontSize: 13.5, height: 1.35, color: EvColors.ink)),
                      if (str(r, 'image').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 200, maxHeight: 200), child: CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(str(r, 'image')), fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox.shrink())))),
                    ]),
                  ),
                ),
              ]),
              Padding(
                padding: const EdgeInsets.only(left: 36, top: 2, bottom: 8),
                child: Wrap(spacing: 14, children: [
                  Text(timeAgo(asTime(r['time_created'])), style: st.copyWith(fontWeight: FontWeight.w400)),
                  GestureDetector(onTap: () => act('comments/like', {'like': liked ? 0 : 1}), child: Text(liked ? 'Liked${likes > 0 ? ' · $likes' : ''}' : 'Like${likes > 0 ? ' · $likes' : ''}', style: st.copyWith(color: liked ? EvColors.ember2 : EvColors.muted))),
                  GestureDetector(onTap: () => _startReply(id, c.id, u), child: const Text('Reply', style: st)),
                  if (mine)
                    GestureDetector(
                      onTap: () async {
                        final ctrl = TextEditingController(text: str(r, 'comment'));
                        final t = await showDialog<String>(context: context, builder: (d) => AlertDialog(title: const Text('Edit reply'), content: TextField(controller: ctrl, autofocus: true, maxLines: 4), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, ctrl.text.trim()), child: const Text('Save'))]));
                        ctrl.dispose();
                        if (t != null && t.isNotEmpty) await act('comments/reply_edit', {'comment': t});
                      },
                      child: const Text('Edit', style: st),
                    ),
                  if (asBool(r['can_delete']) || mine)
                    GestureDetector(
                      onTap: () async {
                        final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: const Text('Delete this reply?'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete', style: TextStyle(color: EvColors.red)))]));
                        if (ok == true) {
                          await act('comments/reply_delete', {});
                          for (final row in _raw) {
                            if (asInt(row['id']) == c.id) row['reply_count'] = (_replies[c.id] ?? const []).length;
                          }
                        }
                      },
                      child: const Text('Delete', style: st),
                    ),
                ]),
              ),
            ]);
          }),
        ],
        Padding(
          padding: const EdgeInsets.only(left: 8, bottom: 8),
          child: GestureDetector(onTap: () => setState(() => _openReplies.remove(c.id)), child: const Text('— Hide replies', style: st)),
        ),
      ]),
    );
  }

  Future<void> _load() async {
    final forGuid = widget.post.guid;
    try {
      final me = Scope.read(context).current.guid;
      final c = await EvinieApi.instance.comments(me, widget.post.guid);
      if (forGuid != widget.post.guid) return;
      final total = EvinieApi.instance.lastCommentTotal;
      final raw = listOf(mapOf(await ApiClient.instance.post('comments/all', {'guid': widget.post.guid, 'type': 'post', 'limit': 200}))['comments']);
      if (mounted) {
        setState(() {
          _list = c.length > 6 ? c.sublist(c.length - 6) : c;
          _raw = raw.length > 6 ? raw.sublist(raw.length - 6) : raw;
        });
      }
      if (total != widget.post.comments) widget.onTotal?.call(total);
    } catch (_) {}
  }

  /// GIF from GIPHY: pick, download, then send as the comment's picture.
  Future<void> _gif() async {
    final url = await showModalBottomSheet<String>(context: context, isScrollControlled: true, backgroundColor: Colors.white, builder: (_) => const _GifPicker());
    if (url == null || !mounted) return;
    setState(() => _sending = true);
    try {
      final res = await http.get(Uri.parse(url));
      final file = File('${Directory.systemTemp.path}/gif_${DateTime.now().millisecondsSinceEpoch}.gif');
      await file.writeAsBytes(res.bodyBytes);
      final me = Scope.read(context).current.guid;
      final text = _text.text.trim();
      await ApiClient.instance.upload('comment_add', {'subject_guid': widget.post.guid, 'comment': text.isEmpty ? '🎞️' : text, 'type': 'post', 'uguid': me}, 'image_file', file);
      _text.clear();
      await _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

Map _rowFor(EvComment c) => _raw.firstWhere((r) => asInt(r['id']) == c.id, orElse: () => const {});

  /// Like · Edit · Delete under a comment (small).
  Widget _actions(EvComment c) {
    final r = _rowFor(c);
    final id = asInt(r['id']);
    if (id == 0) return const SizedBox(height: 6);
    final liked = asBool(r['is_liked_by_user']);
    final likes = asInt(r['total_likes']);
    final mine = asBool(r['is_mine']) || c.user.guid == Scope.read(context).current.guid;
    const st = TextStyle(fontSize: 11, color: EvColors.muted, fontWeight: FontWeight.w600);
    Future<void> act(String m, Map<String, Object?> f) async {
      try {
        await ApiClient.instance.post(m, {'id': id, ...f});
        await _load();
      } catch (e) {
        if (mounted) showMessage(context, '$e');
      }
    }

    return Padding(
      padding: const EdgeInsets.only(left: 44, bottom: 8),
      child: Row(children: [
        GestureDetector(onTap: () => act('comments/like', {'like': liked ? 0 : 1}), child: Text(liked ? 'Liked${likes > 0 ? ' · $likes' : ''}' : 'Like${likes > 0 ? ' · $likes' : ''}', style: st.copyWith(color: liked ? EvColors.ember2 : EvColors.muted))),
        const SizedBox(width: 14),
        GestureDetector(onTap: () => _startReply(id, id, c.user), child: const Text('Reply', style: st)),
        if (mine) ...[
          const SizedBox(width: 14),
          GestureDetector(
            onTap: () async {
              final ctrl = TextEditingController(text: c.text);
              final t = await showDialog<String>(context: context, builder: (d) => AlertDialog(title: const Text('Edit comment'), content: TextField(controller: ctrl, autofocus: true, maxLines: 4), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, ctrl.text.trim()), child: const Text('Save'))]));
              ctrl.dispose();
              if (t != null && t.isNotEmpty) await act('comments/edit', {'comment': t});
            },
            child: const Text('Edit', style: st),
          ),
        ],
        const SizedBox(width: 14),
        GestureDetector(
          onTap: () async {
            final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: const Text('Delete this comment?'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete', style: TextStyle(color: EvColors.red)))]));
            if (ok == true) await act('comments/delete', {});
          },
          child: const Text('Delete', style: st),
        ),
      ]),
    );
  }

  Future<void> _send() async {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    if (_replyTo != null) return _sendReply(t);
    final me = Scope.read(context).current;
    final temp = EvComment(id: -DateTime.now().millisecondsSinceEpoch, text: t, time: DateTime.now(), user: me);
    // Show it at once; send in the background.
    setState(() {
      _list = [..._list, temp];
      _mentions = [];
    });
    _text.clear();
    widget.onTotal?.call(widget.post.comments + 1);
    try {
      await EvinieApi.instance.addComment(me.guid, widget.post.guid, t);
      _load();
    } catch (e) {
      if (!mounted) return;
      setState(() => _list = _list.where((c) => c.id != temp.id).toList());
      _text.text = t;
      widget.onTotal?.call(widget.post.comments);
      showMessage(context, 'Your comment was not sent: $e');
    }
  }

  List<EvUser> _mentions = [];
  Timer? _mentionTimer;

  void _onCommentType(String v) {
    final q = mentionQuery(v);
    _mentionTimer?.cancel();
    if (q == null) {
      if (_mentions.isNotEmpty) setState(() => _mentions = []);
      return;
    }
    final me = Scope.read(context).current.guid;
    // Friends at once, then other members after a short pause in typing.
    setState(() => _mentions = mentionLocal(me, q));
    _mentionTimer = Timer(const Duration(milliseconds: 250), () async {
      final found = await mentionMatches(me, q);
      // Ignore a late answer if the text has changed since.
      if (mounted && mentionQuery(_text.text) == q) setState(() => _mentions = found);
    });
  }

  void _pickMention(EvUser u) {
    final v = _text.text;
    final i = v.lastIndexOf('@');
    if (i < 0) return;
    _text.text = '${v.substring(0, i)}@${u.username} ';
    _text.selection = TextSelection.collapsed(offset: _text.text.length);
    setState(() => _mentions = []);
  }


  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (_list.length >= 6)
          GestureDetector(onTap: widget.onOpen, child: Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(widget.post.comments > 6 ? 'View all ${widget.post.comments} comments' : 'View all comments', style: const TextStyle(color: EvColors.muted, fontSize: 12, fontWeight: FontWeight.w600)))),
        for (final c in _list) ...[
          Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Avatar(c.user, size: 28),
              const SizedBox(width: 8),
              Flexible(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
                  decoration: BoxDecoration(color: EvColors.sand, borderRadius: BorderRadius.circular(14)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(c.user.fullname, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                    if (_gifIn(c.text).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 220, maxHeight: 220), child: CachedNetworkImage(cacheManager: evCache, imageUrl: _gifIn(c.text), fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox.shrink()))))
                    else if (!c.text.startsWith('🎞')) MentionText(cleanText(c.text), style: const TextStyle(fontSize: 14.5, height: 1.35, color: EvColors.ink)),
                    if (str(_rowFor(c), 'image').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 220, maxHeight: 220), child: CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(str(_rowFor(c), 'image')), fit: BoxFit.cover, errorWidget: (_, __, ___) => const SizedBox.shrink())))),
                  ]),
                ),
              ),
            ]),
          ),
          _actions(c),
          _repliesFor(c),
        ],
        if (_replyTo != null)
          Padding(
            padding: const EdgeInsets.only(left: 36, bottom: 4),
            child: Row(children: [
              Text('Replying to $_replyName', style: const TextStyle(fontSize: 12, color: EvColors.ink2, fontWeight: FontWeight.w600)),
              const SizedBox(width: 8),
              GestureDetector(onTap: _cancelReply, child: const Text('Cancel', style: TextStyle(fontSize: 12, color: EvColors.red))),
            ]),
          ),
        if (_mentions.isNotEmpty)
          Container(
            margin: const EdgeInsets.only(bottom: 6),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: EvColors.line)),
            child: Column(children: [for (final u in _mentions) ListTile(dense: true, leading: Avatar(u, size: 28), title: Text(u.fullname), subtitle: Text('@${u.username}'), onTap: () => _pickMention(u))]),
          ),
        Row(children: [
          Avatar(me, size: 28),
          const SizedBox(width: 8),
          Expanded(
            child: SizedBox(
              height: 36,
              child: TextField(
                controller: _text,
                focusNode: _focus,
                style: const TextStyle(fontSize: 12.5),
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                onChanged: _onCommentType,
                decoration: InputDecoration(hintText: _replyTo != null ? 'Write a reply…' : 'Write a comment…', contentPadding: const EdgeInsets.symmetric(horizontal: 14), suffixIcon: Row(mainAxisSize: MainAxisSize.min, children: [GestureDetector(onTap: _sending ? null : _gif, child: const Icon(Icons.gif_box_outlined, color: EvColors.blue, size: 21)), const SizedBox(width: 8), GestureDetector(onTap: () => setState(() => _emoji = !_emoji), child: Icon(_emoji ? Icons.keyboard_rounded : Icons.emoji_emotions_outlined, color: EvColors.gold, size: 20)), const SizedBox(width: 10)]), border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none), filled: true, fillColor: EvColors.sand),
              ),
            ),
          ),
          IconButton(onPressed: _sending ? null : _send, icon: const Icon(Icons.send_rounded, color: EvColors.ember2, size: 20)),
        ]),
        if (_emoji)
          Wrap(spacing: 2, children: [
            for (final e in const ['😀', '😂', '🤣', '😍', '🥰', '😘', '😎', '🤩', '🙏', '👍', '👏', '🔥', '🎉', '❤️', '💯', '😢', '😮', '😡', '🤝', '🎂', '🌹', '💪', '🙌', '😇'])
              GestureDetector(
                onTap: () {
                  final t = _text.text;
                  final sel = _text.selection;
                  final pos = sel.isValid ? sel.start : t.length;
                  _text.text = t.replaceRange(pos, sel.isValid ? sel.end : pos, e);
                  _text.selection = TextSelection.collapsed(offset: pos + e.length);
                },
                child: Padding(padding: const EdgeInsets.all(4), child: Text(e, style: const TextStyle(fontSize: 22))),
              ),
          ]),
      ]),
    );
  }
}


class _GifPicker extends StatefulWidget {
  const _GifPicker();
  @override
  State<_GifPicker> createState() => _GifPickerState();
}

class _GifPickerState extends State<_GifPicker> {
  List<Map> _gifs = [];
  bool _busy = true;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _search('');
  }

  Future<void> _search(String q) async {
    setState(() => _busy = true);
    final base = q.isEmpty ? 'https://api.giphy.com/v1/gifs/trending?' : 'https://api.giphy.com/v1/gifs/search?q=${Uri.encodeQueryComponent(q)}&';
    try {
      final r = await http.get(Uri.parse('${base}api_key=${AppConfig.giphyKey}&limit=30&rating=pg'));
      final data = (jsonDecode(r.body) as Map)['data'];
      if (mounted) setState(() => _gifs = data is List ? data.whereType<Map>().toList() : []);
    } catch (_) {
      if (mounted) setState(() => _gifs = []);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _u(Map g, String size) => ((g['images'] is Map ? (g['images'] as Map)[size] : null) is Map ? ((g['images'] as Map)[size] as Map)['url'] : '')?.toString() ?? '';

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SizedBox(
        height: MediaQuery.of(context).size.height * 0.7,
        child: Column(children: [
          Padding(
            padding: EdgeInsets.fromLTRB(12, 12, 12, 8 + MediaQuery.of(context).viewInsets.bottom * 0),
            child: TextField(
              decoration: const InputDecoration(hintText: 'Search GIFs', prefixIcon: Icon(Icons.search_rounded)),
              onChanged: (v) {
                _t?.cancel();
                _t = Timer(const Duration(milliseconds: 400), () => _search(v.trim()));
              },
            ),
          ),
          Expanded(
            child: _busy
                ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
                : GridView.count(crossAxisCount: 3, padding: const EdgeInsets.all(8), mainAxisSpacing: 6, crossAxisSpacing: 6, children: [
                    for (final g in _gifs)
                      GestureDetector(
                        onTap: () => Navigator.pop(context, _u(g, 'downsized').isNotEmpty ? _u(g, 'downsized') : _u(g, 'original')),
                        child: ClipRRect(borderRadius: BorderRadius.circular(8), child: CachedNetworkImage(cacheManager: evCache, imageUrl: _u(g, 'fixed_width_small'), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
                      ),
                  ]),
          ),
          const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('Powered by GIPHY', style: TextStyle(color: EvColors.muted, fontSize: 11))),
        ]),
      );
}


/// Text with tappable @mentions: tapping opens that person's profile.
class MentionText extends StatelessWidget {
  final String text;
  final TextStyle style;
  final int? maxLines;
  const MentionText(this.text, {super.key, required this.style, this.maxLines});

  Future<void> _open(BuildContext context, String username) async {
    try {
      final r = mapOf(await ApiClient.instance.post('search/all', {'q': username, 'type': 'users'}));
      final users = listOf(r['users']);
      final u = users.firstWhere((x) => str(x, 'username').toLowerCase() == username.toLowerCase(), orElse: () => users.isNotEmpty ? users.first : const {});
      if (u.isNotEmpty && context.mounted) openProfile(context, EvUser.fromJson(u));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final spans = <InlineSpan>[];
    var last = 0;
    for (final m in RegExp(r'@([A-Za-z0-9_.]{2,})').allMatches(text)) {
      if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start)));
      final name = m.group(1)!;
      spans.add(WidgetSpan(alignment: PlaceholderAlignment.baseline, baseline: TextBaseline.alphabetic, child: GestureDetector(onTap: () => _open(context, name), child: Text('@$name', style: style.copyWith(color: EvColors.blue, fontWeight: FontWeight.w600)))));
      last = m.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
    return Text.rich(TextSpan(style: style, children: spans), maxLines: maxLines, overflow: maxLines == null ? TextOverflow.visible : TextOverflow.ellipsis);
  }
}


/// Friend status with someone: Friends / Requested / Add friend.
class RelationChip extends StatefulWidget {
  final int guid;
  const RelationChip(this.guid, {super.key});
  @override
  State<RelationChip> createState() => _RelationChipState();
}

class _RelationChipState extends State<RelationChip> {
  String? _rel;
  @override
  void initState() {
    super.initState();
    ApiClient.instance.post('user/status', {'guids': '${widget.guid}'}).then((p) {
      final l = listOf(mapOf(p)['list']);
      if (mounted) setState(() => _rel = l.isEmpty ? 'none' : str(l.first, 'relation', 'none'));
    }).catchError((_) {
      if (mounted) setState(() => _rel = 'none');
    });
  }

  @override
  Widget build(BuildContext context) {
    switch (_rel) {
      case null:
      case 'self':
        return const SizedBox.shrink();
      case 'friend':
        return const StatusChip('Friends');
      case 'requested':
        return const StatusChip('Requested');
      default:
        return FilledButton(
          onPressed: () async {
            try {
              await ApiClient.instance.post('user_add_friend', {'user_a': Scope.read(context).current.guid, 'user_b': widget.guid});
              if (mounted) setState(() => _rel = 'requested');
            } catch (e) {
              if (mounted) showMessage(context, '$e');
            }
          },
          style: FilledButton.styleFrom(backgroundColor: EvColors.ember2, visualDensity: VisualDensity.compact),
          child: const Text('Add friend', style: TextStyle(fontSize: 12)),
        );
    }
  }
}

/// "Online" or "Active 5m ago" for a person (OnlineStatus rule: 5 minutes).
class OnlineLine extends StatelessWidget {
  final int guid;
  const OnlineLine(this.guid, {super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder(
        future: ApiClient.instance.post('user/status', {'guids': '$guid'}),
        builder: (_, s) {
          final l = listOf(mapOf(s.data)['list']);
          if (l.isEmpty) return const SizedBox.shrink();
          final on = asBool(l.first['online']);
          final last = asInt(l.first['last_activity']);
          return Row(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 8, height: 8, decoration: BoxDecoration(color: on ? EvColors.green : EvColors.muted, shape: BoxShape.circle)),
            const SizedBox(width: 5),
            Text(on ? 'Online' : (last > 0 ? 'Active ${timeAgo(DateTime.fromMillisecondsSinceEpoch(last * 1000))}' : 'Offline'), style: TextStyle(fontSize: 12, color: on ? EvColors.green : EvColors.muted, fontWeight: FontWeight.w600)),
          ]);
        },
      );
}


/// A GIF link inside a comment (GIPHY, Tenor or any .gif address).
String _gifIn(String t) {
  final m = RegExp(r'https?://\S+?(\.gif|giphy\.com/media/\S+|media\.tenor\.com/\S+)', caseSensitive: false).firstMatch(t);
  return m == null ? '' : m.group(0)!;
}

/// The original post inside a share.
class SharedOriginal extends StatelessWidget {
  final int guid;
  const SharedOriginal(this.guid, {super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder(
        future: ApiClient.instance.post('wall/get', {'guid': guid}),
        builder: (_, s) {
          if (s.hasError) return const Padding(padding: EdgeInsets.all(12), child: Text('The shared post is no longer available.', style: TextStyle(color: EvColors.muted)));
          if (!s.hasData) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2)));
          final o = EvPost.fromJson(mapOf(s.data));
          return GestureDetector(
            onTap: () => openPost(context, o),
            child: Container(
              margin: const EdgeInsets.fromLTRB(12, 10, 12, 0),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: EvColors.line)),
              clipBehavior: Clip.antiAlias,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Padding(padding: const EdgeInsets.fromLTRB(12, 10, 12, 6), child: Row(children: [Avatar(o.poster, size: 30), const SizedBox(width: 8), Expanded(child: NameLine(o.poster)), Text(timeAgo(o.time), style: const TextStyle(color: EvColors.muted, fontSize: 11))])),
                if (o.text.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(12, 0, 12, 8), child: MentionText(o.text, maxLines: 6, style: const TextStyle(fontSize: 14, height: 1.45, color: EvColors.ink))),
                if (o.image.isNotEmpty) AspectRatio(aspectRatio: 4 / 3, child: CachedNetworkImage(cacheManager: evCache, imageUrl: o.image, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
              ]),
            ),
          );
        },
      );
}


/// People to suggest after "@": your friends first (instant), then other
/// members from search.
///
/// Before, the first "@" downloaded your whole friends list page by page
/// (up to 50 requests) before anything appeared, and every key press in a
/// comment waited for a server search. Now friends load in the background
/// as soon as the feed opens (using the copy already saved on the phone at
/// once), friend matches show on the very first key press, and the server
/// search runs only after a short pause, remembering its answers.
List<EvUser>? _friendsCache;
Future<void>? _friendsLoading;
final Map<String, List<EvUser>> _mentionSearchCache = {};

/// Who "@" is being typed for, at the end of [beforeCursor] ('' for a bare
/// "@"), or null when the text doesn't end in a mention.
String? mentionQuery(String beforeCursor) => RegExp(r'(?:^|\s)@(\w*)$').firstMatch(beforeCursor)?.group(1);

/// Starts loading your friends in the background (safe to call often).
Future<void> warmMentions(int me) {
  if (_friendsCache != null || me <= 0) return Future.value();
  return _friendsLoading ??= () async {
    try {
      _friendsCache = await MoneyApi.instance.friends(me);
    } catch (_) {
      // Try again next time.
    } finally {
      _friendsLoading = null;
    }
  }();
}

/// Friends saved on the phone from earlier visits (no network).
List<EvUser> _savedFriends(int me) {
  final out = <EvUser>[];
  final seen = <int>{};
  for (var page = 1; page <= 20; page++) {
    final p = ApiClient.instance.peek('user_friends', {'guid': me, 'offset': page});
    final list = p is Map ? (p['list'] ?? p['friends']) : p;
    if (list is! List || list.isEmpty) break;
    var added = 0;
    for (final u in list.whereType<Map>().map(EvUser.fromJson)) {
      if (u.guid > 0 && seen.add(u.guid)) {
        out.add(u);
        added++;
      }
    }
    if (added == 0) break;
  }
  return out;
}

/// Instant suggestions from your friends only.
List<EvUser> mentionLocal(int me, String q) {
  warmMentions(me);
  final pool = _friendsCache ?? _savedFriends(me);
  final low = q.toLowerCase();
  return [
    for (final f in pool)
      if (low.isEmpty || f.username.toLowerCase().startsWith(low) || f.fullname.toLowerCase().split(' ').any((w) => w.startsWith(low))) f,
  ].take(6).toList();
}

/// Friends plus other members from search (needs the network).
Future<List<EvUser>> mentionMatches(int me, String q) async {
  final out = mentionLocal(me, q);
  if (out.length >= 4 || q.length < 2) return out;
  final low = q.toLowerCase();
  var found = _mentionSearchCache[low];
  if (found == null) {
    try {
      final r = mapOf(await ApiClient.instance.post('search/all', {'q': q, 'type': 'users'}));
      found = listOf(r['users']).map(EvUser.fromJson).where((u) => u.guid > 0).toList();
      if (_mentionSearchCache.length > 100) _mentionSearchCache.clear();
      _mentionSearchCache[low] = found;
    } catch (_) {
      found = const [];
    }
  }
  for (final u in found) {
    if (out.length >= 6) break;
    if (!out.any((x) => x.guid == u.guid)) out.add(u);
  }
  return out;
}


/// Full-screen picture with pinch-to-zoom.
void openImageViewer(BuildContext context, String url) => Navigator.of(context).push(MaterialPageRoute(
      fullscreenDialog: true,
      builder: (_) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
        body: Center(child: InteractiveViewer(minScale: 1, maxScale: 5, child: CachedNetworkImage(cacheManager: evCache, imageUrl: url, fit: BoxFit.contain, errorWidget: (_, __, ___) => const Icon(Icons.broken_image_outlined, color: Colors.white54, size: 60)))),
      ),
    ));


/// Poll, event, video and product posts: show the item inside the post.
class ItemEmbed extends StatelessWidget {
  final String type;
  final int guid;
  const ItemEmbed({super.key, required this.type, required this.guid});

  Widget _frame(BuildContext context, {required Widget child, VoidCallback? onTap}) => GestureDetector(
        onTap: onTap,
        child: Container(margin: const EdgeInsets.fromLTRB(12, 10, 12, 0), decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: EvColors.line), color: Colors.white), clipBehavior: Clip.antiAlias, child: child),
      );

  @override
  Widget build(BuildContext context) {
    final t = type.toLowerCase();
    Widget loading() => const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2)));
    if (t.contains('video')) {
      return FutureBuilder(
        future: ApiClient.instance.post('video/get', {'guid': guid}),
        builder: (_, s) {
          if (s.hasError) return const SizedBox.shrink();
          if (!s.hasData) return loading();
          final v = mapOf(s.data);
          return _frame(context, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReelPlayerScreen(reels: [{'guid': asInt(v['guid']) > 0 ? asInt(v['guid']) : guid, 'video_src': str(v, 'file:video'), 'title': str(v, 'title')}]))), child: AspectRatio(aspectRatio: 1, child: Stack(fit: StackFit.expand, children: [
            CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(str(v, 'file:cover')), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.ink)),
            const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 64)),
            if (str(v, 'title').isNotEmpty) Positioned(left: 12, right: 12, bottom: 10, child: Text(str(v, 'title'), maxLines: 2, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, shadows: [Shadow(blurRadius: 6)]))),
          ])));
        },
      );
    }
    if (t.contains('poll')) {
      return FutureBuilder<Poll>(
        future: CommunityApi.instance.poll(guid),
        builder: (_, s) {
          if (s.hasError) return const SizedBox.shrink();
          if (!s.hasData) return loading();
          final q = s.data!;
          return _frame(context, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PollScreen(poll: q))), child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [const Icon(Icons.bar_chart_rounded, color: EvColors.ember2), const SizedBox(width: 6), Expanded(child: Text(q.title, style: const TextStyle(fontWeight: FontWeight.w700)))]),
            const SizedBox(height: 8),
            for (final o in q.options.take(4)) Container(width: double.infinity, margin: const EdgeInsets.only(bottom: 6), padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), decoration: BoxDecoration(color: EvColors.sand, borderRadius: BorderRadius.circular(10)), child: Text(o.title)),
            if (q.options.length > 4) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text('+${q.options.length - 4} more', style: const TextStyle(color: EvColors.muted, fontSize: 12))),
            Text(q.closed ? 'Poll closed · see results' : 'Tap to vote', style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 12.5)),
          ])));
        },
      );
    }
    if (t.contains('event')) {
      return FutureBuilder<EventItem>(
        future: CommunityApi.instance.event(guid),
        builder: (_, s) {
          if (s.hasError) return const SizedBox.shrink();
          if (!s.hasData) return loading();
          final e = s.data!;
          return _frame(context, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => EventScreen(guid: e.guid, preview: e))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (e.image.isNotEmpty) AspectRatio(aspectRatio: 16 / 9, child: CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(e.image), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
            Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.title, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 3), Text([e.date, e.start, e.location].where((x) => x.isNotEmpty).join(' · '), style: const TextStyle(color: EvColors.muted, fontSize: 12))])),
          ]));
        },
      );
    }
    if (t.contains('market') || t.contains('product')) {
      return FutureBuilder<Product>(
        future: CommunityApi.instance.product(guid),
        builder: (_, s) {
          if (s.hasError) return const SizedBox.shrink();
          if (!s.hasData) return loading();
          final pr = s.data!;
          return _frame(context, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductScreen(product: pr))), child: Row(children: [
            SizedBox(width: 96, height: 96, child: CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(pr.cover), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(pr.title, maxLines: 2, style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 4), Text(pr.priceText, style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w800))])),
          ]));
        },
      );
    }
    return const SizedBox.shrink();
  }
}
