import '../state/media_cache.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../models/models.dart';
import '../theme/colors.dart';

String timeAgo(DateTime t) {
  final d = DateTime.now().difference(t);
  if (d.inSeconds < 60) return 'just now';
  if (d.inMinutes < 60) return '${d.inMinutes} min ago';
  if (d.inHours < 24) return '${d.inHours}h ago';
  if (d.inDays < 7) return '${d.inDays}d ago';
  const m = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return '${t.day} ${m[t.month - 1]}';
}

void showMessage(BuildContext context, String text) =>
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

/// Photo, or coloured initials while loading or when there is no photo.
class Avatar extends StatelessWidget {
  final EvUser? user;
  final double size;
  final bool ring;
  const Avatar(this.user, {super.key, this.size = 40, this.ring = false});

  @override
  Widget build(BuildContext context) {
    final name = user?.fullname ?? '';
    final initials = name.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).take(2).map((w) => w[0].toUpperCase()).join();
    const colours = [Color(0xFFE9886A), Color(0xFF7FA7E8), Color(0xFF8CC9A6), Color(0xFFE6B65C), Color(0xFFB79BE6), Color(0xFF6CC3C8)];
    final bg = colours[name.codeUnits.fold<int>(0, (a, b) => a + b) % colours.length];
    final fallback = Container(
      color: bg,
      alignment: Alignment.center,
      child: Text(initials, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: size * 0.36)),
    );
    final img = ClipOval(
      child: SizedBox(
        width: size,
        height: size,
        child: (user?.icon ?? '').isEmpty
            ? fallback
            : CachedNetworkImage(cacheManager: evCache, imageUrl: user!.icon, fit: BoxFit.cover, placeholder: (_, __) => fallback, errorWidget: (_, __, ___) => fallback),
      ),
    );
    if (!ring) return img;
    return Container(padding: const EdgeInsets.all(2.5), decoration: const BoxDecoration(shape: BoxShape.circle, gradient: EvColors.emberGradient), child: Container(padding: const EdgeInsets.all(2), decoration: const BoxDecoration(shape: BoxShape.circle, color: Colors.white), child: img));
  }
}

class NameLine extends StatelessWidget {
  final EvUser user;
  final double size;
  const NameLine(this.user, {super.key, this.size = 13.5});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        Flexible(child: Text(user.fullname, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, fontSize: size))),
        if (user.verified) const Padding(padding: EdgeInsets.only(left: 4), child: Icon(Icons.verified_rounded, color: EvColors.blue, size: 15)),
      ]);
}

/// The ember gradient button, with a built-in loading state.
class EmberButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final bool loading;
  final IconData? icon;
  const EmberButton(this.label, {super.key, this.onPressed, this.loading = false, this.icon});

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    return Opacity(
      opacity: enabled || loading ? 1 : 0.5,
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          gradient: EvColors.emberGradient,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: EvColors.ember2.withValues(alpha: 0.35), blurRadius: 18, offset: const Offset(0, 8))],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: enabled ? onPressed : null,
            child: Center(
              child: loading
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
                  : Row(mainAxisSize: MainAxisSize.min, children: [
                      if (icon != null) Padding(padding: const EdgeInsets.only(right: 8), child: Icon(icon, color: Colors.white, size: 19)),
                      Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                    ]),
            ),
          ),
        ),
      ),
    );
  }
}

class OutlineEmberButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  const OutlineEmberButton(this.label, {super.key, this.onPressed});
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 50,
        child: OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
            foregroundColor: EvColors.ember2,
            side: const BorderSide(color: EvColors.ember1, width: 1.5),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            textStyle: const TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w700, fontSize: 14.5),
          ),
          child: Text(label),
        ),
      );
}

class EvCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  const EvCard({super.key, required this.child, this.padding = const EdgeInsets.all(14)});
  @override
  Widget build(BuildContext context) => Container(
        padding: padding,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [BoxShadow(color: Color(0x0F1F1A17), blurRadius: 16, offset: Offset(0, 6))],
        ),
        child: child,
      );
}

/// Empty and error states: say what happened and what to do next.
class StateMessage extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final String? action;
  final VoidCallback? onAction;
  const StateMessage({super.key, required this.icon, required this.title, required this.body, this.action, this.onAction});
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(24)),
              child: Icon(icon, color: EvColors.ember2, size: 34),
            ),
            const SizedBox(height: 16),
            Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(body, textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted, fontSize: 13, height: 1.5)),
            if (action != null) ...[
              const SizedBox(height: 18),
              SizedBox(width: 200, child: EmberButton(action!, onPressed: onAction)),
            ],
          ]),
        ),
      );
}

/// Soft pulsing placeholder while content loads.
class Skeleton extends StatefulWidget {
  final double height;
  final double width;
  final double radius;
  const Skeleton({super.key, this.height = 14, this.width = double.infinity, this.radius = 8});
  @override
  State<Skeleton> createState() => _SkeletonState();
}

class _SkeletonState extends State<Skeleton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: Tween(begin: 0.45, end: 1.0).animate(_c),
        child: Container(width: widget.width, height: widget.height, decoration: BoxDecoration(color: EvColors.sand2, borderRadius: BorderRadius.circular(widget.radius))),
      );
}

class PostSkeleton extends StatelessWidget {
  const PostSkeleton({super.key});
  @override
  Widget build(BuildContext context) => Container(
        color: Colors.white,
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(16),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Skeleton(width: 40, height: 40, radius: 20), SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Skeleton(width: 140), SizedBox(height: 6), Skeleton(width: 80, height: 10)]))]),
          SizedBox(height: 14),
          Skeleton(),
          SizedBox(height: 8),
          Skeleton(width: 220),
          SizedBox(height: 12),
          Skeleton(height: 180, radius: 18),
        ]),
      );
}
