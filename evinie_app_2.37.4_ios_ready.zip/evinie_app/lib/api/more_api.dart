import 'dart:io';
import '../models/models.dart';
import 'api_client.dart';

/// Small helpers for reading the looser response shapes of Phase 4.
Map mapOf(dynamic v) => v is Map ? v : const {};
List<Map> listOf(dynamic v) => v is List ? v.whereType<Map>().toList() : <Map>[];
String str(Map m, String k, [String fallback = '']) => asStr(m[k]).isEmpty ? fallback : asStr(m[k]);

/// iHealth Assist, Business Hub, business verification, referrals,
/// creators, staff, rewards, daily prompt and signed-in devices.
/// The member comes from the sign-in token on the server.
class MoreApi {
  MoreApi._();
  static final MoreApi instance = MoreApi._();
  final ApiClient _c = ApiClient.instance;

  // ---------- iHealth Assist ----------
  Future<Map> healthStatus() async => mapOf(await _c.post('ihealth/status'));
  Future<void> healthConsent() => _c.post('ihealth/consent', {'agree': 1});

  /// Returns chat, reply, flags (emergency, selfharm, child, pregnancy), remaining.
  Future<Map> ask(String message, int chat) async => mapOf(await _c.post('ihealth/ask', {'message': message, if (chat > 0) 'chat': chat}));
  Future<List<Map>> healthChats() async => listOf(mapOf(await _c.post('ihealth/chats'))['list']);
  Future<Map> healthChat(int guid) async => mapOf(await _c.post('ihealth/chat', {'guid': guid}));
  Future<Map> doctors({String specialty = ''}) async => mapOf(await _c.post('ihealth/doctors', {if (specialty.isNotEmpty) 'specialty': specialty}));
  Future<Map> doctor(int guid) async => mapOf(await _c.post('ihealth/doctor', {'guid': guid}));

  /// when: "now" or a slot value; mode: video or chat; pay: wallet or card.
  Future<Map> book({required int doctor, required String when, required String mode, required String pay, String reason = ''}) async =>
      mapOf(await _c.post('ihealth/book', {'doctor': doctor, 'when': when, 'mode': mode, 'pay': pay, 'reason': reason}));
  Future<Map> appointments() async => mapOf(await _c.post('ihealth/appointments'));
  Future<Map> consultation(int booking, {int after = 0}) async => mapOf(await _c.post('ihealth/consultation', {'booking': booking, 'after': after}));
  Future<void> consultSend(int booking, String text) => _c.post('ihealth/send', {'booking': booking, 'text': text});
  Future<void> cancelBooking(int booking) => _c.post('ihealth/cancel', {'booking': booking});
  Future<Map> partners({String kind = ''}) async => mapOf(await _c.post('ihealth/partners', {if (kind.isNotEmpty) 'kind': kind}));

  // ---------- Business pages I manage ----------
  Future<List<Map>> myPages() async => listOf(mapOf(await _c.post('businesspage/mypages', {'offset': 1}))['list']);

  // ---------- Business Hub (page_guid) ----------
  Future<Map> hubSummary(int page) async => mapOf(await _c.post('businesshub/summary', {'page_guid': page}));
  Future<List<Map>> hubDocuments(int page, {String type = ''}) async => listOf(mapOf(await _c.post('businesshub/documents', {'page_guid': page, if (type.isNotEmpty) 'type': type}))['list']);
  Future<Map> hubDocument(int page, int guid) async => mapOf(mapOf(await _c.post('businesshub/document', {'page_guid': page, 'guid': guid}))['document']);
  Future<void> hubEmail(int page, int guid, String email) => _c.post('businesshub/document_email', {'page_guid': page, 'guid': guid, 'email': email});

  /// do: e.g. "paid", "sent", "cancelled"; method for payments (cash, transfer…).
  Future<Map> hubStatus(int page, int guid, String action, {String method = ''}) async =>
      mapOf(mapOf(await _c.post('businesshub/document_status', {'page_guid': page, 'guid': guid, 'do': action, if (method.isNotEmpty) 'method': method}))['document']);
  Future<List<Map>> hubProducts(int page) async => listOf(mapOf(await _c.post('businesshub/products', {'page_guid': page}))['list']);
  Future<Map> hubBooks(int page, String month) async => mapOf(await _c.post('businesshub/books', {'page_guid': page, 'month': month}));
  Future<Map> hubReport(int page, String period) async => mapOf(await _c.post('businesshub/report', {'page_guid': page, 'period': period}));
  Future<Map> hubPayments(int page) async => mapOf(await _c.post('businesshub/payments', {'page_guid': page}));

  /// Creates or updates a quotation or invoice. items: [{description, qty, price, product_guid}].
  Future<Map> hubSaveDocument(int page, Map<String, Object?> fields, {int guid = 0}) async =>
      mapOf(mapOf(await _c.post('businesshub/document_save', {'page_guid': page, if (guid > 0) 'guid': guid, ...fields}))['document']);
  Future<void> hubDeleteDocument(int page, int guid) => _c.post('businesshub/document_delete', {'page_guid': page, 'guid': guid});
  Future<List<Map>> hubActiveProducts(int page) async => listOf(mapOf(await _c.post('businesshub/products', {'page_guid': page, 'active_only': '1'}))['list']);

  /// Creates or updates a product or service, with an optional picture.
  Future<Map> hubSaveProduct(int page, Map<String, Object?> fields, {int guid = 0, File? image}) async {
    final all = <String, Object?>{'page_guid': page, if (guid > 0) 'guid': guid, ...fields};
    final r = image != null ? await _c.upload('businesshub/product_save', all, 'image', image) : await _c.post('businesshub/product_save', all);
    return mapOf(mapOf(r)['product']);
  }

  Future<void> hubDeleteProduct(int page, int guid) => _c.post('businesshub/product_delete', {'page_guid': page, 'guid': guid});

  // ---------- Business verification & team ----------
  Future<Map> suiteStatus(int page) async => mapOf(await _c.post('businesssuite/status', {'page_guid': page}));
  Future<void> suiteUploadCac(int page, File file) => _c.upload('businesssuite/uploadcac', {'page_guid': page}, 'cac', file);
  Future<Map> suitePay(int page) async => mapOf(await _c.post('businesssuite/pay', {'page_guid': page}));
  Future<Map> suiteRenew(int page) async => mapOf(await _c.post('businesssuite/renew', {'page_guid': page}));
  Future<Map> suiteTeam(int page) async => mapOf(await _c.post('businesssuite/team', {'page_guid': page}));
  Future<Map> suiteAddManager(int page, String username, String role) async => mapOf(await _c.post('businesssuite/addmanager', {'page_guid': page, 'username': username, 'role': role}));
  Future<void> suiteRemoveManager(int page, int member) => _c.post('businesssuite/removemanager', {'page_guid': page, 'member_guid': member});

  // ---------- Growth ----------
  Future<Map> referralCode() async => mapOf(await _c.post('referral/mycode'));
  Future<Map> referralStats() async => mapOf(await _c.post('referral/stats'));
  Future<Map> inviteLink() async => mapOf(await _c.post('invite/link'));
  Future<Map> creatorStatus() async => mapOf(await _c.post('creators/status'));
  Future<Map> creatorDashboard() async => mapOf(await _c.post('creators/dashboard', {'days': 30, 'history': 3}));
  Future<Map> creatorApply(String message) async => mapOf(await _c.post('creators/apply', {'message': message}));
  Future<Map> staffSummary(String month) async => mapOf(await _c.post('staffearnings/summary', {'month': month}));
  Future<Map> rewards() async => mapOf(await _c.post('profilerewards/status'));
  Future<Map> dailyPrompt() async => mapOf(await _c.post('dailyprompt/today'));

  // ---------- Signed-in devices ----------
  Future<List<Map>> sessions() async => listOf(mapOf(await _c.post('auth/sessions'))['list']);
  Future<void> revokeSession(int session) => _c.post('auth/revoke', {'session': session});
}
