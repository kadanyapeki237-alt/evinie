import '../models/community.dart';
import '../models/models.dart';
import 'api_client.dart';

/// Discover, hashtags, groups, events, polls, business pages and the
/// marketplace with escrow Buy now. The member comes from the token.
class CommunityApi {
  CommunityApi._();
  static final CommunityApi instance = CommunityApi._();
  final ApiClient _c = ApiClient.instance;

  List<Map> _list(dynamic p, [String key = 'list']) => (p is Map && p[key] is List) ? (p[key] as List).whereType<Map>().toList() : [];

  Future<List<Trend>> trending() async => _list(await _c.post('hashtag/trending', {'limit': 12})).map(Trend.fromJson).where((t) => t.tag.isNotEmpty).toList();

  Future<List<EvPost>> hashtagPosts(int me, String tag, int page) async {
    final p = await _c.post('hashtag/list', {'guid': me, 'hashtag': tag, 'offset': page});
    return _list(p, 'posts').map(EvPost.fromJson).where((x) => x.guid > 0).toList();
  }

  Future<List<EvUser>> suggestions() async => _list(await _c.post('peoplesuggest/list', {'limit': 10})).map((u) => EvUser.fromJson({...u, 'icon': u['icon_url']})).toList();

  Future<List<Group>> groups({bool mine = false, String keyword = ''}) async {
    final p = await _c.post(mine ? 'groups/mine' : 'groups/explore', {if (keyword.isNotEmpty) 'keyword': keyword, if (!mine) 'include_joined': 1});
    return _list(p).map(Group.fromJson).toList();
  }

  Future<List<GroupPost>> groupFeed(int group, int page) async =>
      _list(await _c.post('groupnewsfeed/feed', {'group_guid': group, 'offset': page, 'limit': 15})).map(GroupPost.fromJson).toList();

  /// filter: all, mine (I created) or interested (Interested or Going).
  Future<List<EventItem>> events({String filter = 'all'}) async => _list(await _c.post('eventsv3/list', {'limit': 50, if (filter != 'all') 'filter': filter})).map(EventItem.fromJson).toList();

  Future<EventItem> event(int guid) async {
    final p = await _c.post('event/view', {'guid': guid});
    return EventItem.fromJson((p is Map && p['event'] is Map) ? p['event'] as Map : const {});
  }

  /// type: going, interested or nointerested.
  Future<void> rsvp(int guid, String type) => _c.post('event/relation', {'guid': guid, 'type': type});

  /// [filter]: 'all' (every poll), 'mine' (polls I created) or 'voted'
  /// (polls I took part in).
  Future<List<Poll>> polls({String filter = 'all'}) async {
    if (filter == 'mine' || filter == 'voted') {
      return _list(await _c.post('mypolls/list', {'filter': filter == 'mine' ? 'created' : 'voted', 'limit': 50})).map(Poll.fromJson).toList();
    }
    return _list(await _c.post('pollsv3/list', {'limit': 30})).map(Poll.fromJson).toList();
  }

  /// Corrects the question of a poll I created (choices stay the same).
  Future<void> editPoll(int guid, String title) async {
    await _c.post('poll/edit', {'guid': guid, 'title': title});
  }

  /// One poll with its choices and results. [checkVoted] also asks
  /// poll/voted whether this member has voted (used by the poll screen).
  Future<Poll> poll(int guid, {bool checkVoted = false}) async {
    final p = await _c.post('poll/view', {'guid': guid});
    var poll = Poll.fromJson((p is Map && p['poll'] is Map) ? p['poll'] as Map : const {});
    if (checkVoted) {
      try {
        final v = await _c.post('poll/voted', {'guid': guid});
        if (v is Map && '${v['voted']}'.toLowerCase() == 'yes') poll = poll.copyWith(hasVoted: true);
      } catch (_) {}
    }
    return poll;
  }

  /// Votes and returns the poll with fresh results. Servers that only
  /// send {option hash: percent} back get those applied to [current].
  Future<Poll?> vote(int guid, String option, {Poll? current}) async {
    final p = await _c.post('poll/vote', {'guid': guid, 'option': option});
    if (p is Map && p['poll'] is Map) {
      final fresh = Poll.fromJson(p['poll'] as Map);
      if (fresh.options.isNotEmpty) return fresh.copyWith(hasVoted: true);
    }
    if (current != null && p is Map && p['votes'] is Map) {
      final votes = p['votes'] as Map;
      return current.copyWith(hasVoted: true, options: [
        for (final o in current.options) PollOption(o.key, o.title, o.votes, double.tryParse('${votes[o.key] ?? 0}')),
      ]);
    }
    return current?.copyWith(hasVoted: true);
  }

  /// filter: all, mine (pages I created) or liked (pages I joined).
  Future<List<BizPage>> pages({String keyword = '', bool mine = false, String filter = 'all'}) async {
    final p = await _c.post(mine ? 'businesspage/mypages' : 'businesspage/list', {if (keyword.isNotEmpty) 'keyword': keyword, 'offset': 1, if (!mine && filter != 'all') 'filter': filter});
    return _list(p).map(BizPage.fromJson).toList();
  }

  Future<BizPage> page(int guid) async => BizPage.fromJson(await _c.post('businesspage/view', {'guid': guid}) as Map);

  Future<(bool, int)> likePage(int guid, bool like) async {
    final p = await _c.post(like ? 'businesspage/like' : 'businesspage/unlike', {'guid': guid});
    return (asBool(p['is_liked']), asInt(p['likes_count']));
  }

  Future<List<Product>> products({String keyword = '', int? category, String sort = 'newest'}) async {
    // The server sorts with sort_by (latest, low_high, high_low) and pages with offset.
    const sortBy = {'newest': 'latest', 'price_low': 'low_high', 'price_high': 'high_low'};
    final all = <Product>[];
    final seen = <int>{};
    for (var page = 1; page <= 40; page++) {
      final p = await _c.post('marketplace/list', {if (keyword.isNotEmpty) 'keyword': keyword, if (category != null) 'category_guid': category, 'sort_by': sortBy[sort] ?? 'latest', 'offset': page});
      final batch = _list(p).map(Product.fromJson).where((x) => x.guid > 0 && seen.add(x.guid)).toList();
      if (batch.isEmpty) break;
      all.addAll(batch);
    }
    return all;
  }

  Future<List<Product>> _productsOld({String keyword = '', int? category, String sort = 'newest'}) async {
    final p = await _c.post('marketplace/list', {if (keyword.isNotEmpty) 'keyword': keyword, if (category != null) 'category_guid': category, 'sort_by': sort, 'offset': 1});
    return _list(p).map(Product.fromJson).where((x) => x.guid > 0).toList();
  }

  Future<Product> product(int guid) async {
    final p = await _c.post('marketplace/view', {'guid': guid});
    final m = (p is Map && p['product'] is Map) ? p['product'] as Map : (p as Map);
    return Product.fromJson(m['full'] is Map ? m['full'] as Map : m);
  }

  /// Escrow Buy now: the server takes payment and holds it until the
  /// buyer confirms delivery (or opens a dispute).
  Future<Order> buy(int product) async => Order.fromJson({...(await _c.post('marketescrow/buy', {'product': product}) as Map), 'product_title': ''});

  Future<List<Order>> orders({String role = 'buyer'}) async => _list(await _c.post('marketescrow/list', {'role': role})).map(Order.fromJson).toList();
  Future<void> confirmOrder(int order) => _c.post('marketescrow/confirm', {'order_guid': order});
  Future<void> disputeOrder(int order, String complaint) => _c.post('marketescrow/dispute', {'order_guid': order, 'complaint': complaint});
}
