import 'dart:io';
import '../models/models.dart';
import 'api_client.dart';

/// One method per EndPoints call used by the app. Field names follow the
/// API docs exactly. The member making each request is taken from the
/// sign-in token on the server, so [me] here only fills older fields
/// that some endpoints still require.
class EvinieApi {
  EvinieApi._();
  static final EvinieApi instance = EvinieApi._();
  final ApiClient _c = ApiClient.instance;

  // ---------- account ----------
  /// Signs in with a username, email or phone number. When the account
  /// uses two-step sign-in, the first call throws [TwoFactorRequired]; call
  /// again with its challenge and the code from the email.
  Future<(String, int, EvUser)> signIn(String username, String password, String device, {String challenge = '', String code = ''}) async {
    final p = await _c.post('auth/login', {'username': username, 'password': password, 'device': device, if (challenge.isNotEmpty) 'challenge': challenge, if (code.isNotEmpty) 'code': code});
    if (p is Map && asBool(p['two_factor'])) throw TwoFactorRequired(asStr(p['challenge']), asStr(p['message']));
    return (asStr(p['token']), asInt(p['expires']), EvUser.fromJson(p['user'] as Map));
  }

  /// Emails a password reset link (username, email or phone number).
  Future<String> forgotPassword(String login) async {
    final r = await _c.post('auth/forgot', {'login': login});
    final p = r is Map ? r : const {};
    final msg = asStr(p['message']);
    return msg.isEmpty ? 'If an account matches, we have emailed a link to reset the password.' : msg;
  }

  Future<EvUser> me() async {
    final p = await _c.post('auth/me');
    return EvUser.fromJson(p['user'] as Map);
  }

  Future<void> signOut() async {
    try {
      await _c.post('auth/logout');
    } catch (_) {
      // Signing out locally still matters if the server is unreachable.
    }
  }

  /// user_add. birthdate is dd/mm/yyyy, gender male or female.
  Future<void> signUp({
    required String firstName,
    required String lastName,
    required String email,
    required String gender,
    required String birthdate,
    required String username,
    required String password,
  }) async {
    await _c.post('user_add', {
      'firstname': firstName,
      'lastname': lastName,
      'email': email,
      'reemail': email,
      'gender': gender,
      'birthdate': birthdate,
      'username': username,
      'password': password,
    });
  }

  Future<EvUser> userDetails(int guid) async {
    final p = await _c.post('user_details', {'guid': guid});
    final u = (p is Map && p['user'] is Map) ? p['user'] as Map : (p as Map);
    return EvUser.fromJson(u);
  }

  // ---------- feed & posts ----------
  /// wall_list_home: offset is the page number (10 posts per page).
  Future<List<EvPost>> homeFeed(int me, int page) async {
    final p = await _c.post('wall_list_home', {'guid': me, 'offset': page, 'count': 10});
    return _posts(p);
  }

  /// wall_list_user: uguid is the profile, guid is the viewer.
  Future<List<EvPost>> userFeed(int profile, int me, int page) async {
    final p = await _c.post('wall_list_user', {'uguid': profile, 'guid': me, 'offset': page, 'count': 10});
    return _posts(p);
  }

  List<EvPost> _posts(dynamic p) {
    final list = (p is Map) ? p['posts'] : null;
    if (list is! List) return [];
    return list.whereType<Map>().map(EvPost.fromJson).where((x) => x.guid > 0).toList();
  }

  /// wall_add. privacy: 2 = public, 3 = friends.
  Future<EvPost?> createPost(int me, String text, {File? photo, int privacy = 2, String background = '', String location = ''}) async {
    // wall/add (EndPoints 4.16.3) posts as the signed-in member.
    final fields = {'post': text, 'type': 'user', 'privacy': privacy, if (background.isNotEmpty) 'postbackground_type': background, if (location.isNotEmpty) 'location': location};
    final p = photo == null ? await _c.post('wall/add', fields) : await _c.upload('wall/add', fields, 'ossn_photo', photo);
    return (p is Map && p['post'] is Map) ? EvPost.fromJson(p) : null;
  }

  /// Likes / unlikes a post. post/react (EndPoints 4.40) sets the wanted
  /// state and never fails just because it is already so (video posts
  /// used to show "reaction failed"); older servers use the core calls.
  Future<void> like(int me, int postGuid) => _react(me, postGuid, true);
  Future<void> unlike(int me, int postGuid) => _react(me, postGuid, false);

  Future<void> _react(int me, int postGuid, bool want) async {
    try {
      await _c.post('post/react', {'guid': postGuid, 'like': want ? 1 : 0});
      return;
    } on ApiException catch (e) {
      final m = e.message.toLowerCase();
      // A real answer from the new endpoint: show it.
      if (m.contains('could not be saved') || m.contains('no longer available')) rethrow;
    } catch (_) {}
    await _c.post(want ? 'like_add' : 'unlike_set', {'subject_guid': postGuid, 'type': 'post', 'uguid': me});
  }

  /// Number of comments on the last post loaded by [comments].
  int lastCommentTotal = 0;

  /// All comments on a post (EndPoints comments/all). A post with no
  /// comments gives an empty list, never an error.
  Future<List<EvComment>> comments(int me, int postGuid) async {
    try {
      final p = await _c.post('comments/all', {'guid': postGuid, 'type': 'post', 'limit': 200});
      final list = (p is Map) ? p['comments'] : null;
      final out = list is List ? list.whereType<Map>().map((c) => EvComment.fromJson(c)).toList() : <EvComment>[];
      lastCommentTotal = p is Map && p['total'] != null ? asInt(p['total']) : out.length;
      return out;
    } on ApiException catch (e) {
      if (e.message.toLowerCase().contains('no payload')) {
        lastCommentTotal = 0;
        return [];
      }
      rethrow;
    }
  }

  Future<EvComment?> addComment(int me, int postGuid, String text) async {
    final p = await _c.post('comment_add', {'subject_guid': postGuid, 'comment': text, 'type': 'post', 'uguid': me});
    if (p is! Map) return null;
    return EvComment.fromJson(p, p['user'] is Map ? p['user'] as Map : null);
  }

  // ---------- stories ----------
  Future<List<EvStory>> stories(int me) async => EvStory.listFrom(await _c.post('stories/list', {'uguid': me}));

  // ---------- notifications ----------
  Future<List<EvNotification>> notifications(int me, int page) async {
    final p = await _c.post('notifications_list_user', {'owner_guid': me, 'offset': page});
    final list = (p is Map) ? p['list'] : null;
    if (list is! List) return [];
    return list.whereType<Map>().map(EvNotification.fromJson).toList();
  }

  Future<int> notificationCount(int me) async {
    final p = await _c.post('notifications_count', {'guid': me});
    if (p is Map) return asInt(p['count'] ?? p['notifications'] ?? p['total']);
    return asInt(p);
  }

  // ---------- messages ----------
  Future<List<EvMessage>> recentChats(int me) async {
    final p = await _c.post('message_recent', {'guid': me, 'offset': 1});
    final list = (p is Map) ? p['list'] : null;
    if (list is! List) return [];
    return list.whereType<Map>().map(EvMessage.fromJson).toList();
  }

  Future<List<EvMessage>> chat(int me, int withUser, {int page = 1}) async {
    final p = await _c.post('message_list', {'guid': me, 'to': withUser, 'markallread': 1, 'offset': page});
    final list = (p is Map) ? p['list'] : null;
    if (list is! List) return [];
    return list.whereType<Map>().map(EvMessage.fromJson).toList();
  }

  Future<EvMessage> sendMessage(int me, int to, String text) async {
    final p = await _c.post('message_add', {'from': me, 'to': to, 'message': text});
    return EvMessage.fromJson(p as Map);
  }
}

/// The account uses two-step sign-in: a code was emailed.
class TwoFactorRequired implements Exception {
  final String challenge, message;
  TwoFactorRequired(this.challenge, this.message);
  @override
  String toString() => message;
}
