import '../models/models.dart';
import '../models/money.dart';
import 'api_client.dart';

/// Wallet, eGifts, points, Get verified and EviEarner. Every amount and
/// price comes from the server; the app never works one out itself.
/// The member is taken from the sign-in token on the server.
class MoneyApi {
  MoneyApi._();
  static final MoneyApi instance = MoneyApi._();
  final ApiClient _c = ApiClient.instance;

  Future<double> balance() async => asDouble((await _c.post('wallet/balance'))['balance']);

  Future<(List<WalletEntry>, int)> history(int page) async {
    final p = await _c.post('wallet/history', {'offset': page});
    final list = (p['list'] is List) ? (p['list'] as List).whereType<Map>().map(WalletEntry.fromJson).toList() : <WalletEntry>[];
    return (list, asInt(p['count']));
  }

  /// Starts a Flutterwave top-up: returns the payment page and reference.
  Future<(String link, String txRef)> startTopUp(int amount) async {
    final p = await _c.post('walletadd/init', {'amount': amount});
    return (asStr(p['payment_link']), asStr(p['tx_ref']));
  }

  /// Confirms with Flutterwave and credits once (safe to repeat).
  Future<(bool credited, String reason, double balance)> verifyTopUp(String txRef, String transactionId) async {
    final p = await _c.post('walletadd/verify', {'tx_ref': txRef, 'transaction_id': transactionId});
    return (asBool(p['credited']), asStr(p['reason']), asDouble(p['balance']));
  }

  Future<Cashout> requestCashout({required int amount, required String bank, required String accountNumber, required String accountName}) async {
    final p = await _c.post('walletcashout/request', {'amount': amount, 'bank_name': bank, 'account_number': accountNumber, 'account_name': accountName});
    return Cashout.fromJson(p as Map);
  }

  Future<List<Cashout>> cashouts() async {
    final p = await _c.post('walletcashout/list', {'offset': 1});
    return (p['list'] is List) ? (p['list'] as List).whereType<Map>().map(Cashout.fromJson).toList() : [];
  }

  Future<void> cancelCashout(int guid) => _c.post('walletcashout/cancel', {'guid': guid});

  Future<List<Gift>> gifts() async {
    final p = await _c.post('egifts/list');
    return (p['gifts'] is List) ? (p['gifts'] as List).whereType<Map>().map(Gift.fromJson).toList() : [];
  }

  /// Returns (sent, failed).
  Future<(int, int)> sendGift(int giftGuid, List<int> friends) async {
    final p = await _c.post('egifts/send', {'guid': giftGuid, 'friends': friends.join(',')});
    int n(dynamic v) => v is List ? v.length : asInt(v);
    return (n(p['sent']), n(p['failed']));
  }

  Future<List<GiftEntry>> giftsReceived() async => _entries(await _c.post('egifts/received'));
  Future<List<GiftEntry>> giftsSent() async => _entries(await _c.post('egifts/sent'));
  List<GiftEntry> _entries(dynamic p) => (p is Map && p['list'] is List) ? (p['list'] as List).whereType<Map>().map(GiftEntry.fromJson).toList() : [];

  Future<int> points() async => asInt((await _c.post('userpoints/count'))['userPoints']);

  Future<List<PointsActivity>> pointsActivity() async {
    final p = await _c.post('userpoints/activities', {'limit': 30});
    return (p['list'] is List) ? (p['list'] as List).whereType<Map>().map(PointsActivity.fromJson).toList() : [];
  }

  Future<VerifyStatus> verifyStatus() async => VerifyStatus.fromJson(await _c.post('paidverify/status') as Map);

  /// Charges the Wallet for the plan (monthly or yearly).
  Future<String> payVerification(String plan) async {
    final p = await _c.post('paidverify/pay', {'plan': plan});
    return asStr(p['message']).isEmpty ? 'Payment received. Your request is now pending review.' : asStr(p['message']);
  }

  Future<MyTier> myTier() async => MyTier.fromJson(await _c.post('membershiptier/mystatus') as Map);

  Future<List<EvUser>> friends(int me) async {
    final all = <EvUser>[];
    final seen = <int>{};
    for (var page = 1; page <= 50; page++) {
      final p = await _c.post('user_friends', {'guid': me, 'offset': page});
      final list = p is Map ? (p['list'] ?? p['friends']) : p;
      final batch = list is List ? list.whereType<Map>().map(EvUser.fromJson).where((u) => u.guid > 0).toList() : <EvUser>[];
      final fresh = batch.where((u) => seen.add(u.guid)).toList();
      if (fresh.isEmpty) break; // no more pages (or the server ignores paging)
      all.addAll(fresh);
    }
    return all;
  }
}
