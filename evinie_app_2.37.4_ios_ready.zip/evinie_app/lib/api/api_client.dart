import 'dart:async';
import 'package:http_parser/http_parser.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../config.dart';
import '../state/cache.dart';

/// Read-only endpoints whose answers are saved on the phone. Anything not
/// listed is never saved: iHealth Assist (health data), sign-in, and every
/// action that changes something (posts, payments, Buy now, gifts...).
const Set<String> kSavedReads = {
  'auth/me', 'auth/sessions', 'user_details', 'user_friends',
  'wall_list_home', 'wall_list_user', 'comments_list', 'stories/list',
  'notifications_list_user', 'notifications_count', 'message_recent', 'message_list',
  // iHealth is never listed (health data stays off the phone).
  // 2.37.1: reels, wallet, eGifts and more are saved too, so they open
  // offline. Saved copies are only shown when the server can't be reached
  // (with the "offline" bar); online, every screen still loads live.
  'reelsnewsfeed/feed', 'wallet/balance', 'wallet/history', 'walletcashout/list',
  'egifts/list', 'egifts/received', 'egifts/sent', 'comments/replies', 'creators/badge',
  'mypolls/list', 'poll/voted', 'sitepage/get', 'staff/acquisitions', 'staff/scorecard',
  'video/get', 'wall/get', 'ads/campaigns', 'ads/campaign', 'ads/pricing',
  'userpoints/count', 'userpoints/activities', 'paidverify/status', 'membershiptier/mystatus',
  'comments/all', 'wall/list', 'wall/count', 'group/view', 'group/members', 'groups/mine', 'reelsnewsfeed/comments',
  'video/list', 'birthday/upcoming', 'search/all', 'friends/count', 'profileviews/list',
  'hashtag/trending', 'hashtag/list', 'peoplesuggest/list', 'groups/explore', 'groupnewsfeed/feed',
  'eventsv3/list', 'event/view', 'pollsv3/list', 'poll/view',
  'businesspage/list', 'businesspage/view', 'businesspage/mypages',
  'marketplace/list', 'marketplace/view', 'marketescrow/list',
  'businesshub/summary', 'businesshub/documents', 'businesshub/document', 'businesshub/products',
  'businesshub/books', 'businesshub/report', 'businesshub/payments', 'businesssuite/status', 'businesssuite/team',
  'referral/mycode', 'referral/stats', 'invite/link', 'creators/status', 'creators/dashboard',
  'staffearnings/summary', 'profilerewards/status', 'dailyprompt/today',
  'bookmarks/list', 'profileviewers/list', 'topearners/list', 'block/list', 'membershiptier/list', 'notificationmute/status',
};

/// An error from the API, with a message that is safe to show people.
class ApiException implements Exception {
  final String code;
  final String message;
  ApiException(this.code, this.message);
  @override
  String toString() => message;
}

/// Talks to the Evinie EndPoints API. Every call sends the API key and,
/// once signed in, the member's personal token (X-User-Token). The
/// server works out who the member is from the token.
class ApiClient {
  ApiClient._();
  static final ApiClient instance = ApiClient._();

  final http.Client _http = http.Client();
  String? token;

  /// Called when the server says the token is no longer valid.
  void Function()? onSessionExpired;

  String? _version;
  bool _checkingSession = false;

  /// One "session not valid" reply is not enough to sign someone out:
  /// ask auth/me once, and only sign out if that confirms it.
  Future<void> _confirmExpired() async {
    if (_checkingSession) return;
    _checkingSession = true;
    try {
      await post('auth/me');
    } on ApiException catch (e) {
      if (e.code == '103' && e.message.toLowerCase().contains('session')) onSessionExpired?.call();
    } catch (_) {
      // Offline or slow: keep the member signed in.
    } finally {
      _checkingSession = false;
    }
  }

  /// The API version this server answers on, found once per app start.
  String? get version => _version;

  Future<String> baseUrl() async {
    if (_version == null && AppConfig.apiVersion.isEmpty) {
      // 2.37.1: remembered between launches, so an offline start doesn't
      // wait for the server before showing saved content.
      final kept = await LocalCache.readSetting('api_version');
      if (kept != null && AppConfig.apiVersions.contains(kept)) _version = kept;
    }
    if (_version == null) {
      _version = AppConfig.apiVersion.isNotEmpty ? AppConfig.apiVersion : await _detectVersion();
      LocalCache.writeSetting('api_version', _version!);
    }
    return '${AppConfig.siteUrl}/api/$_version';
  }

  /// Asks each known version for auth/login with no details (harmless:
  /// a working server replies "username and password are required").
  /// Offline: rethrows the network error so saved content can show.
  Future<String> _detectVersion() async {
    Object? networkError;
    for (final v in AppConfig.apiVersions) {
      try {
        final res = await _http.post(Uri.parse('${AppConfig.siteUrl}/api/$v/auth/login'), headers: {'Accept': 'application/json'}, body: {'api_key_token': AppConfig.apiKey}).timeout(const Duration(seconds: 15));
        final j = jsonDecode(res.body);
        if (j is Map && !'${j['message']}'.toLowerCase().contains('invalid method')) return v;
      } on FormatException {
        // Not JSON (for example a web page): try the next version.
      } catch (e) {
        // No network: the other versions can't answer either.
        networkError ??= e;
        break;
      }
    }
    if (networkError != null) throw networkError;
    throw ApiException('setup', "Evinie's server is not set up for the app yet: the sign-in method was not found. EndPoints 4.16 must be installed and enabled on ${AppConfig.siteUrl}.");
  }

  /// True while screens are showing saved content because the phone is offline.
  final ValueNotifier<bool> offline = ValueNotifier(false);

  /// Request fields that change every time (reels already seen, and the
  /// like) and so are left out of the saved copy's name.
  static const _volatile = {'exclude'};

  static String cacheKey(String method, Map<String, Object?> fields) {
    final keys = fields.keys.where((k) => fields[k] != null && !_volatile.contains(k)).toList()..sort();
    return '$method?${keys.map((k) => '$k=${fields[k]}').join('&')}';
  }

  /// The saved answer for a read, if any (for showing it before the network).
  dynamic peek(String method, [Map<String, Object?> fields = const {}]) =>
      kSavedReads.contains(method) ? LocalCache.get(cacheKey(method, fields))?.$1 : null;

  Map<String, String> get _headers => {
        'Accept': 'application/json',
        if (token != null) 'X-User-Token': token!,
      };

  /// Which API version answers each method. evinie.com serves the core
  /// methods (feed, messages, notifications...) and the EndPoints methods
  /// (sign-in, daily prompt...) under different versions, so each method
  /// is tried on the remembered version first, then the others.
  final Map<String, String> _methodVersion = {};

  bool _isInvalidMethod(String raw) {
    try {
      final j = jsonDecode(raw);
      return j is Map && '${j['message']}'.toLowerCase().contains('invalid method');
    } catch (_) {
      return false;
    }
  }

  Future<String> _send(String method, Future<http.Response> Function(String base) send) async {
    await baseUrl();
    final first = _methodVersion[method] ?? _version!;
    final order = [first, ...AppConfig.apiVersions.where((v) => v != first)];
    late String last;
    for (final v in order) {
      final res = await send('${AppConfig.siteUrl}/api/$v');
      last = res.body;
      if (!_isInvalidMethod(last)) {
        _methodVersion[method] = v;
        return last;
      }
    }
    return last;
  }

  Map<String, String> _formFields(Map<String, Object?> fields) {
    final body = <String, String>{'api_key_token': AppConfig.apiKey};
    fields.forEach((k, v) {
      if (v != null) body[k] = '$v';
    });
    return body;
  }

  Future<dynamic> post(String method, [Map<String, Object?> fields = const {}]) async {
    final body = _formFields(fields);
    final savable = kSavedReads.contains(method);
    final key = savable ? cacheKey(method, fields) : '';
    final saved = savable ? LocalCache.get(key) : null;
    try {
      final raw = await _send(method, (base) => _http
          .post(Uri.parse('$base/$method'), headers: _headers, body: body)
          // With a saved copy to fall back on, don't keep people waiting.
          .timeout(Duration(seconds: saved != null ? 12 : 30)));
      final payload = _handle(raw);
      if (savable) await LocalCache.put(key, payload);
      offline.value = false;
      return payload;
    } on ApiException {
      rethrow;
    } on FormatException {
      throw ApiException('bad', 'Evinie sent an unexpected reply. Please try again.');
    } catch (e) {
      // No connection (or too slow): show what was saved, if anything.
      if (saved != null) {
        offline.value = true;
        return saved.$1;
      }
      throw ApiException('net', e is SocketException ? 'No internet connection. Check your network and try again.' : 'Could not reach Evinie. Please try again.');
    }
  }

  Future<dynamic> _multipart(String method, Map<String, Object?> fields, String fileField, List<File> files, {required bool many, int seconds = 600}) async {
    var status = 0;
    try {
      final raw = await _send(method, (base) async {
        // The API key also goes in the address: if a file is bigger than the
        // server's post_max_size, PHP throws away every form field, and the
        // server could then only say "invalid API key" instead of the real reason.
        final req = http.MultipartRequest('POST', Uri.parse('$base/$method').replace(queryParameters: {'api_key_token': AppConfig.apiKey}))
          ..headers.addAll(_headers)
          ..fields.addAll(_formFields(fields));
        for (final f in files) {
          req.files.add(await http.MultipartFile.fromPath(many ? '$fileField[]' : fileField, f.path, contentType: mediaTypeFor(f.path)));
        }
        final res = await http.Response.fromStream(await req.send().timeout(Duration(seconds: seconds)));
        status = res.statusCode;
        return res;
      });
      return _handle(raw);
    } on ApiException {
      rethrow;
    } on SocketException {
      throw ApiException('net', 'No internet connection. Check your network and try again.');
    } on FormatException {
      // Not a JSON reply: the web server stopped the upload before Evinie saw it.
      if (status == 413) throw ApiException('big', 'This file is too large for the server. Please choose a shorter or smaller video.');
      if (status >= 500) throw ApiException('server', 'The server could not process this upload (error $status). Please try a shorter video, or ask the admin to check the server logs.');
      throw ApiException('bad', 'The server sent an unexpected reply to the upload${status > 0 ? ' (HTTP $status)' : ''}.');
    } on TimeoutException {
      throw ApiException('net', 'The upload took too long and was stopped. Try a shorter video or a faster connection.');
    } catch (_) {
      throw ApiException('net', 'The upload did not finish. Please try again.');
    }
  }

  /// Same as [post], with one file attached (for example a post photo).
  Future<dynamic> upload(String method, Map<String, Object?> fields, String fileField, File file) =>
      _multipart(method, fields, fileField, [file], many: false);

  /// Several files in one field (for example product photos as photos[]).
  Future<dynamic> uploadMany(String method, Map<String, Object?> fields, String fileField, List<File> files) =>
      _multipart(method, fields, fileField, files, many: true, seconds: 600);

  /// The real type of a file, from its extension.
  static MediaType mediaTypeFor(String path) {
    final ext = path.split('.').last.toLowerCase();
    const types = {
      'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'jfif': 'image/jpeg', 'png': 'image/png', 'gif': 'image/gif', 'webp': 'image/webp', 'heic': 'image/heic',
      'mp4': 'video/mp4', 'mov': 'video/quicktime', '3gp': 'video/3gpp', 'webm': 'video/webm', 'mkv': 'video/x-matroska',
      'm4a': 'audio/mp4', 'aac': 'audio/aac', 'mp3': 'audio/mpeg', 'wav': 'audio/wav', 'ogg': 'audio/ogg',
      'pdf': 'application/pdf', 'doc': 'application/msword', 'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    };
    return MediaType.parse(types[ext] ?? 'application/octet-stream');
  }

  dynamic _handle(String raw) {
    final json = jsonDecode(raw);
    if (json is! Map) throw ApiException('bad', 'Evinie sent an unexpected reply.');
    final code = '${json['code'] ?? ''}';
    if (code == '100') return json['payload'];
    var message = (json['message'] ?? 'Something went wrong.').toString();
    if (message.toLowerCase().contains('invalid method')) {
      message = 'This feature is not available on the server yet. Please ask the Evinie admin to update EndPoints.';
    }
    if (token != null && code == '103' && message.toLowerCase().contains('session')) {
      _confirmExpired();
    }
    throw ApiException(code, message);
  }
}
