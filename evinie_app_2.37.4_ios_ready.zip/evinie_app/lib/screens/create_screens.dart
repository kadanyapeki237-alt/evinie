import 'package:video_player/video_player.dart';
import '../widgets/post_extras.dart';
import '../widgets/feed_extras.dart' show ReelPlayerScreen;
import '../state/media_cache.dart';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../api/api_client.dart';
import '../api/community_api.dart';
import '../api/money_api.dart';
import '../api/more_api.dart';
import '../models/community.dart';
import '../models/models.dart';
import '../models/money.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'discover_screens.dart';
import 'feed_screens.dart';
import 'market_screens.dart';
import 'money_screens.dart';

final _api = ApiClient.instance;

/// Friend requests sent from People you may know (this session).
final Set<int> _requested = {};

/// The "+" button: everything you can create, in one sheet.
Future<bool?> showCreateSheet(BuildContext context) {
  final items = [
    (Icons.edit_rounded, 'Post', EvColors.ember2, () => const CreatePostScreen()),
    (Icons.photo_library_outlined, 'Photo', EvColors.blue, () => const CreatePostScreen(pickPhoto: true)),
    (Icons.videocam_outlined, 'Video', EvColors.red, () => const VideoUploadScreen()),
    (Icons.add_circle_outline_rounded, 'Story', EvColors.ember2, () => const StoryUploadScreen()),
    (Icons.bar_chart_rounded, 'Poll', EvColors.green, () => const CreatePollScreen()),
    (Icons.event_rounded, 'Event', EvColors.blue, () => const CreateEventScreen()),
    (Icons.sell_outlined, 'Product', EvColors.gold, () => const CreateProductScreen()),
    (Icons.flag_outlined, 'Page', EvColors.red, () => const CreatePageScreen()),
    (Icons.groups_rounded, 'Group', const Color(0xFF7C4DFF), () => const CreateGroupScreen()),
    (Icons.campaign_outlined, 'Ad', EvColors.ember2, () => const WebPage(title: 'Create an ad', path: 'ads/add')),
  ];
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (sheet) => SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Create', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            childAspectRatio: 3.3,
            children: [
              for (final it in items)
                InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () async {
                    Navigator.pop(sheet);
                    final made = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => it.$4(), fullscreenDialog: true));
                    if (made == true && context.mounted) showMessage(context, 'Done!');
                  },
                  child: Container(
                    decoration: BoxDecoration(border: Border.all(color: EvColors.line), borderRadius: BorderRadius.circular(14)),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Row(children: [Tile(it.$1, it.$3, size: 32), const SizedBox(width: 10), Text(it.$2, style: const TextStyle(fontWeight: FontWeight.w600))]),
                  ),
                ),
            ],
          ),
        ]),
      ),
    ),
  );
}

/// Shared form scaffold: fields, then one action button at the bottom.
class _Form extends StatelessWidget {
  final String title, action;
  final List<Widget> children;
  final bool busy;
  final VoidCallback onSubmit;
  const _Form({required this.title, required this.action, required this.children, required this.busy, required this.onSubmit});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Column(children: [
          Expanded(child: ListView(padding: const EdgeInsets.all(16), children: children)),
          Padding(padding: EdgeInsets.fromLTRB(16, 8, 16, 12 + MediaQuery.of(context).padding.bottom), child: EmberButton(action, loading: busy, onPressed: onSubmit)),
        ]),
      );
}

Widget _gap() => const SizedBox(height: 12);

Future<void> _submit(State s, void Function(bool) setBusy, Future<void> Function() run) async {
  setBusy(true);
  try {
    await run();
    if (s.mounted) Navigator.of(s.context).pop(true);
  } catch (e) {
    if (s.mounted) showMessage(s.context, '$e');
  } finally {
    if (s.mounted) setBusy(false);
  }
}

class VideoUploadScreen extends StatefulWidget {
  const VideoUploadScreen({super.key});
  @override
  State<VideoUploadScreen> createState() => _VideoUploadScreenState();
}

class _VideoUploadScreenState extends State<VideoUploadScreen> {
  final _title = TextEditingController(), _desc = TextEditingController();
  File? _video;
  bool _busy = false;

  Future<void> _pick(ImageSource src) async {
    final x = await ImagePicker().pickVideo(source: src, maxDuration: const Duration(minutes: 10));
    if (x != null) setState(() => _video = File(x.path));
  }

  @override
  Widget build(BuildContext context) => _Form(
        title: 'Add video',
        action: 'Upload video',
        busy: _busy,
        onSubmit: () {
          if (_video == null) return showMessage(context, 'Record or choose a video first.');
          if (_title.text.trim().isEmpty) return showMessage(context, 'Add a title.');
          _submit(this, (b) => setState(() => _busy = b), () => _api.upload('video/add', {'title': _title.text.trim(), 'description': _desc.text.trim(), 'container_type': 'user', 'container_guid': Scope.read(context).current.guid}, 'video', _video!));
        },
        children: [
          EvCard(
            child: Column(children: [
              if (_video != null) Padding(padding: const EdgeInsets.only(bottom: 10), child: ClipRRect(borderRadius: BorderRadius.circular(14), child: SizedBox(height: 220, child: LocalVideoPreview(_video!, key: ValueKey(_video!.path))))) else
              Tile(_video == null ? Icons.videocam_outlined : Icons.check_rounded, _video == null ? EvColors.ember2 : EvColors.green, size: 52),
              const SizedBox(height: 8),
              Text(_video == null ? 'Add your video' : 'Video ready', style: const TextStyle(fontWeight: FontWeight.w700)),
              const Text('MP4 or MOV, up to 10 minutes', style: TextStyle(color: EvColors.muted, fontSize: 12)),
              const SizedBox(height: 12),
              Row(children: [Expanded(child: EmberButton('Record', icon: Icons.fiber_manual_record_rounded, onPressed: () => _pick(ImageSource.camera))), const SizedBox(width: 8), Expanded(child: OutlineEmberButton('Choose', onPressed: () => _pick(ImageSource.gallery)))]),
            ]),
          ),
          _gap(),
          TextField(controller: _title, decoration: const InputDecoration(hintText: 'Title')),
          _gap(),
          TextField(controller: _desc, maxLines: 3, decoration: const InputDecoration(hintText: 'Tell viewers what your video is about…')),
        ],
      );
}

class StoryUploadScreen extends StatefulWidget {
  const StoryUploadScreen({super.key});
  @override
  State<StoryUploadScreen> createState() => _StoryUploadScreenState();
}

class _StoryUploadScreenState extends State<StoryUploadScreen> {
  final _text = TextEditingController();
  File? _file;
  bool _isVideo = false, _busy = false;

  /// Video stories also go to Reels (EndPoints 4.42), unless unticked.
  bool _toReels = true;

  Future<void> _pick(bool video) async {
    final p = ImagePicker();
    final x = video ? await p.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 60)) : await p.pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
    if (x != null) {
      setState(() {
        _file = File(x.path);
        _isVideo = video;
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white, title: const Text('New story', style: TextStyle(color: Colors.white))),
        body: Column(children: [
          Expanded(
            child: Center(
              child: _file != null && !_isVideo
                  ? Image.file(_file!, fit: BoxFit.contain)
                  : _file != null
                      ? LocalVideoPreview(_file!, key: ValueKey(_file!.path))
                      : Padding(
                          padding: const EdgeInsets.all(24),
                          child: TextField(controller: _text, maxLines: 5, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700), decoration: const InputDecoration(filled: false, hintText: 'Type a text story, or add a photo or video', hintStyle: TextStyle(color: Colors.white54, fontSize: 18), border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none)),
                        ),
            ),
          ),
          if (_file != null && _isVideo)
            Padding(
              padding: const EdgeInsets.fromLTRB(8, 0, 16, 0),
              child: CheckboxListTile(
                value: _toReels,
                onChanged: (v) => setState(() => _toReels = v ?? true),
                controlAffinity: ListTileControlAffinity.leading,
                dense: true,
                activeColor: EvColors.ember2,
                checkColor: Colors.white,
                side: const BorderSide(color: Colors.white70),
                title: const Text('Also share to Reels', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                subtitle: const Text('Stays on Reels after the story ends', style: TextStyle(color: Colors.white60, fontSize: 12)),
              ),
            ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                IconButton.filled(onPressed: () => _pick(false), icon: const Icon(Icons.photo_outlined), style: IconButton.styleFrom(backgroundColor: Colors.white24)),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: () => _pick(true), icon: const Icon(Icons.videocam_outlined), style: IconButton.styleFrom(backgroundColor: Colors.white24)),
                const SizedBox(width: 12),
                Expanded(
                  child: EmberButton('Share to story', loading: _busy, onPressed: () {
                    if (_file == null && _text.text.trim().isEmpty) return showMessage(context, 'Add a photo, a video or some text.');
                    if (_file != null && _isVideo) {
                      final mb = _file!.lengthSync() / (1024 * 1024);
                      if (mb > 100) return showMessage(context, 'This video is ${mb.toStringAsFixed(0)} MB. Please choose one under 100 MB (a shorter clip).');
                      showMessage(context, 'Uploading your video (${mb.toStringAsFixed(1)} MB)… please keep the app open.');
                    }
                    _submit(this, (b) => setState(() => _busy = b), () async {
                      if (_file == null) {
                        await _api.post('stories/add', {'story_type': 'text', 'story_text': _text.text.trim()});
                      } else {
                        // The story endpoint reads both photos and videos from the "video" field.
                        final me = Scope.read(context).current;
                        final r = mapOf(await _api.upload('stories/add', {'story_type': _isVideo ? 'video' : 'photos', 'title': _text.text.trim(), if (_isVideo) 'to_reels': _toReels ? 1 : 0}, _isVideo ? 'video' : 'image', _file!));
                        // The server could not post it to Reels itself (or is
                        // older): upload it to Reels like a normal video.
                        if (_isVideo && _toReels && asInt(r['reel_guid']) == 0) {
                          try {
                            final t = _text.text.trim();
                            await _api.upload('video/add', {'title': t.isEmpty ? "${me.fullname.split(' ').first}'s story" : t, 'description': '', 'container_type': 'user', 'container_guid': me.guid}, 'video', _file!);
                          } catch (_) {
                            // The story is shared; only the reel copy failed.
                          }
                        }
                      }
                    });
                  }),
                ),
              ]),
            ),
          ),
        ]),
      );
}

class CreatePollScreen extends StatefulWidget {
  const CreatePollScreen({super.key});
  @override
  State<CreatePollScreen> createState() => _CreatePollScreenState();
}

class _CreatePollScreenState extends State<CreatePollScreen> {
  final _q = TextEditingController();
  final _opts = [TextEditingController(), TextEditingController()];
  DateTime _closes = DateTime.now().add(const Duration(days: 7));
  bool _busy = false;
  String _ymd(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  @override
  Widget build(BuildContext context) => _Form(
        title: 'Create a poll',
        action: 'Publish poll',
        busy: _busy,
        onSubmit: () {
          final options = _opts.map((c) => c.text.trim()).where((t) => t.isNotEmpty).toList();
          if (_q.text.trim().isEmpty || options.length < 2) return showMessage(context, 'Add a question and at least two choices.');
          _submit(this, (b) => setState(() => _busy = b), () => _api.post('poll/add', {
                'title': _q.text.trim(),
                'container_type': 'user',
                'container_guid': Scope.read(context).current.guid,
                'counter': options.length,
                'closes': _ymd(_closes),
                for (var i = 0; i < options.length; i++) 'poll_options_${i + 1}': options[i],
              }));
        },
        children: [
          TextField(controller: _q, maxLines: 3, decoration: const InputDecoration(hintText: 'Ask a question…')),
          _gap(),
          for (var i = 0; i < _opts.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: TextField(controller: _opts[i], decoration: InputDecoration(hintText: 'Choice ${i + 1}', suffixIcon: i >= 2 ? IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => _opts.removeAt(i))) : null)),
            ),
          if (_opts.length < 6) Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: () => setState(() => _opts.add(TextEditingController())), icon: const Icon(Icons.add_rounded), label: const Text('Add choice (up to 6)'))),
          _gap(),
          OutlinedButton.icon(
            onPressed: () async {
              final now = DateTime.now();
              final d = await showDatePicker(context: context, initialDate: _closes, firstDate: now, lastDate: now.add(const Duration(days: 365)), helpText: 'Poll closes on');
              if (d != null) setState(() => _closes = d);
            },
            icon: const Icon(Icons.event_available_rounded, size: 18),
            label: Text('Closes on ${_closes.day}/${_closes.month}/${_closes.year}'),
          ),
          const Padding(padding: EdgeInsets.only(top: 6), child: Text('Voting stops at the end of this day. After that, everyone sees the results.', style: TextStyle(color: EvColors.muted, fontSize: 12))),
        ],
      );
}

class CreateEventScreen extends StatefulWidget {
  const CreateEventScreen({super.key});
  @override
  State<CreateEventScreen> createState() => _CreateEventScreenState();
}

class _CreateEventScreenState extends State<CreateEventScreen> {
  final _title = TextEditingController(), _info = TextEditingController(), _loc = TextEditingController(), _cost = TextEditingController();
  DateTime? _date;
  TimeOfDay? _start, _end;
  File? _cover;
  bool _busy = false;
  String _t(TimeOfDay? t) => t == null ? '' : '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) => _Form(
        title: 'Create event',
        action: 'Create event',
        busy: _busy,
        onSubmit: () {
          if (_title.text.trim().isEmpty || _info.text.trim().isEmpty || _date == null || _cover == null) return showMessage(context, 'Add a cover photo, title, description and date.');
          final d = _date!;
          _submit(this, (b) => setState(() => _busy = b), () => _api.upload('event/add', {
                'title': _title.text.trim(),
                'info': _info.text.trim(),
                'location': _loc.text.trim(),
                'date': '${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}/${d.year}',
                'start_time': _t(_start),
                'end_time': _t(_end),
                'event_cost': _cost.text.trim(),
                'allowed_comments': 1,
                'container_type': 'user',
                'container_guid': Scope.read(context).current.guid,
              }, 'picture', _cover!));
        },
        children: [
          GestureDetector(
            onTap: () async {
              final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1920, imageQuality: 85);
              if (x != null) setState(() => _cover = File(x.path));
            },
            child: Container(
              height: 150,
              decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE8C6B0))),
              clipBehavior: Clip.antiAlias,
              child: _cover != null ? Image.file(_cover!, fit: BoxFit.cover, width: double.infinity) : const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.add_a_photo_outlined, color: EvColors.ember2, size: 30), Text('Add cover photo (required)', style: TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w600))])),
            ),
          ),
          _gap(),
          TextField(controller: _title, decoration: const InputDecoration(hintText: 'Event name')),
          _gap(),
          TextField(controller: _info, maxLines: 3, decoration: const InputDecoration(hintText: "What's this event about?")),
          _gap(),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: () async {
              final d = await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 730)));
              if (d != null) setState(() => _date = d);
            }, icon: const Icon(Icons.calendar_today_rounded, size: 16), label: Text(_date == null ? 'Date' : '${_date!.day}/${_date!.month}/${_date!.year}'))),
            const SizedBox(width: 6),
            Expanded(child: OutlinedButton(onPressed: () async {
              final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 18, minute: 0));
              if (t != null) setState(() => _start = t);
            }, child: Text(_start == null ? 'Starts' : _t(_start)))),
            const SizedBox(width: 6),
            Expanded(child: OutlinedButton(onPressed: () async {
              final t = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 21, minute: 0));
              if (t != null) setState(() => _end = t);
            }, child: Text(_end == null ? 'Ends' : _t(_end)))),
          ]),
          _gap(),
          TextField(controller: _loc, decoration: const InputDecoration(hintText: 'Location', prefixIcon: Icon(Icons.place_outlined))),
          _gap(),
          TextField(controller: _cost, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'Price (leave empty if free)', prefixText: '₦ ')),
        ],
      );
}

class CreateProductScreen extends StatefulWidget {
  const CreateProductScreen({super.key});
  @override
  State<CreateProductScreen> createState() => _CreateProductScreenState();
}

class _CreateProductScreenState extends State<CreateProductScreen> {
  final _title = TextEditingController(), _desc = TextEditingController(), _price = TextEditingController(), _loc = TextEditingController(), _cat = TextEditingController();
  final _photos = <File>[];
  String _condition = 'new';
  bool _busy = false;
  @override
  Widget build(BuildContext context) => _Form(
        title: 'Add product',
        action: 'Publish listing',
        busy: _busy,
        onSubmit: () {
          if (_photos.isEmpty || _title.text.trim().isEmpty || (double.tryParse(_price.text.trim()) ?? 0) <= 0) return showMessage(context, 'Add at least one photo, a title and a price.');
          _submit(this, (b) => setState(() => _busy = b), () => _api.uploadMany('marketplace/add', {
                'title': _title.text.trim(),
                'desc': _desc.text.trim(),
                'price': _price.text.trim(),
                'currency': 'NGN',
                'location': _loc.text.trim(),
                'category': _cat.text.trim(),
                'product_type': _condition,
                'cover_index': 0,
                'privacy': 2,
                'allow_comments': 1,
                'container_type': 'user',
                'container_guid': Scope.read(context).current.guid,
              }, 'photos', _photos));
        },
        children: [
          SizedBox(
            height: 84,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              if (_photos.length < 5)
                GestureDetector(
                  onTap: () async {
                    final x = await ImagePicker().pickMultiImage(maxWidth: 1600, imageQuality: 85);
                    setState(() => _photos.addAll(x.map((f) => File(f.path)).take(5 - _photos.length)));
                  },
                  child: Container(width: 84, decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.add_a_photo_outlined, color: EvColors.ember2)),
                ),
              for (var i = 0; i < _photos.length; i++)
                Padding(padding: const EdgeInsets.only(left: 8), child: Stack(children: [ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(_photos[i], width: 84, height: 84, fit: BoxFit.cover)), Positioned(right: 2, top: 2, child: GestureDetector(onTap: () => setState(() => _photos.removeAt(i)), child: const CircleAvatar(radius: 11, backgroundColor: Colors.black54, child: Icon(Icons.close_rounded, size: 13, color: Colors.white))))])),
            ]),
          ),
          const Padding(padding: EdgeInsets.only(top: 4), child: Text('Up to 5 photos. The first is the cover.', style: TextStyle(color: EvColors.muted, fontSize: 12))),
          _gap(),
          TextField(controller: _title, decoration: const InputDecoration(hintText: 'Title, e.g. Wireless headphones')),
          _gap(),
          TextField(controller: _desc, maxLines: 3, decoration: const InputDecoration(hintText: "Describe it and what's included")),
          _gap(),
          Row(children: [
            Expanded(child: TextField(controller: _price, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'Price', prefixText: '₦ '))),
            const SizedBox(width: 8),
            Expanded(child: DropdownButtonFormField<String>(value: _condition, items: const [DropdownMenuItem(value: 'new', child: Text('New')), DropdownMenuItem(value: 'used', child: Text('Used'))], onChanged: (v) => setState(() => _condition = v ?? 'new'))),
          ]),
          _gap(),
          TextField(controller: _cat, decoration: const InputDecoration(hintText: 'Category, e.g. Electronics')),
          _gap(),
          TextField(controller: _loc, decoration: const InputDecoration(hintText: 'Location, e.g. Lagos', prefixIcon: Icon(Icons.place_outlined))),
        ],
      );
}

class CreatePageScreen extends StatefulWidget {
  const CreatePageScreen({super.key});
  @override
  State<CreatePageScreen> createState() => _CreatePageScreenState();
}

class _CreatePageScreenState extends State<CreatePageScreen> {
  final _c = {for (final k in ['name', 'category', 'description', 'phone', 'email', 'address', 'website']) k: TextEditingController()};
  bool _busy = false;
  @override
  Widget build(BuildContext context) => _Form(
        title: 'Create page',
        action: 'Create page',
        busy: _busy,
        onSubmit: () {
          if (_c['name']!.text.trim().isEmpty) return showMessage(context, 'Give your page a name.');
          _submit(this, (b) => setState(() => _busy = b), () => _api.post('businesspage/add', {for (final e in _c.entries) e.key: e.value.text.trim()}));
        },
        children: [
          for (final f in [('name', 'Page name', Icons.storefront_outlined), ('category', 'Category, e.g. Café', Icons.category_outlined), ('description', 'What your page is about', Icons.notes_rounded), ('phone', 'Phone', Icons.phone_outlined), ('email', 'Email', Icons.mail_outline_rounded), ('address', 'Address', Icons.place_outlined), ('website', 'Website', Icons.public_rounded)])
            Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: _c[f.$1], maxLines: f.$1 == 'description' ? 3 : 1, decoration: InputDecoration(hintText: f.$2, prefixIcon: Icon(f.$3)))),
        ],
      );
}

class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});
  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _name = TextEditingController(), _about = TextEditingController();
  String _privacy = 'public';
  bool _busy = false;
  @override
  Widget build(BuildContext context) => _Form(
        title: 'Create a group',
        action: 'Create group',
        busy: _busy,
        onSubmit: () {
          if (_name.text.trim().isEmpty) return showMessage(context, 'Give your group a name.');
          _submit(this, (b) => setState(() => _busy = b), () => _api.post('group/add', {'name': _name.text.trim(), 'description': _about.text.trim(), 'privacy': _privacy}));
        },
        children: [
          TextField(controller: _name, decoration: const InputDecoration(hintText: 'Group name')),
          _gap(),
          TextField(controller: _about, maxLines: 3, decoration: const InputDecoration(hintText: "What's your group about?")),
          _gap(),
          SegmentedButton<String>(segments: const [ButtonSegment(value: 'public', label: Text('Public'), icon: Icon(Icons.public_rounded)), ButtonSegment(value: 'private', label: Text('Private'), icon: Icon(Icons.lock_outline_rounded))], selected: {_privacy}, onSelectionChanged: (v) => setState(() => _privacy = v.first)),
          const SizedBox(height: 6),
          Text(_privacy == 'public' ? 'Anyone can see the group and its posts.' : 'Only members can see posts. People ask to join.', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
        ],
      );
}

/// Share a public post: to your timeline, a friend's timeline, or a group.
Future<void> showShareSheet(BuildContext context, EvPost post) async {
  final me = Scope.read(context).current;
  final choice = await showModalBottomSheet<String>(
    context: context,
    backgroundColor: Colors.white,
    builder: (s) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Padding(padding: EdgeInsets.all(14), child: Text('Share to', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
        ListTile(leading: const Tile(Icons.dynamic_feed_rounded, EvColors.ember2), title: const Text('Your timeline'), onTap: () => Navigator.pop(s, 'newsfeed')),
        ListTile(leading: const Tile(Icons.person_outline_rounded, EvColors.blue), title: const Text("A friend's timeline"), onTap: () => Navigator.pop(s, 'friend')),
        ListTile(leading: const Tile(Icons.groups_rounded, Color(0xFF7C4DFF)), title: const Text('A group'), onTap: () => Navigator.pop(s, 'group')),
      ]),
    ),
  );
  if (choice == null || !context.mounted) return;
  int? target;
  if (choice == 'friend') {
    final friends = await MoneyApi.instance.friends(me.guid).catchError((_) => <EvUser>[]);
    if (!context.mounted) return;
    target = await _pick(context, 'Choose a friend', [for (final f in friends) (f.guid, f.fullname)]);
  } else if (choice == 'group') {
    final groups = await CommunityApi.instance.groups(mine: true).catchError((_) => <Group>[]);
    if (!context.mounted) return;
    target = await _pick(context, 'Choose a group', [for (final g in groups) (g.guid, g.title)]);
  }
  if (choice != 'newsfeed' && target == null) return;
  try {
    await _api.post('sharepost/share', {'guid': post.guid, 'type': choice, if (choice == 'friend') 'friend': target, if (choice == 'group') 'group': target});
    if (context.mounted) showMessage(context, 'Shared.');
  } catch (e) {
    if (context.mounted) showMessage(context, '$e');
  }
}

Future<int?> _pick(BuildContext context, String title, List<(int, String)> items) => showModalBottomSheet<int>(
      context: context,
      backgroundColor: Colors.white,
      builder: (s) => SafeArea(
        child: items.isEmpty
            ? const Padding(padding: EdgeInsets.all(24), child: Text('Nothing to choose from yet.'))
            : ListView(shrinkWrap: true, children: [Padding(padding: const EdgeInsets.all(14), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700))), for (final it in items) ListTile(title: Text(it.$2), onTap: () => Navigator.pop(s, it.$1))]),
      ),
    );

/// Search people and groups; pages and products search in their own screens.
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  Map? _r;
  bool _busy = false;
  String? _error;
  Future<void> _go(String q) async {
    if (q.trim().length < 2) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final r = await _api.post('search/all', {'q': q.trim()});
      if (mounted) setState(() => _r = mapOf(r));
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final users = listOf(_r?['users']), groups = listOf(_r?['groups']);
    return Scaffold(
      appBar: AppBar(titleSpacing: 0, title: TextField(autofocus: true, textInputAction: TextInputAction.search, onSubmitted: _go, decoration: const InputDecoration(hintText: 'Search people and groups', prefixIcon: Icon(Icons.search_rounded)))),
      body: _busy
          ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
          : _error != null
              ? StateMessage(icon: Icons.search_off_rounded, title: 'Search is not available', body: _error!)
              : _r == null
                  ? ListView(padding: const EdgeInsets.all(16), children: [
                      const Text('Also search', style: TextStyle(color: EvColors.muted)),
                      const SizedBox(height: 8),
                      Wrap(spacing: 8, children: [ActionChip(label: const Text('Business pages'), onPressed: () => push(context, const PagesScreen())), ActionChip(label: const Text('Marketplace'), onPressed: () => push(context, const MarketplaceScreen()))]),
                    ])
                  : users.isEmpty && groups.isEmpty
                      ? const StateMessage(icon: Icons.search_off_rounded, title: 'No results', body: 'Try a different name.')
                      : ListView(children: [
                          if (users.isNotEmpty) const Padding(padding: EdgeInsets.fromLTRB(16, 12, 16, 4), child: Text('People', style: TextStyle(fontWeight: FontWeight.w700))),
                          for (final u in users) ListTile(tileColor: Colors.white, leading: Avatar(EvUser.fromJson(u), size: 42), title: Text(EvUser.fromJson(u).fullname), subtitle: Text('@${str(u, 'username')}'), onTap: () => openProfile(context, EvUser.fromJson(u))),
                          if (groups.isNotEmpty) const Padding(padding: EdgeInsets.fromLTRB(16, 16, 16, 4), child: Text('Groups', style: TextStyle(fontWeight: FontWeight.w700))),
                          for (final g in groups)
                            ListTile(
                              tileColor: Colors.white,
                              leading: const Tile(Icons.groups_rounded, Color(0xFF7C4DFF)),
                              title: Text(str(g, 'title')),
                              subtitle: Text(str(g, 'privacy') == 'private' ? 'Private group' : 'Public group'),
                              onTap: () => push(context, GroupScreen(group: Group(guid: asInt(g['guid']), title: str(g, 'title'), description: str(g, 'description'), cover: '', privacy: str(g, 'privacy'), members: 0, joinStatus: '', isMember: false, isOwner: false, url: str(g, 'url')))),
                            ),
                        ]),
    );
  }
}

/// A simple list screen built from one endpoint.
class _ListScreen extends StatefulWidget {
  final String title, method, empty;
  final Map<String, Object?> fields;
  final Widget Function(BuildContext, Map item, VoidCallback reload) row;
  const _ListScreen({required this.title, required this.method, required this.empty, required this.row, this.fields = const {}});
  @override
  State<_ListScreen> createState() => _ListScreenState();
}

class _ListScreenState extends State<_ListScreen> {
  List<Map>? _list;
  String? _error;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await _api.post(widget.method, widget.fields);
      final m = mapOf(p);
      if (mounted) setState(() => _list = listOf(m['list'] ?? m['users'] ?? m['posts'] ?? p));
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: _error != null
            ? StateMessage(icon: Icons.info_outline_rounded, title: 'Not available', body: _error!, action: 'Try again', onAction: _load)
            : _list == null
                ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
                : _list!.isEmpty
                    ? StateMessage(icon: Icons.inbox_outlined, title: 'Nothing here yet', body: widget.empty)
                    : RefreshIndicator(onRefresh: _load, child: ListView.separated(padding: const EdgeInsets.all(16), itemCount: _list!.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (c, i) => widget.row(c, _list![i], _load))),
      );
}

EvUser _userIn(Map m) => EvUser.fromJson({...m, if (m['user'] is Map) ...m['user'] as Map, if (m['icon'] == null) 'icon': m['icon_url']});

class ProfileViewsScreen extends StatelessWidget {
  const ProfileViewsScreen({super.key});
  @override
  Widget build(BuildContext context) => _ListScreen(
        title: 'Profile views',
        method: 'profileviews/list',
        fields: const {'offset': 1},
        empty: 'People who view your profile will show here.',
        row: (c, m, _) {
          final u = EvUser.fromJson({'guid': m['from'] ?? m['guid'], 'fullname': m['fullname'], 'username': m['username'], 'icon': m['icon_url'] ?? m['icon']});
          return EvCard(padding: EdgeInsets.zero, child: ListTile(trailing: RelationChip(u.guid), leading: Avatar(u, size: 42), title: NameLine(u), subtitle: Text(timeAgo(asTime(m['viewed_time'] ?? m['time'] ?? m['time_created'])), style: const TextStyle(color: EvColors.muted, fontSize: 12)), onTap: () => openProfile(c, u)));
        },
      );
}

class PeopleScreen extends StatelessWidget {
  const PeopleScreen({super.key});
  @override
  Widget build(BuildContext context) => _ListScreen(
        title: 'People you may know',
        method: 'peoplesuggest/list',
        fields: const {'limit': 40},
        empty: 'Suggestions appear as you add friends and join groups.',
        row: (c, m, _) {
          final u = _userIn(m);
          return EvCard(
            padding: EdgeInsets.zero,
            child: ListTile(
              leading: Avatar(u, size: 46),
              title: NameLine(u),
              subtitle: Text('@${u.username}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
              onTap: () => openProfile(c, u),
              trailing: StatefulBuilder(
                builder: (c2, set) => _requested.contains(u.guid)
                    ? OutlinedButton.icon(onPressed: null, icon: const Icon(Icons.schedule_rounded, size: 16), label: const Text('Requested'), style: OutlinedButton.styleFrom(visualDensity: VisualDensity.compact))
                    : FilledButton.icon(
                        style: FilledButton.styleFrom(backgroundColor: EvColors.ember2, visualDensity: VisualDensity.compact),
                        icon: const Icon(Icons.person_add_alt_1_rounded, size: 16),
                        label: const Text('Add'),
                        onPressed: () async {
                          try {
                            await _api.post('user_add_friend', {'user_a': Scope.read(c).current.guid, 'user_b': u.guid});
                            set(() => _requested.add(u.guid));
                          } catch (e) {
                            if (c.mounted) showMessage(c, '$e');
                          }
                        },
                      ),
              ),
            ),
          );
        },
      );
}

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key});
  @override
  Widget build(BuildContext context) => _ListScreen(
        title: 'Saved',
        method: 'bookmarks/list',
        empty: 'Save posts to read later; they appear here.',
        row: (c, m, reload) {
          // 4.40: each saved item says what it is (post, video, missing).
          final kind = asStr(m['kind']).isEmpty ? 'post' : asStr(m['kind']);
          final post = EvPost.fromJson(m['post'] is Map ? m : {...m, 'post': m});
          final guid = asInt(m['guid']) > 0 ? asInt(m['guid']) : post.guid;
          final image = kind == 'video' ? iconUrl(m['cover_src'] ?? m['image']) : post.image;
          void open() {
            if (kind == 'video') {
              push(c, ReelPlayerScreen(reels: [
                {...m, 'guid': guid, 'video_src': str(m, 'video_src'), 'cover_src': str(m, 'cover_src'), 'title': str(m, 'title'), 'owner_fullname': str(m, 'owner_fullname')}
              ]));
            } else if (kind == 'post' && post.guid > 0) {
              openPost(c, post);
            } else {
              showMessage(c, kind == 'missing' ? 'This item is no longer available. You can remove it from Saved.' : "This item can't be opened in the app yet.");
            }
          }

          final who = post.poster.fullname.isNotEmpty ? post.poster.fullname : str(m, 'owner_fullname');
          return EvCard(
            padding: EdgeInsets.zero,
            child: ListTile(
              onTap: guid > 0 ? open : null,
              leading: image.isNotEmpty
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Stack(alignment: Alignment.center, children: [
                        CachedNetworkImage(cacheManager: evCache, imageUrl: image, width: 48, height: 48, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2, child: SizedBox(width: 48, height: 48))),
                        if (kind == 'video') const Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 22),
                      ]))
                  : Tile(kind == 'video' ? Icons.play_circle_rounded : (kind == 'missing' ? Icons.hide_source_rounded : Icons.bookmark_rounded), kind == 'missing' ? EvColors.muted : EvColors.ember2),
              title: Text(
                  kind == 'missing'
                      ? 'No longer available'
                      : post.text.isNotEmpty
                          ? post.text
                          : (kind == 'video' ? (str(m, 'title').isEmpty ? 'Video' : str(m, 'title')) : "$who's post"),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis),
              subtitle: Text(kind == 'video' ? (who.isEmpty ? 'Video' : 'Video · $who') : who, style: const TextStyle(color: EvColors.muted, fontSize: 12)),
              trailing: IconButton(
                icon: const Icon(Icons.bookmark_remove_outlined),
                onPressed: guid <= 0
                    ? null
                    : () async {
                        try {
                          await _api.post('bookmarks/remove', {'guid': guid});
                          reload();
                        } catch (e) {
                          if (c.mounted) showMessage(c, '$e');
                        }
                      },
              ),
            ),
          );
        },
      );
}

class TopEarnersScreen extends StatelessWidget {
  const TopEarnersScreen({super.key});
  @override
  Widget build(BuildContext context) => _ListScreen(
        title: 'Top earners',
        method: 'topearners/list',
        fields: const {'limit': 20, 'period': 'month'},
        empty: 'Earnings this month will show here.',
        row: (c, m, _) {
          final u = _userIn(m);
          return EvCard(padding: EdgeInsets.zero, child: ListTile(leading: Avatar(u, size: 42), title: NameLine(u), trailing: Text(naira(asDouble(m['total'] ?? m['amount'] ?? m['earned'])), style: const TextStyle(fontWeight: FontWeight.w700, color: EvColors.green)), onTap: () => openProfile(c, u)));
        },
      );
}

class MyProductsScreen extends StatelessWidget {
  const MyProductsScreen({super.key});
  @override
  Widget build(BuildContext context) => _ListScreen(
        title: 'My products',
        method: 'marketplace/list',
        fields: {'owner_guid': Scope.read(context).current.guid, 'offset': 1},
        empty: 'Products you list for sale appear here.',
        row: (c, m, reload) {
          final p = Product.fromJson(m);
          Future<void> act(String method, String done) async {
            try {
              await _api.post(method, {'guid': p.guid});
              if (c.mounted) showMessage(c, done);
              reload();
            } catch (e) {
              if (c.mounted) showMessage(c, '$e');
            }
          }

          return EvCard(
            padding: EdgeInsets.zero,
            child: ListTile(
              onTap: () => push(c, ProductScreen(product: p)),
              leading: p.cover.isEmpty ? const Tile(Icons.sell_outlined, EvColors.gold) : ClipRRect(borderRadius: BorderRadius.circular(10), child: CachedNetworkImage(cacheManager: evCache, imageUrl: p.cover, width: 48, height: 48, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
              title: Text(p.title, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(p.sold ? 'Sold' : p.priceText, style: TextStyle(color: p.sold ? EvColors.muted : EvColors.ember2, fontWeight: FontWeight.w600)),
              trailing: PopupMenuButton<String>(
                onSelected: (v) => v == 'sold' ? act('marketplace/marksold', 'Marked as sold.') : act('marketplace/delete', 'Listing deleted.'),
                itemBuilder: (_) => [if (!p.sold) const PopupMenuItem(value: 'sold', child: Text('Mark as sold')), const PopupMenuItem(value: 'delete', child: Text('Delete', style: TextStyle(color: EvColors.red)))],
              ),
            ),
          );
        },
      );
}


/// The chosen video, playing silently on a loop, so you see what you picked.
class LocalVideoPreview extends StatefulWidget {
  final File file;
  const LocalVideoPreview(this.file, {super.key});
  @override
  State<LocalVideoPreview> createState() => _LocalVideoPreviewState();
}

class _LocalVideoPreviewState extends State<LocalVideoPreview> {
  late final VideoPlayerController _c = VideoPlayerController.file(widget.file);
  @override
  void initState() {
    super.initState();
    _c
      ..setLooping(true)
      ..setVolume(0)
      ..initialize().then((_) {
        if (mounted) {
          setState(() {});
          _c.play();
        }
      });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => _c.value.isInitialized
      ? Stack(alignment: Alignment.bottomRight, children: [
          Center(child: AspectRatio(aspectRatio: _c.value.aspectRatio, child: VideoPlayer(_c))),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
              child: Text('${_c.value.duration.inMinutes}:${(_c.value.duration.inSeconds % 60).toString().padLeft(2, '0')}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
            ),
          ),
        ])
      : const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4));
}
