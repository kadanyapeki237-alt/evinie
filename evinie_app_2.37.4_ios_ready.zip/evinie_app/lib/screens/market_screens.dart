import '../state/media_cache.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../api/community_api.dart';
import '../api/money_api.dart';
import '../models/community.dart';
import '../models/money.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'money_screens.dart';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({super.key});
  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  List<Product>? _list;
  String _q = '';
  String _sort = 'all';
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final l = await CommunityApi.instance.products(keyword: _sort == 'all' ? '' : _q, sort: _sort == 'all' ? 'newest' : _sort);
      if (mounted) setState(() => _list = l.where((p) => !p.sold).toList());
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('Marketplace'),
          actions: [
            TextButton.icon(onPressed: () => push(context, const OrdersScreen()), icon: const Icon(Icons.receipt_long_rounded, size: 18), label: const Text('My orders')),
            const SizedBox(width: 6),
          ],
        ),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
            child: TextField(
              textInputAction: TextInputAction.search,
              onSubmitted: (v) {
                _q = v.trim();
                setState(() => _list = null);
                _load();
              },
              decoration: const InputDecoration(hintText: 'Search products…', prefixIcon: Icon(Icons.search_rounded)),
            ),
          ),
          SizedBox(
            height: 42,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
              for (final s in [('all', 'All'), ('newest', 'Newest'), ('price_low', 'Lowest price'), ('price_high', 'Highest price')])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(s.$2),
                    selected: _sort == s.$1,
                    selectedColor: EvColors.ink,
                    labelStyle: TextStyle(color: _sort == s.$1 ? Colors.white : EvColors.ink, fontSize: 12.5),
                    onSelected: (_) {
                      setState(() {
                        _sort = s.$1;
                        _list = null;
                      });
                      _load();
                    },
                  ),
                ),
            ]),
          ),
          Expanded(
            child: _error != null
                ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load products", body: _error!, action: 'Try again', onAction: _load)
                : _list == null
                    ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
                    : _list!.isEmpty
                        ? const StateMessage(icon: Icons.storefront_outlined, title: 'Nothing for sale yet', body: 'Try another search, or check back soon.')
                        : RefreshIndicator(
                            color: EvColors.ember2,
                            onRefresh: _load,
                            child: GridView.builder(
                              padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.72),
                              itemCount: _list!.length,
                              itemBuilder: (_, i) => _ProductCard(_list![i]),
                            ),
                          ),
          ),
        ]),
      );
}

class _ProductCard extends StatelessWidget {
  final Product p;
  const _ProductCard(this.p);
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () => push(context, ProductScreen(product: p)),
        child: Container(
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: const [BoxShadow(color: Color(0x0F1F1A17), blurRadius: 14, offset: Offset(0, 6))]),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: p.cover.isEmpty ? Container(color: EvColors.sand2, child: const Center(child: Icon(Icons.image_outlined, color: EvColors.muted))) : CachedNetworkImage(cacheManager: evCache, imageUrl: p.cover, width: double.infinity, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: EvColors.sand2))),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
                Text(p.priceText, style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 14)),
                if (p.location.isNotEmpty) Row(children: [const Icon(Icons.place_outlined, size: 12, color: EvColors.muted), const SizedBox(width: 2), Expanded(child: Text(p.location, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: EvColors.muted, fontSize: 11)))]),
              ]),
            ),
          ]),
        ),
      );
}

class ProductScreen extends StatefulWidget {
  final Product product;
  const ProductScreen({super.key, required this.product});
  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  late Product _p = widget.product;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    CommunityApi.instance.product(_p.guid).then((p) {
      if (mounted && p.guid > 0) setState(() => _p = p);
    }).catchError((_) {});
  }

  Future<void> _buy() async {
    double? balance;
    try {
      balance = await MoneyApi.instance.balance();
    } catch (_) {}
    if (!mounted) return;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Confirm purchase', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Row(children: [Expanded(child: Text(_p.title, style: const TextStyle(fontWeight: FontWeight.w600))), Text(_p.priceText, style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 17))]),
            if (balance != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Paid from your Wallet · balance ${naira(balance)}', style: const TextStyle(color: EvColors.muted, fontSize: 12.5))),
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: EvColors.greenBg, borderRadius: BorderRadius.circular(14)),
              child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.shield_outlined, color: EvColors.green, size: 20),
                SizedBox(width: 8),
                Expanded(child: Text('Protected by Evinie: your payment is held until you confirm you received the item. If something goes wrong, report a problem from My orders.', style: TextStyle(fontSize: 12.5, height: 1.45))),
              ]),
            ),
            const SizedBox(height: 16),
            EmberButton('Pay ${_p.priceText}', onPressed: () => Navigator.pop(context, true)),
          ]),
        ),
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await CommunityApi.instance.buy(_p.guid);
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          icon: const Icon(Icons.check_circle_rounded, color: EvColors.green, size: 48),
          title: const Text('Order placed'),
          content: const Text('The seller has been told. When your item arrives, confirm delivery in My orders to release the payment.', textAlign: TextAlign.center),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
      if (mounted) push(context, const OrdersScreen());
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final mine = Scope.of(context).current.guid == p.owner;
    return Scaffold(
      body: Column(children: [
        Expanded(
          child: CustomScrollView(slivers: [
            SliverAppBar(
              pinned: true,
              expandedHeight: 300,
              backgroundColor: EvColors.sand,
              flexibleSpace: FlexibleSpaceBar(background: p.cover.isEmpty ? Container(color: EvColors.sand2) : CachedNetworkImage(cacheManager: evCache, imageUrl: p.cover, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(p.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 2),
                  Text(p.priceText, style: const TextStyle(color: EvColors.ember2, fontSize: 24, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  EvCard(
                    child: Column(children: [
                      for (final r in [(Icons.sell_outlined, 'Condition', p.type.isEmpty ? '—' : p.type[0].toUpperCase() + p.type.substring(1)), (Icons.category_outlined, 'Category', p.category.isEmpty ? '—' : p.category), (Icons.place_outlined, 'Location', p.location.isEmpty ? '—' : p.location)])
                        Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [Icon(r.$1, size: 18, color: EvColors.ember2), const SizedBox(width: 10), Text(r.$2, style: const TextStyle(color: EvColors.ink2)), const Spacer(), Text(r.$3, style: const TextStyle(fontWeight: FontWeight.w700))])),
                    ]),
                  ),
                  if (p.description.isNotEmpty) ...[const SizedBox(height: 14), const Text('Description', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 4), Text(p.description, style: const TextStyle(height: 1.55, color: EvColors.ink2))],
                ]),
              ),
            ),
          ]),
        ),
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(16, 10, 16, 10 + MediaQuery.of(context).padding.bottom),
          child: mine
              ? const Text('This is your listing.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))
              : p.sold
                  ? const Text('This item has been sold.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontWeight: FontWeight.w600))
                  : EmberButton('Buy now · ${p.priceText}', icon: Icons.shopping_bag_outlined, loading: _busy, onPressed: _buy),
        ),
      ]),
    );
  }
}

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(title: const Text('My orders'), bottom: const TabBar(tabs: [Tab(text: 'Buying'), Tab(text: 'Selling')], labelColor: EvColors.ember2, indicatorColor: EvColors.ember2, unselectedLabelColor: EvColors.muted)),
          body: const TabBarView(children: [_Orders(role: 'buyer'), _Orders(role: 'seller')]),
        ),
      );
}

class _Orders extends StatefulWidget {
  final String role;
  const _Orders({required this.role});
  @override
  State<_Orders> createState() => _OrdersState();
}

class _OrdersState extends State<_Orders> {
  List<Order>? _list;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final all = await CommunityApi.instance.orders(role: widget.role);
      // Buying shows only what I bought, Selling only what I sold (older
      // servers sent every order on both tabs).
      final me = mounted ? Scope.read(context).current.guid : 0;
      final l = all.where((o) {
        final who = widget.role == 'seller' ? o.seller : o.buyer;
        return me == 0 || who == 0 || who == me;
      }).toList();
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  Future<void> _confirm(Order o) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Confirm delivery?'),
        content: const Text('Only confirm once you have the item and it is as described. The payment is then released to the seller.'),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Not yet')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Yes, I have it'))],
      ),
    );
    if (ok != true) return;
    try {
      await CommunityApi.instance.confirmOrder(o.guid);
      if (mounted) showMessage(context, 'Thanks! The seller has been paid.');
      _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  Future<void> _dispute(Order o) async {
    final ctrl = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Report a problem'),
        content: TextField(controller: ctrl, maxLines: 4, decoration: const InputDecoration(hintText: 'What went wrong? For example: not delivered, damaged, not as described.')),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, ctrl.text.trim()), child: const Text('Send'))],
      ),
    );
    ctrl.dispose();
    if (text == null || text.isEmpty) return;
    try {
      await CommunityApi.instance.disputeOrder(o.guid, text);
      if (mounted) showMessage(context, "We've received your report. The payment stays on hold while we look into it.");
      _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load orders", body: _error!, action: 'Try again', onAction: _load);
    if (_list == null) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    if (_list!.isEmpty) return StateMessage(icon: Icons.receipt_long_rounded, title: widget.role == 'buyer' ? 'No purchases yet' : 'No sales yet', body: widget.role == 'buyer' ? 'Items you buy with Buy now will show here.' : 'Orders for your listings will show here.');
    return RefreshIndicator(
      color: EvColors.ember2,
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _list!.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) {
          final o = _list![i];
          final s = o.status.toLowerCase();
          final waiting = !s.contains('complete') && !s.contains('release') && !s.contains('disput') && !s.contains('refund') && !s.contains('cancel');
          return EvCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Expanded(child: Text(o.title.isEmpty ? 'Order #${o.guid}' : o.title, style: const TextStyle(fontWeight: FontWeight.w700))), StatusChip(o.status)]),
              const SizedBox(height: 4),
              Text('${naira(widget.role == 'seller' ? o.net : o.amount)}${widget.role == 'seller' ? ' to you after fees' : ''} · ${timeAgo(o.time)}', style: const TextStyle(color: EvColors.muted, fontSize: 12.5)),
              if (o.complaint.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Problem reported: ${o.complaint}', style: const TextStyle(fontSize: 12.5))),
              if (widget.role == 'buyer' && waiting) ...[
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: SizedBox(height: 40, child: ElevatedButton(onPressed: () => _confirm(o), style: ElevatedButton.styleFrom(backgroundColor: EvColors.green, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('I received it')))),
                  const SizedBox(width: 8),
                  Expanded(child: SizedBox(height: 40, child: OutlinedButton(onPressed: () => _dispute(o), style: OutlinedButton.styleFrom(foregroundColor: EvColors.red, side: const BorderSide(color: EvColors.red), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))), child: const Text('Report a problem')))),
                ]),
              ],
              if (widget.role == 'seller' && waiting) const Padding(padding: EdgeInsets.only(top: 6), child: Text('Deliver the item. You are paid when the buyer confirms.', style: TextStyle(color: EvColors.muted, fontSize: 12))),
            ]),
          );
        },
      ),
    );
  }
}
