import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:record/record.dart';
import 'dart:io';
import 'package:flutter/services.dart';
import '../widgets/post_extras.dart';
import '../state/media_cache.dart';
import '../widgets/feed_extras.dart';
import 'grow_screens.dart';
import 'create_screens.dart';
import '../models/money.dart';
import '../api/more_api.dart';
import '../api/money_api.dart';
import '../api/api_client.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import '../api/evinie_api.dart';
import '../models/models.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import '../widgets/post_card.dart';
import 'feed_screens.dart';
import 'settings_screens.dart';

/// A member's profile: cover, intro, stats and tabs (Timeline, Friends,
/// Photos, eGifts, Videos). Used for "me" as a bottom-bar tab.
class ProfileScreen extends StatefulWidget {
  final EvUser user;
  final bool isTab;
  const ProfileScreen({super.key, required this.user, this.isTab = false});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late EvUser _user = widget.user;
  Map _details = const {};
  List<EvPost>? _posts;
  List<EvUser>? _friends;
  List<GiftEntry>? _gifts;
  List<Map>? _videos;
  int? _friendCount, _views, _postCount;
  bool _earner = false, _creator = false;
  String? _error;
  String _tab = 'Timeline';
  int _page = 0;
  List<EvPost>? _photos;

  bool get _isMe => Scope.read(context).current.guid == _user.guid;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = ApiClient.instance;
    api.post('user_details', {'guid': _user.guid}).then((p) {
      final m = mapOf(p);
      final u = mapOf(m['user']).isNotEmpty ? mapOf(m['user']) : m;
      if (mounted && u.isNotEmpty) {
        setState(() {
          _details = u;
          final parsed = EvUser.fromJson(u);
          if (parsed.guid > 0) _user = parsed;
        });
      }
    }).catchError((_) {});
    // Every friend, page by page; the count is the full list.
    MoneyApi.instance.friends(_user.guid).then((f) {
      if (mounted) {
        setState(() {
          _friends = f;
          _friendCount = f.length;
        });
      }
    }).catchError((_) {});
    // "Creator" tag (EndPoints 4.40), shown on anyone's profile.
    api.post('creators/badge', {'guid': _user.guid}).then((p) {
      if (!mounted) return;
      final b = mapOf(p);
      setState(() {
        _creator = asBool(b['is_creator']);
        // EndPoints 4.42: EviEarner on anyone's profile too.
        if (!_isMe) _earner = asBool(b['is_eviearner']);
      });
    }).catchError((_) {});
    // All posts since joining (EndPoints 4.16.3).
    api.post('wall/count', {'guid': _user.guid}).then((p) {
      if (mounted) setState(() => _postCount = asInt(mapOf(p)['count']));
    }).catchError((_) {});
    if (_isMe) {
      api.post('profileviews/list', {'limit': 1}).then((p) {
        if (mounted) setState(() => _views = asInt(mapOf(p)['count']));
      }).catchError((_) {});
      MoneyApi.instance.myTier().then((t) {
        if (mounted) setState(() => _earner = t.canMonetize);
      }).catchError((_) {});
    }
    try {
      final p = await EvinieApi.instance.userFeed(_user.guid, Scope.read(context).current.guid, 1);
      if (mounted) setState(() => _posts = p);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  void _openTab(String t) {
    setState(() {
      _tab = t;
      _page = 0;
    });
    if (t == 'Photos' && _photos == null) _loadAllPhotos();
    if (t == 'Friends' && _friends == null) {
      MoneyApi.instance.friends(_user.guid).then((f) {
        if (mounted) setState(() => _friends = f);
      }).catchError((_) {
        if (mounted) setState(() => _friends = []);
      });
    }
    if (t == 'eGifts' && _gifts == null) {
      MoneyApi.instance.giftsReceived().then((g) {
        if (mounted) setState(() => _gifts = g);
      }).catchError((_) {
        if (mounted) setState(() => _gifts = []);
      });
    }
    if (t == 'Videos' && _videos == null) {
      ApiClient.instance.post('video/list', {'guid': _user.guid, 'container_guid': _user.guid, 'container_type': 'user'}).then((p) {
        final m = mapOf(p);
        if (mounted) setState(() => _videos = listOf(m['list'] ?? m['videos'] ?? p));
      }).catchError((_) {
        if (mounted) setState(() => _videos = []);
      });
    }
  }

  /// Every photo on the profile: walks all pages of the timeline.
  Future<void> _loadAllPhotos() async {
    final me = Scope.read(context).current.guid;
    final all = <EvPost>[];
    final seen = <int>{};
    for (var page = 1; page <= 60; page++) {
      try {
        final batch = await EvinieApi.instance.userFeed(_user.guid, me, page);
        final fresh = batch.where((p) => seen.add(p.guid)).toList();
        if (fresh.isEmpty) break;
        all.addAll(fresh.where((p) => p.image.isNotEmpty));
        if (mounted && page % 3 == 0) setState(() => _photos = List.of(all));
      } catch (_) {
        break;
      }
    }
    if (mounted) setState(() => _photos = all);
  }

  Widget _stat(IconData icon, Color c, String value, String label, {VoidCallback? onTap}) => Expanded(
        child: GestureDetector(
          onTap: onTap,
          child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: EvColors.line)),
          child: Column(children: [
            Container(width: 40, height: 40, decoration: BoxDecoration(color: c.withValues(alpha: 0.12), shape: BoxShape.circle), child: Icon(icon, color: c, size: 20)),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            Text(label, style: const TextStyle(color: EvColors.muted, fontSize: 12)),
          ]),
        ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final session = Scope.of(context);
    final isMe = session.current.guid == _user.guid;
    final cover = iconUrl(_details['cover'] ?? _details['cover_url'] ?? _details['cover_photo']);
    final place = [str(_details, 'city'), str(_details, 'country', str(_details, 'location'))].where((x) => x.isNotEmpty).join(', ');
    final gender = str(_details, 'gender');
    final birth = str(_details, 'birthdate');
    // The phone number is for signing in; only the owner sees it.
    final phone = isMe ? str(_details, 'phone', str(_details, 'mobile')) : '';
    final state = [str(_details, 'state'), str(_details, 'country')].where((x) => x.isNotEmpty).join(', ');
    final marital = str(_details, 'marital_status', str(_details, 'relationship'));
    final language = str(_details, 'language');
    final postCount = asInt(_details['total_posts'] ?? _details['posts']);
    final images = (_posts ?? <EvPost>[]).where((p) => p.image.isNotEmpty).toList();
    const tabs = ['Timeline', 'Friends', 'Photos', 'eGifts', 'Videos'];
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: !widget.isTab,
        title: Text(isMe ? 'Profile' : _user.firstName),
        actions: [
          if (isMe) IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()))),
          if (!isMe) PopupMenuButton<String>(onSelected: (_) => blockUser(context, _user), itemBuilder: (_) => const [PopupMenuItem(value: 'block', child: Text('Block'))]),
        ],
      ),
      body: RefreshIndicator(
        color: EvColors.ember2,
        onRefresh: _load,
        child: ListView(padding: EdgeInsets.zero, children: [
          Stack(clipBehavior: Clip.none, children: [
            SizedBox(
              height: 170,
              width: double.infinity,
              child: cover.isEmpty
                  ? const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFFFB27A), EvColors.ember2])))
                  : CachedNetworkImage(cacheManager: evCache, imageUrl: cover, fit: BoxFit.cover, errorWidget: (_, __, ___) => const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFFFB27A), EvColors.ember2])))),
            ),
            Positioned(
              left: 16,
              bottom: -52,
              child: GestureDetector(
                onTap: isMe ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EditProfileScreen())) : null,
                child: Stack(children: [
                  Container(padding: const EdgeInsets.all(4), decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle), child: Avatar(_user, size: 104)),
                  if (isMe) const Positioned(right: 6, bottom: 6, child: CircleAvatar(radius: 15, backgroundColor: EvColors.ember2, child: Icon(Icons.photo_camera_rounded, size: 16, color: Colors.white))),
                ]),
              ),
            ),
          ]),
          const SizedBox(height: 60),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              NameLine(_user, size: 22),
              const SizedBox(height: 4),
              Row(children: [
                if (_user.username.isNotEmpty) Flexible(child: Text('@${_user.username}', overflow: TextOverflow.ellipsis, style: const TextStyle(color: EvColors.muted, fontSize: 14))),
                if (_creator) ...[
                  const SizedBox(width: 8),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: EvColors.ember2, borderRadius: BorderRadius.circular(20)), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 13), SizedBox(width: 4), Text('Creator', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700))])),
                ],
                if (_earner) ...[
                  const SizedBox(width: 8),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: EvColors.green, borderRadius: BorderRadius.circular(20)), child: const Text('EviEarner', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700))),
                ],
              ]),
              if (!isMe) ...[
                const SizedBox(height: 12),
                Padding(padding: const EdgeInsets.only(bottom: 10), child: OnlineLine(_user.guid)),
                Row(children: [
                  Expanded(child: EmberButton('Message', icon: Icons.chat_bubble_outline_rounded, onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(withUser: _user))))),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                    onPressed: () async {
                      try {
                        await ApiClient.instance.post('poke/send', {'user': _user.guid});
                        if (context.mounted) showMessage(context, 'You poked ${_user.firstName} 👉');
                      } catch (e) {
                        if (context.mounted) showMessage(context, '$e');
                      }
                    },
                    icon: const Text('👉'),
                    label: const Text('Poke'),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton(
                    style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10), minimumSize: const Size(44, 40)),
                    onPressed: () async {
                      final pick = await showModalBottomSheet<String>(
                        context: context,
                        backgroundColor: Colors.white,
                        builder: (s) => SafeArea(
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            ListTile(leading: const Icon(Icons.block_rounded, color: EvColors.red), title: Text('Block ${_user.firstName}'), subtitle: const Text("They won't be able to see your profile or message you."), onTap: () => Navigator.pop(s, 'block')),
                          ]),
                        ),
                      );
                      if (pick == 'block' && context.mounted) await blockUser(context, _user);
                    },
                    child: const Icon(Icons.more_horiz_rounded),
                  ),
                ]),
              ],
              if (place.isNotEmpty || gender.isNotEmpty || birth.isNotEmpty || phone.isNotEmpty || marital.isNotEmpty || language.isNotEmpty) ...[
                const SizedBox(height: 14),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: EvColors.line)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('INTRO', style: TextStyle(color: EvColors.muted, fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: 0.6)),
                    const SizedBox(height: 10),
                    if (place.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [const Icon(Icons.place_outlined, size: 18, color: EvColors.muted), const SizedBox(width: 8), const Text('Lives in '), Text(place, style: const TextStyle(fontWeight: FontWeight.w700))])),
                    if (gender.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 8), child: Row(children: [Icon(gender.toLowerCase() == 'female' ? Icons.female_rounded : Icons.male_rounded, size: 18, color: EvColors.muted), const SizedBox(width: 8), Text(gender)])),
                    if (isMe && birth.isNotEmpty) Row(children: [const Icon(Icons.calendar_today_outlined, size: 16, color: EvColors.muted), const SizedBox(width: 8), Text(birth)]),
                    if (state.isNotEmpty && state != place) Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [const Icon(Icons.map_outlined, size: 17, color: EvColors.muted), const SizedBox(width: 8), Expanded(child: Text('From $state'))])),
                    if (marital.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [const Icon(Icons.favorite_border_rounded, size: 17, color: EvColors.muted), const SizedBox(width: 8), Text(marital)])),
                    if (language.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [const Icon(Icons.translate_rounded, size: 17, color: EvColors.muted), const SizedBox(width: 8), Text(language)])),
                    if (phone.isNotEmpty && isMe) Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [const Icon(Icons.phone_outlined, size: 17, color: EvColors.muted), const SizedBox(width: 8), Text(phone)])),
                    if (isMe && str(_details, 'email').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [const Icon(Icons.mail_outline_rounded, size: 17, color: EvColors.muted), const SizedBox(width: 8), Expanded(child: Text(str(_details, 'email')))])),
                  ]),
                ),
              ],
              const SizedBox(height: 12),
              Row(children: [
                _stat(Icons.dynamic_feed_rounded, EvColors.ember2, '${_postCount ?? (postCount > 0 ? postCount : (_posts?.length ?? 0))}', 'Posts'),
                const SizedBox(width: 8),
                _stat(Icons.people_outline_rounded, EvColors.blue, _friendCount == null ? '–' : '$_friendCount', 'Friends'),
                if (isMe) ...[const SizedBox(width: 8), _stat(Icons.visibility_outlined, EvColors.gold, _views == null ? '–' : '$_views', 'Profile views', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ProfileViewsScreen())))],
              ]),
            ]),
          ),
          const SizedBox(height: 14),
          SizedBox(
            height: 42,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
              for (final t in tabs)
                if (t != 'eGifts' || isMe)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(label: Text(t), selected: _tab == t, onSelected: (_) => _openTab(t), selectedColor: EvColors.ink, labelStyle: TextStyle(color: _tab == t ? Colors.white : EvColors.ink2, fontWeight: FontWeight.w600), side: const BorderSide(color: EvColors.line)),
                  ),
            ]),
          ),
          const SizedBox(height: 10),
          ..._tabBody(isMe, images),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }

  List<Widget> _tabBody(bool isMe, List<EvPost> images) {
    Widget loading() => const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    Widget empty(String t) => Padding(padding: const EdgeInsets.all(24), child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted)));
    Widget grid(List<Widget> items) => GridView.count(crossAxisCount: 3, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), padding: const EdgeInsets.symmetric(horizontal: 16), mainAxisSpacing: 6, crossAxisSpacing: 6, children: items);
    List<Widget> paged(List<Widget> items) {
      const per = 50;
      final pages = (items.length / per).ceil();
      final page = _page.clamp(0, pages == 0 ? 0 : pages - 1);
      final slice = items.skip(page * per).take(per).toList();
      return [
        grid(slice),
        if (pages > 1)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(onPressed: page > 0 ? () => setState(() => _page = page - 1) : null, icon: const Icon(Icons.chevron_left_rounded)),
              Text('Page ${page + 1} of $pages · ${items.length} in total', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
              IconButton(onPressed: page < pages - 1 ? () => setState(() => _page = page + 1) : null, icon: const Icon(Icons.chevron_right_rounded)),
            ]),
          ),
      ];
    }

    switch (_tab) {
      case 'Friends':
        if (_friends == null) return [loading()];
        if (_friends!.isEmpty) return [empty('No friends to show yet.')];
        return paged([for (final f in _friends!) GestureDetector(onTap: () => openProfile(context, f), child: Column(children: [Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(14), child: SizedBox(width: double.infinity, child: f.icon.isEmpty ? Avatar(f, size: 80) : CachedNetworkImage(cacheManager: evCache, imageUrl: f.icon, fit: BoxFit.cover, errorWidget: (_, __, ___) => Avatar(f, size: 80))))), const SizedBox(height: 4), Text(f.firstName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))]))]);
      case 'Photos':
        if (_photos == null) return [loading()];
        if (_photos!.isEmpty) return [empty('No photos yet.')];
        return paged([for (final p in _photos!) GestureDetector(onTap: () => openPost(context, p), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: CachedNetworkImage(cacheManager: evCache, imageUrl: p.image, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))))]);
      case 'eGifts':
        if (_gifts == null) return [loading()];
        if (_gifts!.isEmpty) return [empty('No eGifts received yet.')];
        return [grid([for (final g in _gifts!) Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [SizedBox(width: 44, height: 44, child: g.icon.isEmpty ? const Icon(Icons.card_giftcard_rounded, color: EvColors.ember2, size: 34) : CachedNetworkImage(cacheManager: evCache, imageUrl: g.icon, errorWidget: (_, __, ___) => const Icon(Icons.card_giftcard_rounded, color: EvColors.ember2))), const SizedBox(height: 4), Text(g.other?.firstName ?? g.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w600))]))])];
      case 'Videos':
        if (_videos == null) return [loading()];
        if (_videos!.isEmpty) return [empty('No videos yet.')];
        return paged([for (final v in _videos!) GestureDetector(onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReelPlayerScreen(reels: [{'guid': asInt(v['guid']), 'video_src': str(v, 'file:video', str(v, 'url', str(v, 'video', str(v, 'file', str(v, 'video_src'))))), 'cover_src': str(v, 'file:cover', str(v, 'cover')), 'title': str(v, 'title'), 'owner_fullname': _user.fullname}]))), child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Stack(fit: StackFit.expand, children: [CachedNetworkImage(cacheManager: evCache, imageUrl: iconUrl(v['file:cover'] ?? v['cover'] ?? v['thumbnail'] ?? v['image'] ?? v['poster']), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.ink)), const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 34))])))]);
      default:
        return [
          if (isMe)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
              child: GestureDetector(
                onTap: () => showCreateSheet(context),
                child: Row(children: [Avatar(_user, size: 40), const SizedBox(width: 10), Expanded(child: Container(height: 44, alignment: Alignment.centerLeft, padding: const EdgeInsets.symmetric(horizontal: 16), decoration: BoxDecoration(color: const Color(0xFFEDEBFA), borderRadius: BorderRadius.circular(22)), child: const Text("What's on your mind?", style: TextStyle(color: EvColors.muted))))]),
              ),
            ),
          if (_posts == null && _error == null) const PostSkeleton(),
          if (_error != null) StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load posts", body: _error!, action: 'Try again', onAction: _load),
          if (_posts != null && _posts!.isEmpty) empty(isMe ? 'Share something with your friends.' : '${_user.firstName} hasn\'t posted yet.'),
          for (final p in _posts ?? <EvPost>[]) PostCard(p, onOpen: () => openPost(context, p)),
        ];
    }
  }
}

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<EvNotification>? _list;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await EvinieApi.instance.notifications(Scope.read(context).current.guid, 1);
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  ({Color bg, Color fg, IconData icon}) _style(String type) {
    if (type.startsWith('like')) return (bg: EvColors.redBg, fg: EvColors.red, icon: Icons.favorite_rounded);
    if (type.startsWith('comments')) return (bg: EvColors.blueBg, fg: EvColors.blue, icon: Icons.chat_bubble_rounded);
    if (type.contains('friend')) return (bg: EvColors.greenBg, fg: EvColors.green, icon: Icons.person_add_rounded);
    if (type.contains('gift')) return (bg: const Color(0xFFFFF4DF), fg: const Color(0xFFC77D06), icon: Icons.card_giftcard_rounded);
    return (bg: EvColors.peach, fg: EvColors.ember2, icon: Icons.notifications_rounded);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Notifications')),
        body: _list == null && _error == null
            ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
            : _error != null
                ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load notifications", body: _error!, action: 'Try again', onAction: _load)
                : _list!.isEmpty
                    ? const StateMessage(icon: Icons.notifications_none_rounded, title: "You're all caught up", body: 'Likes, comments and friend requests will show up here.')
                    : RefreshIndicator(
                        color: EvColors.ember2,
                        onRefresh: _load,
                        child: ListView.separated(
                          itemCount: _list!.length,
                          separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
                          itemBuilder: (_, i) {
                            final n = _list![i];
                            final st = _style(n.type);
                            return Container(
                              color: n.viewed ? Colors.white : const Color(0xFFFFF7F2),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                                onTap: () => openProfile(context, n.poster),
                                leading: Stack(clipBehavior: Clip.none, children: [
                                  Avatar(n.poster, size: 44),
                                  Positioned(right: -4, bottom: -4, child: Container(width: 22, height: 22, decoration: BoxDecoration(color: st.bg, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)), child: Icon(st.icon, size: 11, color: st.fg))),
                                ]),
                                title: Text.rich(TextSpan(children: [TextSpan(text: n.poster.fullname, style: const TextStyle(fontWeight: FontWeight.w700)), TextSpan(text: ' ${n.action}.')]), style: const TextStyle(fontSize: 13.5, height: 1.4)),
                                subtitle: Text(timeAgo(n.time), style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
                              ),
                            );
                          },
                        ),
                      ),
      );
}

class InboxScreen extends StatefulWidget {
  const InboxScreen({super.key});
  @override
  State<InboxScreen> createState() => _InboxScreenState();
}

class _InboxScreenState extends State<InboxScreen> {
  List<EvMessage>? _list;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await EvinieApi.instance.recentChats(Scope.read(context).current.guid);
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Scaffold(
      appBar: AppBar(title: const Text('Messages')),
      body: _list == null && _error == null
          ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
          : _error != null
              ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load messages", body: _error!, action: 'Try again', onAction: _load)
              : _list!.isEmpty
                  ? const StateMessage(icon: Icons.chat_bubble_outline_rounded, title: 'No messages yet', body: 'Open a friend\'s profile and tap Message to start a chat.')
                  : RefreshIndicator(
                      color: EvColors.ember2,
                      onRefresh: _load,
                      child: ListView.separated(
                        itemCount: _list!.length,
                        separatorBuilder: (_, __) => const Divider(height: 1, indent: 76),
                        itemBuilder: (_, i) {
                          final m = _list![i];
                          final other = m.from.guid == me.guid ? m.to : m.from;
                          final unread = !m.viewed && m.from.guid != me.guid;
                          return ListTile(
                            tileColor: Colors.white,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                            leading: Avatar(other, size: 48),
                            title: NameLine(other, size: 14),
                            subtitle: Text(
                              '${m.from.guid == me.guid ? 'You: ' : ''}${m.text}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: unread ? EvColors.ink : EvColors.muted, fontWeight: unread ? FontWeight.w600 : FontWeight.w400, fontSize: 12.5),
                            ),
                            trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text(timeAgo(m.time), style: const TextStyle(color: EvColors.muted, fontSize: 11)),
                              if (unread) Container(margin: const EdgeInsets.only(top: 5), width: 9, height: 9, decoration: const BoxDecoration(color: EvColors.ember2, shape: BoxShape.circle)),
                            ]),
                            onTap: () async {
                              await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(withUser: other)));
                              _load();
                            },
                            // Press and hold: delete the whole chat (from your side only).
                            onLongPress: () async {
                              final ok = await showDialog<bool>(
                                context: context,
                                builder: (d) => AlertDialog(
                                  title: Text('Delete chat with ${other.firstName}?'),
                                  content: Text('It will be removed from your inbox. ${other.firstName} will still see their copy.'),
                                  actions: [
                                    TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                                    TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete', style: TextStyle(color: EvColors.red))),
                                  ],
                                ),
                              );
                              if (ok != true || !context.mounted) return;
                              try {
                                await ApiClient.instance.post('conversation/delete', {'with_guid': other.guid});
                                if (mounted) setState(() => _list!.remove(m));
                              } catch (e) {
                                if (context.mounted) showMessage(context, '$e');
                              }
                            },
                          );
                        },
                      ),
                    ),
    );
  }
}

/// A conversation. New messages are checked every 8 seconds while open.
class ChatScreen extends StatefulWidget {
  final EvUser withUser;
  const ChatScreen({super.key, required this.withUser});

  /// Who the open chat is with, so no phone notification rings for it.
  static int? openWith;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  /// Press and hold a message: delete it for you, or (your own) for both.
  Future<void> _messageOptions(EvMessage m, bool mine) async {
    final pick = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      builder: (s) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.copy_rounded), title: const Text('Copy text'), onTap: () => Navigator.pop(s, 'copy')),
          ListTile(leading: const Icon(Icons.delete_outline_rounded, color: EvColors.red), title: const Text('Delete for me'), onTap: () => Navigator.pop(s, 'me')),
          if (mine) ListTile(leading: const Icon(Icons.delete_forever_rounded, color: EvColors.red), title: const Text('Delete for everyone'), onTap: () => Navigator.pop(s, 'all')),
        ]),
      ),
    );
    if (!mounted || pick == null) return;
    if (pick == 'copy') {
      await Clipboard.setData(ClipboardData(text: m.text));
      if (mounted) showMessage(context, 'Copied.');
      return;
    }
    final i = _messages.indexOf(m);
    setState(() => _messages.remove(m));
    try {
      await ApiClient.instance.post('message/delete', {'id': m.id, 'with_guid': widget.withUser.guid, if (pick == 'all') 'everyone': 1});
    } catch (e) {
      if (mounted) {
        setState(() => _messages.insert(i.clamp(0, _messages.length), m));
        showMessage(context, '$e');
      }
    }
  }

  /// Clears the whole chat from YOUR side (the other person keeps theirs),
  /// the same as deleting a conversation on the website.
  Future<void> _deleteChat() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Delete this chat?'),
        content: Text('All messages with ${widget.withUser.firstName} will be removed from your inbox. ${widget.withUser.firstName} will still see their copy.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete', style: TextStyle(color: EvColors.red))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    try {
      await ApiClient.instance.post('conversation/delete', {'with_guid': widget.withUser.guid});
      if (!mounted) return;
      showMessage(context, 'Chat deleted.');
      Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  final _text = TextEditingController();
  final _scroll = ScrollController();
  List<EvMessage> _messages = [];
  bool _loading = true;
  bool _sending = false;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    ChatScreen.openWith = widget.withUser.guid;
    _load();
    _poll = Timer.periodic(const Duration(seconds: 8), (_) => _load(quiet: true));
  }

  @override
  void dispose() {
    if (ChatScreen.openWith == widget.withUser.guid) ChatScreen.openWith = null;
    _poll?.cancel();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load({bool quiet = false}) async {
    try {
      final l = await EvinieApi.instance.chat(Scope.read(context).current.guid, widget.withUser.guid);
      l.sort((a, b) => a.time.compareTo(b.time));
      if (!mounted) return;
      final grew = l.length != _messages.length;
      setState(() {
        _messages = l;
        _loading = false;
      });
      if (grew) _toBottom();
    } catch (e) {
      if (!mounted) return;
      setState(() => _loading = false);
      if (!quiet) showMessage(context, '$e');
    }
  }

  void _toBottom() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  final _rec = AudioRecorder();
  bool _recording = false;

  /// Voice note: tap to record (WAV, as the server expects), tap again to send.
  Future<void> _toggleVoice() async {
    if (_recording) {
      final path = await _rec.stop();
      setState(() => _recording = false);
      if (path != null) await _sendFile(File(path), 'Voice note');
      return;
    }
    if (!await _rec.hasPermission()) {
      if (mounted) showMessage(context, 'Allow microphone access to record voice notes.');
      return;
    }
    final dir = await getTemporaryDirectory();
    await _rec.start(const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 16000, numChannels: 1), path: '${dir.path}/voice_${DateTime.now().millisecondsSinceEpoch}.wav');
    setState(() => _recording = true);
  }

  Future<void> _attach() async {
    final pick = await showModalBottomSheet<String>(context: context, backgroundColor: Colors.white, builder: (s) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_outlined, color: EvColors.green), title: const Text('Photo'), onTap: () => Navigator.pop(s, 'photo')),
          ListTile(leading: const Icon(Icons.description_outlined, color: EvColors.blue), title: const Text('Document (PDF or Word)'), onTap: () => Navigator.pop(s, 'doc')),
        ])));
    if (pick == 'photo') {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
      if (x != null) await _sendFile(File(x.path), 'Photo');
    } else if (pick == 'doc') {
      final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'docx']);
      final path = r?.files.single.path;
      if (path != null) await _sendFile(File(path), 'Document');
    }
  }

  Future<void> _sendFile(File f, String label) async {
    setState(() => _sending = true);
    try {
      await ApiClient.instance.upload('message/attach', {'to': widget.withUser.guid, 'message': _text.text.trim()}, 'attachment', f);
      _text.clear();
      await _load(quiet: true);
      if (mounted) showMessage(context, '$label sent.');
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _send() async {
    final text = _text.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final m = await EvinieApi.instance.sendMessage(Scope.read(context).current.guid, widget.withUser.guid, text);
      _text.clear();
      if (mounted) setState(() => _messages.add(m));
      _toBottom();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: GestureDetector(
          onTap: () => openProfile(context, widget.withUser),
          child: Row(children: [Avatar(widget.withUser, size: 36), const SizedBox(width: 10), Expanded(child: NameLine(widget.withUser, size: 15))]),
        ),
      actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'profile') openProfile(context, widget.withUser);
              if (v == 'delete') _deleteChat();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'profile', child: Text('View profile')),
              PopupMenuItem(value: 'delete', child: Text('Delete chat', style: TextStyle(color: EvColors.red))),
            ],
          ),
        ]),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
              : _messages.isEmpty
                  ? StateMessage(icon: Icons.waving_hand_outlined, title: 'Say hello', body: 'This is the start of your chat with ${widget.withUser.firstName}.')
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
                      itemCount: _messages.length,
                      itemBuilder: (_, i) {
                        final m = _messages[i];
                        final mine = m.from.guid == me.guid;
                        return Align(
                          alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                          child: GestureDetector(
                           onLongPress: m.id > 0 ? () => _messageOptions(m, mine) : null,
                           child: Container(
                            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.76),
                            margin: const EdgeInsets.only(bottom: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                            decoration: BoxDecoration(
                              gradient: mine ? EvColors.emberGradient : null,
                              color: mine ? null : Colors.white,
                              borderRadius: BorderRadius.only(topLeft: const Radius.circular(18), topRight: const Radius.circular(18), bottomLeft: Radius.circular(mine ? 18 : 5), bottomRight: Radius.circular(mine ? 5 : 18)),
                            ),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text(m.text, style: TextStyle(color: mine ? Colors.white : EvColors.ink, fontSize: 14, height: 1.4)),
                              const SizedBox(height: 3),
                              Text(timeAgo(m.time), style: TextStyle(color: mine ? Colors.white70 : EvColors.muted, fontSize: 10)),
                            ]),
                          ),
                          ),
                        );
                      },
                    ),
        ),
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(12, 8, 12, 8 + MediaQuery.of(context).padding.bottom),
          child: Row(children: [
            IconButton(tooltip: 'Attach a photo or document', onPressed: _sending ? null : _attach, icon: const Icon(Icons.attach_file_rounded, color: EvColors.muted)),
            IconButton(tooltip: _recording ? 'Stop and send' : 'Record a voice note', onPressed: _sending ? null : _toggleVoice, icon: Icon(_recording ? Icons.stop_circle_rounded : Icons.mic_rounded, color: _recording ? EvColors.red : EvColors.ember2)),
            Expanded(
              child: TextField(
                controller: _text,
                minLines: 1,
                maxLines: 5,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(hintText: _recording ? 'Recording… tap stop to send' : 'Type a message…', filled: true, fillColor: EvColors.sand, contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10), border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none)),
              ),
            ),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: _sending ? null : _send,
              child: Container(
                width: 44,
                height: 44,
                decoration: const BoxDecoration(shape: BoxShape.circle, gradient: EvColors.emberGradient),
                child: _sending ? const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
              ),
            ),
          ]),
        ),
      ]),
    );
  }
}
