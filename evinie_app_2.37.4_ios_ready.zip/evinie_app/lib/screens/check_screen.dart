import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../config.dart';
import '../theme/colors.dart';

/// "Check connection": harmless test calls (no account is created and no
/// password is sent) that show exactly what the server replies.
class CheckScreen extends StatefulWidget {
  const CheckScreen({super.key});
  @override
  State<CheckScreen> createState() => _CheckScreenState();
}

class _CheckScreenState extends State<CheckScreen> {
  final _rows = <(String, String, bool)>[];
  bool _busy = true;

  @override
  void initState() {
    super.initState();
    _run();
  }

  Future<(String, bool)> _call(String url, Map<String, String> body) async {
    try {
      final res = await http.post(Uri.parse(url), headers: {'Accept': 'application/json'}, body: body).timeout(const Duration(seconds: 15));
      try {
        final j = jsonDecode(res.body);
        if (j is Map) {
          final msg = '${j['message']}';
          return ('code ${j['code']}: $msg', !msg.toLowerCase().contains('invalid method'));
        }
      } catch (_) {}
      final snippet = res.body.replaceAll(RegExp(r'\s+'), ' ');
      return ('HTTP ${res.statusCode}, not an API reply: ${snippet.substring(0, snippet.length > 120 ? 120 : snippet.length)}', false);
    } catch (e) {
      return ('No reply: $e', false);
    }
  }

  Future<void> _run() async {
    setState(() {
      _rows.clear();
      _busy = true;
    });
    _rows.add(('Server', AppConfig.siteUrl, AppConfig.siteUrl.startsWith('https://')));
    _rows.add(('API key in this build', AppConfig.apiKey.isEmpty ? 'MISSING' : 'set (${AppConfig.apiKey.length} characters)', AppConfig.apiKey.isNotEmpty));
    final site = await _call(AppConfig.siteUrl, {});
    _rows.add(('Website reachable', site.$1.startsWith('No reply') ? site.$1 : 'yes', !site.$1.startsWith('No reply')));
    for (final v in AppConfig.apiVersions) {
      final base = '${AppConfig.siteUrl}/api/$v';
      final login = await _call('$base/auth/login', {'api_key_token': AppConfig.apiKey});
      final signup = await _call('$base/user_add', {'api_key_token': AppConfig.apiKey});
      _rows.add(('$v · sign-in (auth/login)', login.$1, login.$2));
      _rows.add(('$v · sign-up (user_add)', signup.$1, signup.$2));
      final feed = await _call('$base/wall_list_home', {'api_key_token': AppConfig.apiKey});
      _rows.add(('$v · feed (wall_list_home)', feed.$1, feed.$2));
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Check connection')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Test calls only: nothing is created and no password is sent. Each method only needs a green tick on one version: the app uses whichever version answers. "Invalid method" on every line means EndPoints 4.16 is not installed or enabled on this server.', style: TextStyle(color: EvColors.muted, fontSize: 12.5, height: 1.45)),
          const SizedBox(height: 12),
          for (final r in _rows)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
              child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(r.$3 ? Icons.check_circle_rounded : Icons.cancel_rounded, color: r.$3 ? EvColors.green : EvColors.red, size: 20),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.$1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)), const SizedBox(height: 2), SelectableText(r.$2, style: const TextStyle(fontSize: 12.5, height: 1.4))])),
              ]),
            ),
          if (_busy) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))),
          if (!_busy) TextButton.icon(onPressed: _run, icon: const Icon(Icons.refresh_rounded), label: const Text('Run again')),
          if (!_busy) const Text('Take a screenshot of this screen and send it to support.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontSize: 12)),
        ]),
      );
}
