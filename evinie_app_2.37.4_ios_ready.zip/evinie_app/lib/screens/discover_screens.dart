import '../state/media_cache.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'create_screens.dart';
import '../api/money_api.dart';
import 'package:share_plus/share_plus.dart';
import '../api/more_api.dart';
import '../widgets/feed_extras.dart';
import 'business_screens.dart';
import '../api/api_client.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../api/community_api.dart';
import '../models/community.dart';
import '../models/models.dart';
import '../models/money.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import '../widgets/post_card.dart';
import 'feed_screens.dart';
import 'money_screens.dart';
import 'health_screens.dart' show HealthHome;
import 'market_screens.dart' show MarketplaceScreen;

Widget _loading() => const Center(child: Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));

Widget _sec(String title, {VoidCallback? onAll}) => Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
      child: Row(children: [
        Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15.5))),
        if (onAll != null) GestureDetector(onTap: onAll, child: const Text('See all', style: TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 12.5))),
      ]),
    );

Widget _img(String url, {double? h, double? w, double r = 14}) => ClipRRect(
      borderRadius: BorderRadius.circular(r),
      child: url.isEmpty
          ? Container(height: h, width: w, color: EvColors.sand2, child: const Icon(Icons.image_outlined, color: EvColors.muted))
          : CachedNetworkImage(cacheManager: evCache, imageUrl: url, height: h, width: w, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(height: h, width: w, color: EvColors.sand2)),
    );

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});
  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen> {
  List<Trend>? _trends;
  List<EvUser>? _people;
  List<Group>? _groups;
  List<EventItem>? _events;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = CommunityApi.instance;
    await Future.wait([
      api.trending().then((v) => _trends = v).catchError((_) => _trends = <Trend>[]),
      api.suggestions().then((v) => _people = v).catchError((_) => _people = <EvUser>[]),
      api.groups().then((v) => _groups = v).catchError((_) => _groups = <Group>[]),
      api.events().then((v) => _events = v.where((e) => !e.finished).toList()).catchError((_) => _events = <EventItem>[]),
    ]);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Discover')),
        body: RefreshIndicator(
          color: EvColors.ember2,
          onRefresh: _load,
          child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
            const EarnHighlights(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(spacing: 8, runSpacing: 8, children: [
                for (final x in [('Groups', Icons.groups_rounded, const GroupsScreen()), ('Events', Icons.event_rounded, const EventsScreen()), ('Polls', Icons.bar_chart_rounded, const PollsScreen()), ('Pages', Icons.flag_rounded, const PagesScreen()), ('Marketplace', Icons.storefront_rounded, const MarketplaceScreen()), ('iHealth Assist', Icons.health_and_safety_rounded, const HealthHome()), ('Get Verified', Icons.verified_rounded, const GetVerifiedScreen())])
                  ActionChip(avatar: Icon(x.$2, size: 17, color: EvColors.ember2), label: Text(x.$1), backgroundColor: Colors.white, side: const BorderSide(color: EvColors.line), onPressed: () => push(context, x.$3)),
              ]),
            ),
            _sec('Trending now'),
            if (_trends == null) _loading(),
            if ((_trends ?? []).isEmpty && _trends != null) const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('Nothing trending yet.', style: TextStyle(color: EvColors.muted))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Wrap(spacing: 8, runSpacing: 8, children: [
                for (final t in _trends ?? <Trend>[])
                  InkWell(
                    onTap: () => push(context, HashtagScreen(tag: t.tag, total: t.total)),
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: EvColors.line)),
                      child: Text.rich(TextSpan(children: [TextSpan(text: '#${t.tag}', style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700)), TextSpan(text: '  ${t.total} posts', style: const TextStyle(color: EvColors.muted, fontSize: 11.5))])),
                    ),
                  ),
              ]),
            ),
            if ((_people ?? []).isNotEmpty) ...[
              _sec('People you may know'),
              SizedBox(
                height: 150,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _people!.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (_, i) => GestureDetector(
                    onTap: () => openProfile(context, _people![i]),
                    child: SizedBox(width: 118, child: EvCard(padding: const EdgeInsets.all(12), child: Column(children: [Avatar(_people![i], size: 56), const SizedBox(height: 8), Text(_people![i].fullname, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)), const Text('View profile', style: TextStyle(color: EvColors.ember2, fontSize: 11.5, fontWeight: FontWeight.w600))]))),
                  ),
                ),
              ),
            ],
            _sec('Groups', onAll: () => push(context, const GroupsScreen())),
            if (_groups == null) _loading(),
            for (final g in (_groups ?? <Group>[]).take(3)) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 8), child: GroupTile(g)),
            _sec('Upcoming events', onAll: () => push(context, const EventsScreen())),
            if (_events == null) _loading(),
            if ((_events ?? []).isEmpty && _events != null) const Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Text('No upcoming events.', style: TextStyle(color: EvColors.muted))),
            for (final e in (_events ?? <EventItem>[]).take(2)) Padding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 10), child: EventCard(e)),
          ]),
        ),
      );
}

class HashtagScreen extends StatefulWidget {
  final String tag;
  final int total;
  const HashtagScreen({super.key, required this.tag, this.total = 0});
  @override
  State<HashtagScreen> createState() => _HashtagScreenState();
}

class _HashtagScreenState extends State<HashtagScreen> {
  List<EvPost>? _posts;
  String? _error;
  @override
  void initState() {
    super.initState();
    CommunityApi.instance.hashtagPosts(Scope.read(context).current.guid, widget.tag, 1).then((p) {
      if (mounted) setState(() => _posts = p);
    }).catchError((e) {
      if (mounted) setState(() => _error = '$e');
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('#${widget.tag}')),
        body: _error != null
            ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load posts", body: _error!)
            : _posts == null
                ? ListView(children: const [PostSkeleton(), PostSkeleton()])
                : ListView(children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: EvCard(child: Row(children: [
                        Container(width: 52, height: 52, decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.tag_rounded, color: Colors.white, size: 28)),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('#${widget.tag}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18)), Text('${widget.total > 0 ? widget.total : _posts!.length} posts', style: const TextStyle(color: EvColors.muted))])),
                      ])),
                    ),
                    if (_posts!.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No posts with this tag yet.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))),
                    for (final p in _posts!) PostCard(p, onOpen: () => openPost(context, p), onOpenUser: (u) => openProfile(context, u)),
                  ]),
      );
}

// ---------------- Groups ----------------
class GroupTile extends StatelessWidget {
  final Group g;
  const GroupTile(this.g, {super.key});
  @override
  Widget build(BuildContext context) => EvCard(
        padding: const EdgeInsets.all(10),
        child: InkWell(
          onTap: () => push(context, GroupScreen(group: g)),
          child: Row(children: [
            _img(g.cover, h: 48, w: 48, r: 14),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(g.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)), Text('${g.members} members · ${g.privacy == 'private' ? 'Private' : 'Public'}', style: const TextStyle(color: EvColors.muted, fontSize: 12))])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(color: g.isMember ? EvColors.sand2 : EvColors.peach, borderRadius: BorderRadius.circular(10)),
              child: Text(g.isOwner ? 'Owner' : (g.isMember ? 'Joined' : 'View'), style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: g.isMember ? EvColors.ink : EvColors.ember2)),
            ),
          ]),
        ),
      );
}

class GroupsScreen extends StatelessWidget {
  const GroupsScreen({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Groups'),
            actions: [IconButton(icon: const Icon(Icons.add_circle_rounded, color: EvColors.ember2), onPressed: () => push(context, const CreateGroupScreen()))],
            bottom: const TabBar(tabs: [Tab(text: 'All Groups'), Tab(text: 'My Groups'), Tab(text: 'Joined')], labelColor: EvColors.ember2, indicatorColor: EvColors.ember2, unselectedLabelColor: EvColors.muted),
          ),
          body: const TabBarView(children: [_GroupList(kind: 'explore'), _GroupList(kind: 'owner'), _GroupList(kind: 'member')]),
        ),
      );
}

class _GroupList extends StatefulWidget {
  final String kind;
  const _GroupList({required this.kind});
  @override
  State<_GroupList> createState() => _GroupListState();
}

class _GroupListState extends State<_GroupList> with AutomaticKeepAliveClientMixin {
  List<Group>? _list;
  @override
  bool get wantKeepAlive => true;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      // All Groups includes the ones you are already in.
      final p = widget.kind == 'explore' ? await ApiClient.instance.post('groups/explore', {'include_joined': 1}) : await ApiClient.instance.post('groups/mine', {'role': widget.kind});
      final m = mapOf(p);
      if (mounted) setState(() => _list = listOf(m['list'] ?? m['groups'] ?? p).map(Group.fromJson).where((g) => g.guid > 0).toList());
    } catch (_) {
      if (mounted) setState(() => _list = []);
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_list == null) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    if (_list!.isEmpty) return StateMessage(icon: Icons.groups_rounded, title: widget.kind == 'explore' ? 'No groups to explore' : 'No groups yet', body: widget.kind == 'owner' ? 'Create a group with the + button.' : 'Groups you join appear here.');
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(14),
        itemCount: _list!.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) {
          final g = _list![i];
          return EvCard(
            padding: EdgeInsets.zero,
            child: ListTile(
              onTap: () async {
                await Navigator.of(context).push(MaterialPageRoute(builder: (_) => GroupScreen(group: g)));
                _load();
              },
              leading: CircleAvatar(backgroundColor: EvColors.peach, child: Text(g.title.isEmpty ? '?' : g.title[0].toUpperCase(), style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700))),
              title: Text(g.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('${g.members} members · ${g.privacy == 'private' ? 'Private' : 'Public'}', style: const TextStyle(fontSize: 12)),
              trailing: StatusChip(widget.kind == 'owner' ? 'Owner' : (widget.kind == 'member' || g.isMember) ? 'Joined' : 'Join'),
            ),
          );
        },
      ),
    );
  }
}

class GroupScreen extends StatefulWidget {
  final Group group;
  const GroupScreen({super.key, required this.group});
  @override
  State<GroupScreen> createState() => _GroupScreenState();
}

/// A group, as in the design: Discussion, About, Members, Active Polls,
/// Videos, Events and Moderators, all in the app.
class _GroupScreenState extends State<GroupScreen> {
  final _scroll = ScrollController();
  int _pageNo = 1;
  bool _more = true, _loadingMore = false;

  /// Next page of the timeline as you near the bottom.
  Future<void> _loadMorePosts(String owner, int guid) async {
    if (_loadingMore || !_more || _posts == null) return;
    _loadingMore = true;
    try {
      final r = mapOf(await ApiClient.instance.post('wall/list', {'owner_guid': guid, 'type': owner, 'offset': _pageNo + 1}));
      final seen = _posts!.map((x) => x.guid).toSet();
      final next = listOf(r['posts']).map(EvPost.fromJson).where((x) => x.guid > 0 && !seen.contains(x.guid)).toList();
      if (mounted) {
        setState(() {
          if (next.isEmpty) {
            _more = false;
          } else {
            _pageNo++;
            _posts!.addAll(next);
          }
        });
      }
    } catch (_) {
    } finally {
      _loadingMore = false;
    }
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }
  Map _g = const {};
  String _tab = 'Discussion';
  List<EvPost>? _posts;
  List<Map>? _members, _videos;
  List<Poll>? _polls;
  List<EventItem>? _events;
  bool _busy = false;

  int get _id => widget.group.guid;
  bool get _member => asBool(_g['is_member']) || asBool(_g['is_owner']);

  @override
  void initState() {
    super.initState();
    _view();
    _loadTab('Discussion');
    _scroll.addListener(() {
      if (_tab == 'Discussion' && _scroll.hasClients && _scroll.position.extentAfter < 600) _loadMorePosts('group', _id);
    });
  }

  Future<void> _view() async {
    try {
      final g = mapOf(await ApiClient.instance.post('group/view', {'guid': _id}));
      if (mounted) setState(() => _g = g);
    } catch (_) {}
  }

  Future<void> _loadTab(String t) async {
    final api = ApiClient.instance;
    final where = {'container_guid': _id, 'container_type': 'group', 'offset': 1};
    try {
      switch (t) {
        case 'Discussion':
          final r = mapOf(await api.post('wall/list', {'owner_guid': _id, 'type': 'group', 'offset': 1}));
          if (mounted) {
            setState(() {
              _posts = listOf(r['posts']).map(EvPost.fromJson).where((x) => x.guid > 0).toList();
              _pageNo = 1;
              _more = true;
            });
          }
        case 'Members':
        case 'Moderators':
          final r = mapOf(await api.post('group/members', {'guid': _id}));
          if (mounted) setState(() => _members = listOf(r['list']));
        case 'Active Polls':
          final r = mapOf(await api.post('pollsv3/list', where));
          if (mounted) setState(() => _polls = listOf(r['list'] ?? r['polls']).map(Poll.fromJson).toList());
        case 'Videos':
          final r = mapOf(await api.post('video/list', where));
          if (mounted) setState(() => _videos = listOf(r['list'] ?? r['videos']));
        case 'Events':
          final r = mapOf(await api.post('eventsv3/list', where));
          if (mounted) setState(() => _events = listOf(r['list'] ?? r['events']).map(EventItem.fromJson).toList());
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _posts ??= t == 'Discussion' ? [] : null;
        _members ??= (t == 'Members' || t == 'Moderators') ? [] : null;
        _polls ??= t == 'Active Polls' ? [] : null;
        _videos ??= t == 'Videos' ? [] : null;
        _events ??= t == 'Events' ? [] : null;
      });
    }
  }

  Future<void> _joinOrLeave() async {
    final leaving = _member || asBool(_g['request_pending']);
    if (leaving) {
      final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: Text(_member ? 'Leave this group?' : 'Cancel your request?'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('No')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Yes'))]));
      if (ok != true) return;
    }
    setState(() => _busy = true);
    try {
      await ApiClient.instance.post(leaving ? 'group/leave' : 'group/join', {'guid': _id});
      await _view();
      _loadTab(_tab);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _write() async {
    final ctrl = TextEditingController();
    final text = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (s) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(s).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: ctrl, autofocus: true, minLines: 3, maxLines: 8, decoration: const InputDecoration(hintText: "What's on your mind?")),
          const SizedBox(height: 12),
          EmberButton('Post', onPressed: () => Navigator.pop(s, ctrl.text.trim())),
        ]),
      ),
    );
    ctrl.dispose();
    if (text == null || text.isEmpty) return;
    try {
      await ApiClient.instance.post('wall/add', {'owner_guid': _id, 'post': text, 'type': 'group'});
      _loadTab('Discussion');
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final title = str(_g, 'title', widget.group.title);
    final private = str(_g, 'privacy', widget.group.privacy) == 'private';
    final pending = asBool(_g['request_pending']);
    const tabs = ['Discussion', 'About', 'Members', 'Active Polls', 'Videos', 'Events', 'Moderators'];
    Widget loading() => const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    Widget empty(String t) => Padding(padding: const EdgeInsets.all(30), child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted)));
    Widget person(Map m) => EvCard(
          padding: EdgeInsets.zero,
          child: ListTile(
            onTap: () => openProfile(context, EvUser.fromJson(m)),
            leading: Avatar(EvUser.fromJson(m), size: 40),
            title: Text(EvUser.fromJson(m).fullname, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: str(m, 'role') == 'member' ? null : Text(str(m, 'role') == 'owner' ? 'Admin' : 'Moderator', style: const TextStyle(color: EvColors.ember2, fontSize: 12, fontWeight: FontWeight.w600)),
          ),
        );
    List<Widget> body() {
      if (private && !_member && _tab != 'About') return [empty('This is a private group. Join to see its ${_tab.toLowerCase()}.')];
      switch (_tab) {
        case 'About':
          return [
            EvCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('About this group', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                Text(cleanText(str(_g, 'description', widget.group.description)), style: const TextStyle(height: 1.5, color: EvColors.ink2)),
                const SizedBox(height: 10),
                Row(children: [Icon(private ? Icons.lock_outline_rounded : Icons.public_rounded, size: 16, color: EvColors.muted), const SizedBox(width: 6), Text(private ? 'Private group' : 'Public group')]),
                if (asInt(_g['time_created']) > 0) Padding(padding: const EdgeInsets.only(top: 6), child: Row(children: [const Icon(Icons.calendar_today_outlined, size: 15, color: EvColors.muted), const SizedBox(width: 6), Text('Created ${timeAgo(asTime(_g['time_created']))}')])),
              ]),
            ),
          ];
        case 'Members':
        case 'Moderators':
          if (_members == null) return [loading()];
          final list = _tab == 'Moderators' ? _members!.where((m) => str(m, 'role') != 'member').toList() : _members!;
          if (list.isEmpty) return [empty(_tab == 'Moderators' ? 'No moderators yet.' : 'No members yet.')];
          return [for (final m in list) Padding(padding: const EdgeInsets.only(bottom: 8), child: person(m))];
        case 'Active Polls':
          if (_polls == null) return [loading()];
          if (_polls!.isEmpty) return [empty('No polls yet.')];
          return [for (final q in _polls!) Padding(padding: const EdgeInsets.only(bottom: 8), child: EvCard(padding: EdgeInsets.zero, child: ListTile(onTap: () => push(context, PollScreen(poll: q)), leading: const Tile(Icons.bar_chart_rounded, EvColors.ember2), title: Text(q.title, style: const TextStyle(fontWeight: FontWeight.w600)), trailing: StatusChip(q.closed ? 'Closed' : 'Opened'))))];
        case 'Videos':
          if (_videos == null) return [loading()];
          if (_videos!.isEmpty) return [empty('No videos yet.')];
          return [
            GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 10, crossAxisSpacing: 10, children: [
              for (final v in _videos!)
                GestureDetector(
                  onTap: () => push(context, ReelPlayerScreen(reels: [{'guid': asInt(v['guid']), 'video_src': str(v, 'file:video', str(v, 'url', str(v, 'video', str(v, 'file', str(v, 'video_src'))))), 'title': str(v, 'title'), 'owner_fullname': title}])),
                  child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Stack(fit: StackFit.expand, children: [CachedNetworkImage(cacheManager: evCache, imageUrl: iconUrl(v['file:cover'] ?? v['cover'] ?? v['thumbnail'] ?? v['image']), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.ink)), const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 36))])),
                ),
            ]),
          ];
        case 'Events':
          if (_events == null) return [loading()];
          if (_events!.isEmpty) return [empty('No events yet.')];
          return [for (final e in _events!) Padding(padding: const EdgeInsets.only(bottom: 8), child: EventCard(e))];
        default:
          if (_posts == null) return [loading()];
          return [
            if (_member)
              Padding(padding: const EdgeInsets.only(bottom: 10), child: GestureDetector(onTap: _write, child: Container(height: 44, alignment: Alignment.centerLeft, padding: const EdgeInsets.symmetric(horizontal: 16), decoration: BoxDecoration(color: const Color(0xFFEDEBFA), borderRadius: BorderRadius.circular(22)), child: const Text("What's on your mind?", style: TextStyle(color: EvColors.muted))))),
            if (_posts!.isEmpty) empty('No posts yet. Start the discussion.'),
            for (var i = 0; i < _posts!.length; i++) ...[PostCard(_posts![i], onOpen: () => openPost(context, _posts![i]), onChanged: () => _loadTab('Discussion')), if (feedExtra(i) != null) feedExtra(i)!],
            if (_more && _posts!.isNotEmpty) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))),
          ];
      }
    }

    return Scaffold(
      appBar: AppBar(title: Text(title, overflow: TextOverflow.ellipsis)),
      body: RefreshIndicator(
        color: EvColors.ember2,
        onRefresh: () async {
          await _view();
          await _loadTab(_tab);
        },
        child: ListView(controller: _scroll, padding: EdgeInsets.zero, children: [
          // Cover picture (owner and moderators can change it).
          SizedBox(
            height: 140,
            child: Stack(fit: StackFit.expand, children: [
              if (str(_g, 'cover_url').isNotEmpty)
                CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(str(_g, 'cover_url')), fit: BoxFit.cover, errorWidget: (_, __, ___) => const DecoratedBox(decoration: BoxDecoration(gradient: EvColors.emberGradient)))
              else
                const DecoratedBox(decoration: BoxDecoration(gradient: EvColors.emberGradient)),
              Positioned(left: 16, bottom: 16, child: CircleAvatar(radius: 30, backgroundColor: Colors.white, child: Text(title.isEmpty ? '?' : title[0].toUpperCase(), style: const TextStyle(color: EvColors.ember2, fontSize: 24, fontWeight: FontWeight.w700)))),
              if (asBool(_g['is_owner']) || asBool(_g['is_moderator']))
                Positioned(
                  right: 12,
                  bottom: 12,
                  child: Material(
                    color: Colors.black54,
                    shape: const StadiumBorder(),
                    child: InkWell(
                      customBorder: const StadiumBorder(),
                      onTap: () async {
                        if (await pickAndUpload(context, 'group/cover', {'guid': _id}, 'coverphoto')) _view();
                      },
                      child: const Padding(padding: EdgeInsets.symmetric(horizontal: 12, vertical: 7), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.photo_camera_rounded, color: Colors.white, size: 16), SizedBox(width: 6), Text('Change cover', style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600))])),
                    ),
                  ),
                ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              Text('${private ? 'Private' : 'Public'} · ${asInt(_g['members'] ?? widget.group.members)} members', style: const TextStyle(color: EvColors.muted, fontSize: 12.5)),
              const SizedBox(height: 10),
              Row(children: [
                if (!asBool(_g['is_owner']))
                  Expanded(
                    child: _member || pending
                        ? OutlinedButton.icon(onPressed: _busy ? null : _joinOrLeave, icon: Icon(_member ? Icons.check_circle_outline_rounded : Icons.schedule_rounded, size: 17), label: Text(_member ? 'Joined' : 'Requested'))
                        : FilledButton.icon(onPressed: _busy ? null : _joinOrLeave, icon: const Icon(Icons.group_add_rounded, size: 17), label: Text(private ? 'Ask to join' : 'Join group'), style: FilledButton.styleFrom(backgroundColor: EvColors.ember2)),
                  ),
                if (!asBool(_g['is_owner'])) const SizedBox(width: 8),
                Expanded(child: FilledButton.icon(onPressed: () => Share.share('Join "$title" on Evinie: ${absUrl(str(_g, 'url', widget.group.url))}'), icon: const Icon(Icons.person_add_alt_1_rounded, size: 17), label: const Text('Invite'), style: FilledButton.styleFrom(backgroundColor: EvColors.ember2))),
              ]),
            ]),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 40,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
              for (final t in tabs)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(label: Text(t), selected: _tab == t, onSelected: (_) {
                    setState(() => _tab = t);
                    _loadTab(t);
                  }, selectedColor: EvColors.ink, labelStyle: TextStyle(color: _tab == t ? Colors.white : EvColors.ink2, fontWeight: FontWeight.w600, fontSize: 12.5), side: const BorderSide(color: EvColors.line)),
                ),
            ]),
          ),
          const SizedBox(height: 10),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: body())),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}

class EventCard extends StatelessWidget {
  final EventItem e;
  const EventCard(this.e, {super.key});
  @override
  Widget build(BuildContext context) {
    final (day, month) = e.badge;
    return GestureDetector(
      onTap: () => push(context, EventScreen(guid: e.guid, preview: e)),
      child: EvCard(
        padding: EdgeInsets.zero,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Stack(children: [
            ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(20)), child: e.image.isEmpty ? Container(height: 120, decoration: const BoxDecoration(gradient: EvColors.emberGradient)) : CachedNetworkImage(cacheManager: evCache, imageUrl: e.image, height: 130, width: double.infinity, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
            if (day.isNotEmpty)
              Positioned(left: 10, top: 10, child: Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)), child: Column(children: [Text(month, style: const TextStyle(color: EvColors.ember2, fontSize: 10.5, fontWeight: FontWeight.w700)), Text(day, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, height: 1))]))),
            Positioned(left: 10, bottom: 10, child: Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3), decoration: BoxDecoration(color: EvColors.ember2, borderRadius: BorderRadius.circular(20)), child: Text(e.cost > 0 ? naira(e.cost) : 'Free', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)))),
          ]),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(e.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
              const SizedBox(height: 4),
              Row(children: [const Icon(Icons.schedule_rounded, size: 14, color: EvColors.muted), const SizedBox(width: 4), Text('${e.date} · ${e.start}${e.end.isEmpty ? '' : ' – ${e.end}'}', style: const TextStyle(color: EvColors.muted, fontSize: 12))]),
              if (e.location.isNotEmpty) Row(children: [const Icon(Icons.place_outlined, size: 14, color: EvColors.muted), const SizedBox(width: 4), Expanded(child: Text(e.location, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: EvColors.muted, fontSize: 12)))]),
            ]),
          ),
        ]),
      ),
    );
  }
}

class EventsScreen extends StatefulWidget {
  const EventsScreen({super.key});
  @override
  State<EventsScreen> createState() => _EventsScreenState();
}

class _EventsScreenState extends State<EventsScreen> {
  List<EventItem>? _list;
  String? _error;
  String _filter = 'all';
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await CommunityApi.instance.events(filter: _filter);
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Events')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Row(children: [
              for (final f in const [('all', 'All events'), ('mine', 'My events'), ('interested', 'Interested')])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(f.$2),
                    selected: _filter == f.$1,
                    selectedColor: EvColors.peach,
                    onSelected: (_) {
                      setState(() {
                        _filter = f.$1;
                        _list = null;
                        _error = null;
                      });
                      _load();
                    },
                  ),
                ),
            ]),
          ),
          Expanded(
            child: _error != null
                ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load events", body: _error!, action: 'Try again', onAction: _load)
                : _list == null
                    ? _loading()
                    : _list!.isEmpty
                        ? StateMessage(icon: Icons.event_rounded, title: 'No events here', body: _filter == 'mine' ? "Events you create appear here." : _filter == 'interested' ? "Tap Interested or Going on an event and it appears here." : 'Events from your friends, groups and pages will show here.')
                        : RefreshIndicator(color: EvColors.ember2, onRefresh: _load, child: ListView.separated(padding: const EdgeInsets.all(16), itemCount: _list!.length, separatorBuilder: (_, __) => const SizedBox(height: 12), itemBuilder: (_, i) => EventCard(_list![i]))),
          ),
        ]),
      );
}

class EventScreen extends StatefulWidget {
  final int guid;
  final EventItem? preview;
  const EventScreen({super.key, required this.guid, this.preview});
  @override
  State<EventScreen> createState() => _EventScreenState();
}

class _EventScreenState extends State<EventScreen> {
  late EventItem? _e = widget.preview;
  String? _mine;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    CommunityApi.instance.event(widget.guid).then((e) {
      if (mounted && e.guid > 0) setState(() => _e = e);
    }).catchError((_) {});
  }

  Future<void> _rsvp(String type) async {
    setState(() => _busy = true);
    try {
      await CommunityApi.instance.rsvp(widget.guid, type);
      if (mounted) setState(() => _mine = type);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final e = _e;
    if (e == null) return Scaffold(appBar: AppBar(), body: _loading());
    Widget rsvp(String type, String label, Color c) => Expanded(
          child: GestureDetector(
            onTap: _busy ? null : () => _rsvp(type),
            child: Container(
              height: 42,
              alignment: Alignment.center,
              decoration: BoxDecoration(color: _mine == type ? c : Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: c, width: 1.5)),
              child: Text(label, style: TextStyle(color: _mine == type ? Colors.white : c, fontWeight: FontWeight.w700, fontSize: 12.5)),
            ),
          ),
        );
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(pinned: true, expandedHeight: 210, backgroundColor: EvColors.sand, flexibleSpace: FlexibleSpaceBar(background: e.image.isEmpty ? const DecoratedBox(decoration: BoxDecoration(gradient: EvColors.emberGradient)) : CachedNetworkImage(cacheManager: evCache, imageUrl: e.image, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2)))),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(e.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w700, letterSpacing: -0.3)),
              const SizedBox(height: 12),
              for (final r in [(Icons.calendar_today_rounded, e.date, '${e.start}${e.end.isEmpty ? '' : ' – ${e.end}'}'), (Icons.place_outlined, e.location.isEmpty ? 'Location to be announced' : e.location, ''), (Icons.sell_outlined, e.cost > 0 ? naira(e.cost) : 'Free entry', '')])
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(children: [Tile(r.$1, EvColors.ember2, size: 38), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(r.$2, style: const TextStyle(fontWeight: FontWeight.w600)), if (r.$3.isNotEmpty) Text(r.$3, style: const TextStyle(color: EvColors.muted, fontSize: 12))]))]),
                ),
              const SizedBox(height: 6),
              if (e.finished)
                const Text('This event has ended.', style: TextStyle(color: EvColors.muted, fontWeight: FontWeight.w600))
              else
                Row(children: [rsvp('going', 'Going', EvColors.ember2), const SizedBox(width: 8), rsvp('interested', 'Interested', EvColors.green), const SizedBox(width: 8), rsvp('nointerested', 'Not going', EvColors.muted)]),
              if (e.description.isNotEmpty) ...[const SizedBox(height: 18), const Text('About this event', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 6), Text(e.description, style: const TextStyle(height: 1.55, color: EvColors.ink2))],
            ]),
          ),
        ),
      ]),
    );
  }
}

// ---------------- Polls ----------------
class PollsScreen extends StatefulWidget {
  const PollsScreen({super.key});
  @override
  State<PollsScreen> createState() => _PollsScreenState();
}

class _PollsScreenState extends State<PollsScreen> {
  List<Poll>? _list;
  String _filter = 'all';
  String? _error;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await CommunityApi.instance.polls(filter: _filter);
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Polls')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                for (final f in const [('all', 'All polls'), ('mine', 'My polls'), ('voted', 'I voted')])
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(f.$2),
                      selected: _filter == f.$1,
                      selectedColor: EvColors.peach,
                      onSelected: (_) {
                        if (_filter == f.$1) return;
                        setState(() {
                          _filter = f.$1;
                          _list = null;
                          _error = null;
                        });
                        _load();
                      },
                    ),
                  ),
              ]),
            ),
          ),
          Expanded(child: _body()),
        ]),
      );

  Widget _body() => _error != null
      ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load polls", body: _error!, action: 'Try again', onAction: _load)
      : _list == null
          ? _loading()
          : _list!.isEmpty
              ? StateMessage(
                  icon: Icons.bar_chart_rounded,
                  title: 'No polls yet',
                  body: _filter == 'mine'
                      ? "Polls you create will show here."
                      : _filter == 'voted'
                          ? "Polls you vote on will show here."
                          : 'Polls from your friends and groups will show here.')
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                    itemCount: _list!.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 8),
                    itemBuilder: (_, i) {
                      final p = _list![i];
                      final closes = p.closesAt;
                      final when = p.closed
                          ? 'closed'
                          : closes != null
                              ? 'closes ${closes.day}/${closes.month}/${closes.year}'
                              : '${p.totalVotes} votes';
                      return EvCard(
                        padding: EdgeInsets.zero,
                        child: ListTile(
                          onTap: () async {
                            await Navigator.of(context).push(MaterialPageRoute(builder: (_) => PollScreen(poll: p)));
                            if (mounted) _load();
                          },
                          leading: Tile(Icons.bar_chart_rounded, p.closed ? EvColors.muted : EvColors.ember2),
                          title: Text(p.title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                          subtitle: Text('${timeAgo(p.time)} · $when', style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
                          trailing: _Chip(p.closed ? 'Closed' : 'Open', p.closed ? EvColors.muted : EvColors.green),
                        ),
                      );
                    },
                  ),
                );
}

class _Chip extends StatelessWidget {
  final String t;
  final Color c;
  const _Chip(this.t, this.c);
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3), decoration: BoxDecoration(color: c.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)), child: Text(t, style: TextStyle(color: c, fontSize: 11, fontWeight: FontWeight.w700)));
}

class PollScreen extends StatefulWidget {
  final Poll poll;
  const PollScreen({super.key, required this.poll});
  @override
  State<PollScreen> createState() => _PollScreenState();
}

class _PollScreenState extends State<PollScreen> {
  late Poll _p = widget.poll;
  String? _voted;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    CommunityApi.instance.poll(_p.guid, checkVoted: true).then((p) {
      if (mounted && p.guid > 0 && p.options.isNotEmpty) setState(() => _p = p);
    }).catchError((_) {});
  }

  bool get _isOwner => _p.mine || (_p.ownerGuid > 0 && _p.ownerGuid == Scope.read(context).current.guid);

  Future<void> _editQuestion() async {
    final c = TextEditingController(text: _p.title);
    final t = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Edit question'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          TextField(controller: c, autofocus: true, maxLines: 3, minLines: 1),
          const SizedBox(height: 8),
          const Text('Only the question can be changed. The choices and votes stay the same.', style: TextStyle(color: EvColors.muted, fontSize: 12)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    c.dispose();
    if (t == null || t.isEmpty || t == _p.title || !mounted) return;
    try {
      await CommunityApi.instance.editPoll(_p.guid, t);
      if (!mounted) return;
      setState(() => _p = _p.copyWith(title: t));
      showMessage(context, 'Question updated');
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  Future<void> _vote(PollOption o) async {
    if (_busy || _voted != null || _p.hasVoted || _p.closed) return;
    setState(() => _busy = true);
    try {
      final updated = await CommunityApi.instance.vote(_p.guid, o.key, current: _p);
      if (!mounted) return;
      setState(() {
        _voted = o.key;
        _p = updated ?? _p.copyWith(hasVoted: true);
      });
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final total = _p.totalVotes;
    final showResults = _voted != null || _p.hasVoted || _p.closed;
    final String footer;
    if (_voted != null) {
      footer = total > 0 ? 'Thanks for voting · $total votes' : 'Thanks for voting';
    } else if (_p.closed) {
      footer = total > 0 ? '$total votes · this poll is closed' : 'This poll is closed';
    } else if (_p.hasVoted) {
      footer = "You've already voted on this poll";
    } else {
      footer = 'Tap an option to vote';
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Poll'), actions: [
        if (_isOwner) IconButton(tooltip: 'Edit question', icon: const Icon(Icons.edit_outlined), onPressed: _editQuestion),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        EvCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text(_p.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, height: 1.35))), _Chip(_p.closed ? 'Closed' : 'Open', _p.closed ? EvColors.muted : EvColors.green)]),
            if (_p.closesAt != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text('${_p.closed ? 'Closed' : 'Closes'} on ${_p.closesAt!.day}/${_p.closesAt!.month}/${_p.closesAt!.year}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
              ),
            const SizedBox(height: 14),
            if (_p.options.isEmpty) const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('Loading choices…', style: TextStyle(color: EvColors.muted))),
            for (final o in _p.options)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: GestureDetector(
                  onTap: () => _vote(o),
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 46),
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: _voted == o.key ? EvColors.ember1 : EvColors.line, width: _voted == o.key ? 1.5 : 1)),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(13),
                      child: Stack(children: [
                        if (showResults)
                          Positioned.fill(child: Align(alignment: Alignment.centerLeft, child: FractionallySizedBox(widthFactor: _p.share(o), heightFactor: 1, child: Container(color: _voted == o.key ? const Color(0xFFFFE1CF) : EvColors.sand2)))),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          child: Row(children: [
                            Icon(_voted == o.key ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, size: 18, color: _voted == o.key ? EvColors.ember2 : EvColors.muted),
                            const SizedBox(width: 10),
                            Expanded(child: Text(o.title, style: const TextStyle(fontWeight: FontWeight.w500))),
                            if (showResults) Text('${(_p.share(o) * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w700)),
                          ]),
                        ),
                      ]),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 4),
            Text(footer, style: const TextStyle(color: EvColors.muted, fontSize: 12)),
          ]),
        ),
      ]),
    );
  }
}

// ---------------- Business pages ----------------
class PagesScreen extends StatefulWidget {
  const PagesScreen({super.key});
  @override
  State<PagesScreen> createState() => _PagesScreenState();
}

class _PagesScreenState extends State<PagesScreen> {
  List<BizPage>? _list;
  String _q = '';
  String _filter = 'all';
  String? _error;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await CommunityApi.instance.pages(keyword: _q, filter: _filter);
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Business pages')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              textInputAction: TextInputAction.search,
              onSubmitted: (v) {
                setState(() {
                  _q = v.trim();
                  _list = null;
                });
                _load();
              },
              decoration: const InputDecoration(hintText: 'Search pages', prefixIcon: Icon(Icons.search_rounded)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Row(children: [
              for (final f in const [('all', 'All pages'), ('mine', 'My pages'), ('liked', 'Joined')])
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(f.$2),
                    selected: _filter == f.$1,
                    selectedColor: EvColors.peach,
                    onSelected: (_) {
                      setState(() {
                        _filter = f.$1;
                        _list = null;
                        _error = null;
                      });
                      _load();
                    },
                  ),
                ),
            ]),
          ),
          Expanded(
            child: _error != null
                ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load pages", body: _error!, action: 'Try again', onAction: _load)
                : _list == null
                    ? _loading()
                    : _list!.isEmpty
                        ? StateMessage(icon: Icons.storefront_outlined, title: 'No pages found', body: _filter == 'mine' ? "You haven't created a page yet." : _filter == 'liked' ? "Pages you join (like) appear here." : 'Try a different name or category.')
                        : ListView.separated(
                            padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                            itemCount: _list!.length,
                            separatorBuilder: (_, __) => const SizedBox(height: 8),
                            itemBuilder: (_, i) {
                              final p = _list![i];
                              return EvCard(
                                padding: const EdgeInsets.all(10),
                                child: InkWell(
                                  onTap: () => push(context, PageScreen(page: p)),
                                  child: Row(children: [
                                    _img(p.photo, h: 48, w: 48),
                                    const SizedBox(width: 12),
                                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)), Text('${p.category.isEmpty ? 'Business' : p.category} · ${p.likes} likes', style: const TextStyle(color: EvColors.muted, fontSize: 12))])),
                                    const Icon(Icons.chevron_right_rounded, color: EvColors.muted),
                                  ]),
                                ),
                              );
                            },
                          ),
          ),
        ]),
      );
}

class PageScreen extends StatefulWidget {
  final BizPage page;
  const PageScreen({super.key, required this.page});
  @override
  State<PageScreen> createState() => _PageScreenState();
}

/// Business page: header, Like, owner tools, and Timeline / About /
/// Videos / Polls / Events tabs, all inside the app.
class _PageScreenState extends State<PageScreen> {
  final _scroll = ScrollController();
  int _pageNo = 1;
  bool _more = true, _loadingMore = false;

  /// Next page of the timeline as you near the bottom.
  Future<void> _loadMorePosts(String owner, int guid) async {
    if (_loadingMore || !_more || _posts == null) return;
    _loadingMore = true;
    try {
      final r = mapOf(await ApiClient.instance.post('wall/list', {'owner_guid': guid, 'type': owner, 'offset': _pageNo + 1}));
      final seen = _posts!.map((x) => x.guid).toSet();
      final next = listOf(r['posts']).map(EvPost.fromJson).where((x) => x.guid > 0 && !seen.contains(x.guid)).toList();
      if (mounted) {
        setState(() {
          if (next.isEmpty) {
            _more = false;
          } else {
            _pageNo++;
            _posts!.addAll(next);
          }
        });
      }
    } catch (_) {
    } finally {
      _loadingMore = false;
    }
  }

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }
  late BizPage _p = widget.page;
  String _tab = 'Timeline';
  List<EvPost>? _posts;
  List<Map>? _videos;
  List<Poll>? _polls;
  List<EventItem>? _events;
  bool _liking = false;

  bool get _isOwner => Scope.read(context).current.guid == _p.owner;

  void _refreshPage() {
    CommunityApi.instance.page(_p.guid).then((p) {
      if (mounted && p.guid > 0) setState(() => _p = p);
    }).catchError((_) {});
  }

  @override
  void initState() {
    super.initState();
    _refreshPage();
    _loadTab('Timeline');
    _scroll.addListener(() {
      if (_tab == 'Timeline' && _scroll.hasClients && _scroll.position.extentAfter < 600) _loadMorePosts('businesspage', _p.guid);
    });
  }

  Future<void> _loadTab(String t) async {
    final api = ApiClient.instance;
    final where = {'container_guid': _p.guid, 'container_type': 'businesspage', 'offset': 1};
    try {
      switch (t) {
        case 'Timeline':
          final r = mapOf(await api.post('wall/list', {'owner_guid': _p.guid, 'type': 'businesspage', 'offset': 1}));
          if (mounted) {
            setState(() {
              _posts = listOf(r['posts']).map(EvPost.fromJson).where((x) => x.guid > 0).toList();
              _pageNo = 1;
              _more = true;
            });
          }
        case 'Videos':
          final r = mapOf(await api.post('video/list', where));
          if (mounted) setState(() => _videos = listOf(r['list'] ?? r['videos']));
        case 'Polls':
          final r = mapOf(await api.post('pollsv3/list', where));
          if (mounted) setState(() => _polls = listOf(r['list'] ?? r['polls']).map(Poll.fromJson).toList());
        case 'Events':
          final r = mapOf(await api.post('eventsv3/list', where));
          if (mounted) setState(() => _events = listOf(r['list'] ?? r['events']).map(EventItem.fromJson).toList());
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        if (t == 'Timeline') _posts ??= [];
        if (t == 'Videos') _videos ??= [];
        if (t == 'Polls') _polls ??= [];
        if (t == 'Events') _events ??= [];
      });
    }
  }

  Future<void> _like() async {
    setState(() => _liking = true);
    try {
      final (liked, count) = await CommunityApi.instance.likePage(_p.guid, !_p.liked);
      if (mounted) {
        setState(() => _p = BizPage(guid: _p.guid, likes: count, owner: _p.owner, name: _p.name, description: _p.description, category: _p.category, website: _p.website, phone: _p.phone, address: _p.address, email: _p.email, photo: _p.photo, cover: _p.cover, url: _p.url, liked: liked));
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _liking = false);
    }
  }

  Future<void> _edit() async {
    final f = {'name': _p.name, 'category': _p.category, 'description': _p.description, 'phone': _p.phone, 'email': _p.email, 'address': _p.address, 'website': _p.website};
    final c = {for (final e in f.entries) e.key: TextEditingController(text: e.value)};
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(
      builder: (ctx) => Scaffold(
        appBar: AppBar(title: const Text('Edit page')),
        body: ListView(padding: EdgeInsets.fromLTRB(16, 16, 16, 40 + MediaQuery.of(ctx).padding.bottom), children: [
          EvCard(
            padding: EdgeInsets.zero,
            child: ListTile(
              onTap: () => push(ctx, BusinessScreen(page: _p.guid, name: _p.name)),
              leading: const Tile(Icons.verified_rounded, EvColors.blue),
              title: const Text('Verification & Business Hub', style: TextStyle(fontWeight: FontWeight.w700)),
              subtitle: FutureBuilder<Map>(
                future: MoreApi.instance.suiteStatus(_p.guid),
                builder: (_, s) => Text(!s.hasData ? 'Checking status…' : (asBool(s.data!['verified'] ?? s.data!['is_verified']) || str(s.data!, 'status') == 'verified') ? 'Verified · open Business Hub' : 'Status: ${str(s.data!, 'status', 'not verified')}', style: const TextStyle(fontSize: 12)),
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
            ),
          ),
          const SizedBox(height: 14),
          for (final e in [('name', 'Page name'), ('category', 'Page type'), ('description', 'Description'), ('phone', 'Phone'), ('email', 'Email'), ('address', 'Address'), ('website', 'Website')])
            Padding(padding: const EdgeInsets.only(bottom: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.$2, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)), const SizedBox(height: 4), TextField(controller: c[e.$1], maxLines: e.$1 == 'description' ? 4 : 1)])),
          EmberButton('Save changes', onPressed: () async {
            try {
              await ApiClient.instance.post('businesspage/edit', {'guid': _p.guid, for (final e in c.entries) e.key: e.value.text.trim()});
              if (ctx.mounted) Navigator.pop(ctx, true);
            } catch (e) {
              if (ctx.mounted) showMessage(ctx, '$e');
            }
          }),
        ]),
      ),
    ));
    for (final x in c.values) {
      x.dispose();
    }
    if (saved == true) {
      final p = await CommunityApi.instance.page(_p.guid);
      if (mounted) setState(() => _p = p);
    }
  }

  Future<void> _postAsPage() async {
    final ctrl = TextEditingController();
    final text = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (s) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(s).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Post as ${_p.name}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 10),
          TextField(controller: ctrl, autofocus: true, minLines: 3, maxLines: 8, decoration: const InputDecoration(hintText: "What's on your mind?")),
          const SizedBox(height: 12),
          EmberButton('Post', onPressed: () => Navigator.pop(s, ctrl.text.trim())),
        ]),
      ),
    );
    ctrl.dispose();
    if (text == null || text.isEmpty) return;
    try {
      await ApiClient.instance.post('wall/add', {'type': 'businesspage', 'owner_guid': _p.guid, 'post': text});
      _loadTab('Timeline');
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final owner = _isOwner;
    const tabs = ['Timeline', 'About', 'Videos', 'Polls', 'Events'];
    Widget loading() => const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    Widget empty(String t) => Padding(padding: const EdgeInsets.all(30), child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted)));
    List<Widget> body() {
      switch (_tab) {
        case 'About':
          final rows = [(Icons.business_rounded, p.category, true), (Icons.phone_outlined, p.phone, owner), (Icons.near_me_outlined, p.address, true), (Icons.mail_outline_rounded, p.email, owner), (Icons.public_rounded, p.website, true)].where((r) => r.$2.isNotEmpty && r.$3).toList();
          return [
            EvCard(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (p.description.isNotEmpty) Text(cleanText(p.description), style: const TextStyle(height: 1.5, color: EvColors.ink2)),
                const SizedBox(height: 10),
                for (final r in rows) Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [Icon(r.$1, size: 17, color: EvColors.muted), const SizedBox(width: 10), Expanded(child: Text(r.$2, style: const TextStyle(fontWeight: FontWeight.w500)))])),
              ]),
            ),
          ];
        case 'Videos':
          if (_videos == null) return [loading()];
          if (_videos!.isEmpty) return [empty('No videos yet.')];
          return [
            GridView.count(crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.2, children: [
              for (final v in _videos!)
                GestureDetector(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReelPlayerScreen(reels: [{'guid': asInt(v['guid']), 'video_src': str(v, 'file:video', str(v, 'url', str(v, 'video', str(v, 'file', str(v, 'video_src'))))), 'title': str(v, 'title'), 'owner_fullname': p.name}]))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Stack(fit: StackFit.expand, children: [CachedNetworkImage(cacheManager: evCache, imageUrl: iconUrl(v['file:cover'] ?? v['cover'] ?? v['thumbnail'] ?? v['image']), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.ink)), const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white, size: 36))]))),
                    const SizedBox(height: 4),
                    Text(str(v, 'title'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
                  ]),
                ),
            ]),
          ];
        case 'Polls':
          if (_polls == null) return [loading()];
          if (_polls!.isEmpty) return [empty('No polls yet.')];
          return [
            for (final q in _polls!)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: EvCard(
                  padding: EdgeInsets.zero,
                  child: ListTile(
                    onTap: () => push(context, PollScreen(poll: q)),
                    leading: Tile(Icons.bar_chart_rounded, q.closed ? EvColors.muted : EvColors.ember2),
                    title: Text(q.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text('${q.options.fold<int>(0, (a, o) => a + o.votes)} votes', style: const TextStyle(fontSize: 12)),
                    trailing: StatusChip(q.closed ? 'Closed' : 'Opened'),
                  ),
                ),
              ),
          ];
        case 'Events':
          if (_events == null) return [loading()];
          if (_events!.isEmpty) return [empty('No events yet.')];
          return [
            for (final e in _events!)
              GestureDetector(
                onTap: () => push(context, EventScreen(guid: e.guid, preview: e)),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
                  clipBehavior: Clip.antiAlias,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    SizedBox(height: 150, width: double.infinity, child: CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(e.image), fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2))),
                    Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(e.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text([e.date, e.start, e.location].where((x) => x.isNotEmpty).join(' · '), style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                      ]),
                    ),
                  ]),
                ),
              ),
          ];
        default:
          if (_posts == null) return [loading()];
          return [
            if (owner)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: GestureDetector(onTap: _postAsPage, child: Container(height: 44, alignment: Alignment.centerLeft, padding: const EdgeInsets.symmetric(horizontal: 16), decoration: BoxDecoration(color: const Color(0xFFEDEBFA), borderRadius: BorderRadius.circular(22)), child: const Text("What's on your mind?", style: TextStyle(color: EvColors.muted)))),
              ),
            if (_posts!.isEmpty) empty('No posts yet.'),
            for (var i = 0; i < _posts!.length; i++) ...[PostCard(_posts![i], onOpen: () => openPost(context, _posts![i]), onChanged: () => _loadTab('Timeline')), if (feedExtra(i) != null) feedExtra(i)!],
            if (_more && _posts!.isNotEmpty) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))),
          ];
      }
    }

    return Scaffold(
      appBar: AppBar(title: Text(p.name, overflow: TextOverflow.ellipsis)),
      body: RefreshIndicator(
        color: EvColors.ember2,
        onRefresh: () => _loadTab(_tab),
        child: ListView(controller: _scroll, padding: EdgeInsets.zero, children: [
          Stack(clipBehavior: Clip.none, children: [
            SizedBox(height: 150, width: double.infinity, child: p.cover.isEmpty ? const DecoratedBox(decoration: BoxDecoration(gradient: EvColors.emberGradient)) : CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(p.cover), fit: BoxFit.cover, errorWidget: (_, __, ___) => const DecoratedBox(decoration: BoxDecoration(gradient: EvColors.emberGradient)))),
            // Page owner: change the cover and the page photo.
            if (owner)
              Positioned(
                right: 12,
                bottom: 10,
                child: Material(
                  color: Colors.black54,
                  shape: const StadiumBorder(),
                  child: InkWell(
                    customBorder: const StadiumBorder(),
                    onTap: () async {
                      if (await pickAndUpload(context, 'businesspage/photo', {'guid': p.guid, 'kind': 'cover'}, 'coverphoto')) _refreshPage();
                    },
                    child: const Padding(padding: EdgeInsets.symmetric(horizontal: 12, vertical: 7), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.photo_camera_rounded, color: Colors.white, size: 16), SizedBox(width: 6), Text('Change cover', style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w600))])),
                  ),
                ),
              ),
            Positioned(
              left: 16,
              bottom: -40,
              child: GestureDetector(
                onTap: owner
                    ? () async {
                        if (await pickAndUpload(context, 'businesspage/photo', {'guid': p.guid, 'kind': 'photo'}, 'photo', maxWidth: 800)) _refreshPage();
                      }
                    : null,
                child: Stack(children: [
                  Container(
                    padding: const EdgeInsets.all(3),
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: EvColors.ember2),
                    child: CircleAvatar(radius: 40, backgroundColor: Colors.white, backgroundImage: p.photo.isEmpty ? null : CachedNetworkImageProvider(absUrl(p.photo), cacheManager: evCache), child: p.photo.isEmpty ? const Icon(Icons.storefront_rounded, color: EvColors.ember2, size: 30) : null),
                  ),
                  if (owner) const Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 14, backgroundColor: EvColors.ember2, child: Icon(Icons.photo_camera_rounded, size: 15, color: Colors.white))),
                ]),
              ),
            ),
          ]),
          const SizedBox(height: 46),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 3),
                    Text(['👍 ${p.likes} likes', if (p.address.isNotEmpty) '📍 ${p.address}'].join('  ·  '), style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                  ]),
                ),
                if (!owner)
                  p.liked
                      ? OutlinedButton.icon(onPressed: _liking ? null : _like, icon: const Icon(Icons.check_rounded, size: 16), label: const Text('Liked'), style: OutlinedButton.styleFrom(foregroundColor: EvColors.ink, visualDensity: VisualDensity.compact))
                      : FilledButton.icon(onPressed: _liking ? null : _like, icon: const Icon(Icons.thumb_up_alt_rounded, size: 16), label: const Text('Like page'), style: FilledButton.styleFrom(backgroundColor: EvColors.ember2, visualDensity: VisualDensity.compact)),
              ]),
              if (owner) ...[
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(child: EmberButton('Edit page', icon: Icons.edit_rounded, onPressed: _edit)),
                  const SizedBox(width: 8),
                  Expanded(child: OutlineEmberButton('Manage admins', onPressed: () => push(context, ManageAdminsScreen(page: p.guid)))),
                ]),
              ],
            ]),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 40,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 16), children: [
              for (final t in tabs)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(t),
                    selected: _tab == t,
                    onSelected: (_) {
                      setState(() => _tab = t);
                      _loadTab(t);
                    },
                    selectedColor: EvColors.ink,
                    labelStyle: TextStyle(color: _tab == t ? Colors.white : EvColors.ink2, fontWeight: FontWeight.w600, fontSize: 12.5),
                    side: const BorderSide(color: EvColors.line),
                  ),
                ),
            ]),
          ),
          const SizedBox(height: 10),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: body())),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}


/// Page admins: list, remove, and add a friend after confirming your password.
class ManageAdminsScreen extends StatefulWidget {
  final int page;
  const ManageAdminsScreen({super.key, required this.page});
  @override
  State<ManageAdminsScreen> createState() => _ManageAdminsScreenState();
}

class _ManageAdminsScreenState extends State<ManageAdminsScreen> {
  List<Map>? _team;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final t = await MoreApi.instance.suiteTeam(widget.page);
      if (mounted) setState(() => _team = listOf(t['team']));
    } catch (e) {
      if (mounted) setState(() => _team = []);
    }
  }

  Future<bool> _confirmPassword(String name) async {
    final c = TextEditingController();
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      builder: (s) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(s).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Confirm password', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 6),
          Text('Enter your password to add $name as an administrator.', style: const TextStyle(color: EvColors.muted, fontSize: 12.5)),
          const SizedBox(height: 10),
          TextField(controller: c, obscureText: true, autofocus: true, decoration: const InputDecoration(hintText: 'Enter password')),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlineEmberButton('Cancel', onPressed: () => Navigator.pop(s, false))),
            const SizedBox(width: 8),
            Expanded(child: EmberButton('Confirm', onPressed: () async {
              try {
                await ApiClient.instance.post('auth/verify', {'password': c.text});
                if (s.mounted) Navigator.pop(s, true);
              } catch (e) {
                if (s.mounted) showMessage(s, '$e');
              }
            })),
          ]),
        ]),
      ),
    );
    c.dispose();
    return ok == true;
  }

  Future<void> _add() async {
    final me = Scope.read(context).current.guid;
    final friends = await MoneyApi.instance.friends(me).catchError((_) => <EvUser>[]);
    if (!mounted) return;
    final pick = await Navigator.of(context).push<EvUser>(MaterialPageRoute(
      builder: (ctx) => Scaffold(
        appBar: AppBar(title: const Text('Add page admin')),
        body: ListView(children: [
          const Padding(padding: EdgeInsets.all(14), child: Text('Choose a friend to assign as an administrator:', style: TextStyle(color: EvColors.muted))),
          for (final f in friends) ListTile(leading: Avatar(f, size: 38), title: Text(f.fullname), trailing: FilledButton(onPressed: () => Navigator.pop(ctx, f), style: FilledButton.styleFrom(backgroundColor: EvColors.ember2, visualDensity: VisualDensity.compact), child: const Text('Add'))),
        ]),
      ),
    ));
    if (pick == null || !mounted) return;
    if (!await _confirmPassword(pick.fullname)) return;
    try {
      await MoreApi.instance.suiteAddManager(widget.page, pick.username, 'manager');
      if (mounted) showMessage(context, '${pick.firstName} is now an administrator.');
      _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Manage admin')),
        body: _team == null
            ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
            : ListView(padding: const EdgeInsets.all(16), children: [
                EvCard(
                  padding: EdgeInsets.zero,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Padding(padding: EdgeInsets.fromLTRB(16, 14, 16, 4), child: Text('Page administrators', style: TextStyle(fontWeight: FontWeight.w700))),
                    for (final m in _team!)
                      ListTile(
                        leading: Avatar(EvUser.fromJson(m), size: 38),
                        title: Text(EvUser.fromJson(m).fullname),
                        subtitle: Text(str(m, 'role', 'admin') == 'owner' ? 'Owner' : 'Admin', style: const TextStyle(fontSize: 12)),
                        trailing: str(m, 'role') == 'owner'
                            ? null
                            : TextButton(
                                onPressed: () async {
                                  try {
                                    await MoreApi.instance.suiteRemoveManager(widget.page, asInt(m['guid'] ?? m['member_guid']));
                                    _load();
                                  } catch (e) {
                                    if (mounted) showMessage(context, '$e');
                                  }
                                },
                                child: const Text('Remove', style: TextStyle(color: EvColors.red)),
                              ),
                      ),
                  ]),
                ),
                const SizedBox(height: 14),
                EmberButton('Add administrator', icon: Icons.person_add_alt_1_rounded, onPressed: _add),
              ]),
      );
}

/// Picks a picture and uploads it (page photo/cover, group cover).
/// Returns true when it was saved.
Future<bool> pickAndUpload(BuildContext context, String method, Map<String, Object?> fields, String field, {double maxWidth = 1600}) async {
  final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: maxWidth, imageQuality: 85);
  if (x == null || !context.mounted) return false;
  showMessage(context, 'Uploading…');
  try {
    await ApiClient.instance.upload(method, fields, field, File(x.path));
    if (context.mounted) showMessage(context, 'Picture updated.');
    return true;
  } catch (e) {
    if (context.mounted) showMessage(context, '$e');
    return false;
  }
}
