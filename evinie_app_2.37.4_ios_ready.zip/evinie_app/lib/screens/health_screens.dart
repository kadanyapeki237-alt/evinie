import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../api/api_client.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api/more_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../models/money.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'money_screens.dart';
import 'settings_screens.dart';

const _gold = Color(0xFFC9960C);
const _healthDark = Color(0xFF17151F);

Future<void> openExternal(String url) async {
  final uri = Uri.tryParse(url);
  if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
}

/// iHealth Assist: consent first, then the sections switched on in admin.
class HealthHome extends StatefulWidget {
  const HealthHome({super.key});
  @override
  State<HealthHome> createState() => _HealthHomeState();
}

class _HealthHomeState extends State<HealthHome> {
  Map? _s;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await MoreApi.instance.healthStatus();
      if (mounted) setState(() => _s = s);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return Scaffold(appBar: AppBar(title: const Text('iHealth Assist')), body: StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't open iHealth Assist", body: _error!, action: 'Try again', onAction: _load));
    final s = _s;
    if (s == null) return Scaffold(appBar: AppBar(title: const Text('iHealth Assist')), body: const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    final ai = asBool(s['assistant_on']);
    final docs = asBool(s['consultations_on']);
    final emergency = str(s, 'emergency_number', '112');
    if (!ai && !docs) return Scaffold(appBar: AppBar(title: const Text('iHealth Assist')), body: const StateMessage(icon: Icons.health_and_safety_outlined, title: 'Not available yet', body: 'iHealth Assist will open here soon.'));
    if (!asBool(s['consented'])) return _Consent(emergency: emergency, onDone: _load);
    final tabs = [if (ai) 'AI Assistant', if (docs) 'Doctors', if (docs) 'Appointments'];
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: _healthDark,
          foregroundColor: Colors.white,
          title: const Row(children: [Icon(Icons.add_box_rounded, color: _gold), SizedBox(width: 8), Text('iHealth Assist', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700))]),
          actions: [
            if (docs) IconButton(tooltip: 'Hospitals & pharmacies', icon: const Icon(Icons.local_hospital_outlined, color: Colors.white), onPressed: () => push(context, const PartnersScreen())),
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: IconButton.filled(tooltip: 'Emergency $emergency', onPressed: () => openExternal('tel:$emergency'), icon: const Icon(Icons.call_rounded, size: 18), style: IconButton.styleFrom(backgroundColor: const Color(0xFFD93025))),
            ),
          ],
          bottom: tabs.length > 1 ? TabBar(tabs: [for (final t in tabs) Tab(text: t)], labelColor: Colors.white, unselectedLabelColor: Colors.white60, indicatorColor: _gold) : null,
        ),
        body: Column(children: [
          Material(
            color: const Color(0xFFFFF6E5),
            child: InkWell(
              onTap: () => push(context, const DoctorApplyScreen()),
              child: const Padding(padding: EdgeInsets.symmetric(horizontal: 16, vertical: 9), child: Row(children: [Icon(Icons.medical_services_outlined, color: Color(0xFFC9960C), size: 18), SizedBox(width: 8), Expanded(child: Text('Are you a doctor? Apply to consult on Evinie', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5))), Icon(Icons.chevron_right_rounded, size: 18)])),
            ),
          ),
          Expanded(child: TabBarView(children: [
          if (ai) _AiChat(status: s),
          if (docs) const _Doctors(),
          if (docs) const _Appointments(),
        ])),
        ]),
      ),
    );
  }
}

class _Consent extends StatefulWidget {
  final String emergency;
  final VoidCallback onDone;
  const _Consent({required this.emergency, required this.onDone});
  @override
  State<_Consent> createState() => _ConsentState();
}

class _ConsentState extends State<_Consent> {
  bool _agree = false, _busy = false;
  @override
  Widget build(BuildContext context) {
    final points = [
      (Icons.auto_awesome_rounded, EvColors.ember2, 'An AI that explains symptoms, medicines and test results. It is not a doctor and cannot diagnose you.'),
      (Icons.call_rounded, EvColors.red, 'Not for emergencies. For chest pain, trouble breathing or heavy bleeding, call ${widget.emergency} or go to the nearest hospital.'),
      (Icons.block_rounded, EvColors.gold, 'It will not prescribe, or give doses for children or during pregnancy.'),
      (Icons.shield_outlined, EvColors.blue, 'Chats are private. Chats showing danger signs may be read by our medical reviewers.'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('iHealth Assist')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Center(child: Icon(Icons.add_box_rounded, color: _gold, size: 56)),
        const SizedBox(height: 8),
        const Text('Before you start', textAlign: TextAlign.center, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        const SizedBox(height: 16),
        EvCard(child: Column(children: [for (final p in points) Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Tile(p.$1, p.$2, size: 32), const SizedBox(width: 10), Expanded(child: Text(p.$3, style: const TextStyle(fontSize: 13, height: 1.45)))]))])),
        CheckboxListTile(value: _agree, onChanged: (v) => setState(() => _agree = v ?? false), activeColor: EvColors.ember2, contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, title: const Text('I understand and agree', style: TextStyle(fontWeight: FontWeight.w600))),
        const SizedBox(height: 8),
        EmberButton('Start using iHealth Assist', loading: _busy, onPressed: !_agree
            ? null
            : () async {
                setState(() => _busy = true);
                try {
                  await MoreApi.instance.healthConsent();
                  widget.onDone();
                } catch (e) {
                  if (mounted) showMessage(context, '$e');
                } finally {
                  if (mounted) setState(() => _busy = false);
                }
              }),
      ]),
    );
  }
}

class _Bubble {
  final String text;
  final bool mine;
  final List<String> flags;
  _Bubble(this.text, this.mine, [this.flags = const []]);
}

class _AiChat extends StatefulWidget {
  final Map status;
  const _AiChat({required this.status});
  @override
  State<_AiChat> createState() => _AiChatState();
}

class _AiChatState extends State<_AiChat> with AutomaticKeepAliveClientMixin {
  final _text = TextEditingController();
  final _scroll = ScrollController();
  final _msgs = <_Bubble>[];
  int _chat = 0;
  int? _left;
  bool _busy = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    final q = widget.status['questions_left'];
    _left = q == null ? null : asInt(q);
  }

  @override
  void dispose() {
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final t = _text.text.trim();
    if (t.isEmpty || _busy) return;
    _text.clear();
    setState(() {
      _msgs.add(_Bubble(t, true));
      _busy = true;
    });
    _down();
    try {
      final r = await MoreApi.instance.ask(t, _chat);
      final flags = (r['flags'] is List) ? (r['flags'] as List).map((f) => '$f').toList() : <String>[];
      setState(() {
        _chat = asInt(r['chat']);
        _msgs.add(_Bubble(str(r, 'reply'), false, flags));
        if (r['remaining'] != null) _left = asInt(r['remaining']);
      });
    } catch (e) {
      final code = '$e';
      setState(() => _msgs.add(_Bubble(
          code == 'limit'
              ? "You've used today's free questions. Upgrade for unlimited questions, or come back tomorrow."
              : code == 'unavailable'
                  ? 'The assistant is not available right now. Please try again later.'
                  : code == 'ai'
                      ? "I couldn't answer just now. Please try again in a moment."
                      : code,
          false,
          code == 'limit' ? ['limit'] : const [])));
    } finally {
      if (mounted) setState(() => _busy = false);
      _down();
    }
  }

  void _down() => WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });

  Widget _alert(String flag) {
    final emergency = str(widget.status, 'emergency_number', '112');
    if (flag == 'emergency') {
      return _AlertCard(color: EvColors.red, title: 'This could be an emergency', body: "Call $emergency or go to the nearest hospital now. Don't wait for an online answer.", action: 'Call $emergency', onAction: () => openExternal('tel:$emergency'));
    }
    if (flag == 'selfharm') {
      final lines = <String>[];
      final raw = widget.status['crisis_lines'];
      if (raw is List) {
        for (final l in raw) {
          lines.add(l is Map ? '${str(l, 'name', str(l, 'label'))}: ${str(l, 'number', str(l, 'phone'))}' : '$l');
        }
      }
      return _AlertCard(color: const Color(0xFF7C4DFF), title: "You don't have to face this alone", body: 'If you might hurt yourself, please talk to someone now.${lines.isEmpty ? '' : '\n${lines.join('\n')}'}\nIn danger right now: call $emergency.', action: 'Call $emergency', onAction: () => openExternal('tel:$emergency'));
    }
    if (flag == 'limit' && !AppConfig.storeSafe) {
      return _AlertCard(color: EvColors.ember2, title: 'Want unlimited questions?', body: 'EviEarners and verified members can ask as many questions as they like.', action: 'Upgrade', onAction: () => startEviEarnerUpgrade(context));
    }
    return const SizedBox.shrink();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(children: [
      Expanded(
        child: _msgs.isEmpty
            ? const StateMessage(icon: Icons.auto_awesome_rounded, title: 'Ask a health question', body: 'For example: "What does a high white blood cell count mean?" Answers are general information, not a diagnosis.')
            : ListView(
                controller: _scroll,
                padding: const EdgeInsets.all(12),
                children: [
                  for (final m in _msgs) ...[
                    for (final f in m.flags) _alert(f),
                    Align(
                      alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
                        decoration: BoxDecoration(gradient: m.mine ? EvColors.emberGradient : null, color: m.mine ? null : Colors.white, borderRadius: BorderRadius.circular(16)),
                        child: Text(m.text, style: TextStyle(color: m.mine ? Colors.white : EvColors.ink, fontSize: 14, height: 1.45)),
                      ),
                    ),
                  ],
                  if (_busy) const Padding(padding: EdgeInsets.all(8), child: Text('Thinking…', style: TextStyle(color: EvColors.muted))),
                ],
              ),
      ),
      Container(
        color: Colors.white,
        padding: EdgeInsets.fromLTRB(12, 6, 12, 8 + MediaQuery.of(context).padding.bottom),
        child: Column(children: [
          if (_left != null) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text('$_left free questions left today', style: const TextStyle(color: EvColors.muted, fontSize: 11.5))),
          Row(children: [
            Expanded(child: TextField(controller: _text, minLines: 1, maxLines: 4, textCapitalization: TextCapitalization.sentences, decoration: const InputDecoration(hintText: 'Type your health question…'))),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: _busy ? null : _send, icon: const Icon(Icons.send_rounded), style: IconButton.styleFrom(backgroundColor: EvColors.ember2)),
          ]),
          const Padding(padding: EdgeInsets.only(top: 4), child: Text('General information, not a diagnosis.', style: TextStyle(color: EvColors.muted, fontSize: 10.5))),
        ]),
      ),
    ]);
  }
}

class _AlertCard extends StatelessWidget {
  final Color color;
  final String title, body, action;
  final VoidCallback onAction;
  const _AlertCard({required this.color, required this.title, required this.body, required this.action, required this.onAction});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14), border: Border.all(color: color, width: 1.5)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(body, style: const TextStyle(fontSize: 13, height: 1.45)),
          const SizedBox(height: 8),
          FilledButton(onPressed: onAction, style: FilledButton.styleFrom(backgroundColor: color), child: Text(action)),
        ]),
      );
}

String _name(dynamic d) => d is Map ? EvUser.fromJson(d).fullname : asStr(d);

class _Doctors extends StatefulWidget {
  const _Doctors();
  @override
  State<_Doctors> createState() => _DoctorsState();
}

class _DoctorsState extends State<_Doctors> with AutomaticKeepAliveClientMixin {
  List<Map>? _list;
  String? _error;
  @override
  bool get wantKeepAlive => true;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await MoreApi.instance.doctors();
      final l = listOf(d['list'])..sort((a, b) => (asBool(b['available_now']) ? 1 : 0) - (asBool(a['available_now']) ? 1 : 0));
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_error != null) return StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load doctors", body: _error!, action: 'Try again', onAction: _load);
    if (_list == null) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    if (_list!.isEmpty) return const StateMessage(icon: Icons.medical_services_outlined, title: 'No doctors yet', body: 'Verified doctors will be listed here.');
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _list!.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (_, i) {
          final d = _list![i];
          final live = asBool(d['available_now']);
          final user = d['doctor'] is Map ? EvUser.fromJson(d['doctor'] as Map) : EvUser(guid: asInt(d['guid']), fullname: _name(d['doctor']));
          return GestureDetector(
            onTap: () => push(context, _DoctorScreen(guid: asInt(d['guid']), summary: d)),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: live ? const Color(0xFF2E9E5B) : Colors.transparent, width: 1.5)),
              child: Row(children: [
                Avatar(user, size: 54),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    if (live) const Text('● Available now', style: TextStyle(color: Color(0xFF2E9E5B), fontWeight: FontWeight.w700, fontSize: 11.5)),
                    Text('Dr ${user.fullname}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    Text('${str(d, 'specialty_label', str(d, 'specialty'))}${asInt(d['years']) > 0 ? ' · ${asInt(d['years'])} years' : ''}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                    const SizedBox(height: 4),
                    Text('${naira(asDouble(d['fee']))} / ${asInt(d['minutes']) > 0 ? asInt(d['minutes']) : 30} min', style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700)),
                  ]),
                ),
                const Icon(Icons.chevron_right_rounded, color: EvColors.muted),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _DoctorScreen extends StatefulWidget {
  final int guid;
  final Map summary;
  const _DoctorScreen({required this.guid, required this.summary});
  @override
  State<_DoctorScreen> createState() => _DoctorScreenState();
}

class _DoctorScreenState extends State<_DoctorScreen> {
  Map? _d;
  String? _when;
  String _mode = 'video';
  final _reason = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    MoreApi.instance.doctor(widget.guid).then((d) {
      if (mounted) setState(() => _d = d);
    }).catchError((e) {
      if (mounted) showMessage(context, '$e');
    });
    if (asBool(widget.summary['available_now'])) _when = 'now';
  }

  @override
  void dispose() {
    _reason.dispose();
    super.dispose();
  }

  Future<void> _book(String pay) async {
    if (_when == null) return showMessage(context, 'Choose Talk now or a time.');
    setState(() => _busy = true);
    try {
      final r = await MoreApi.instance.book(doctor: widget.guid, when: _when!, mode: _mode, pay: pay, reason: _reason.text.trim());
      if (!mounted) return;
      if (pay == 'card') {
        final link = str(r, 'payment_link');
        if (link.isNotEmpty) await openExternal(link);
        if (mounted) showMessage(context, 'Finish paying in your browser. Your booking appears in Appointments once the payment is confirmed.');
      } else {
        await showDialog<void>(context: context, builder: (_) => AlertDialog(icon: const Icon(Icons.check_circle_rounded, color: EvColors.green, size: 46), title: const Text('Booked'), content: Text(_when == 'now' ? 'The doctor has been told. Open Appointments to start.' : 'You can find this in Appointments.', textAlign: TextAlign.center), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));
        if (mounted) Navigator.of(context).pop();
      }
    } catch (e) {
      const words = {'funds': 'Your Wallet balance is too low. Add money or pay by card.', 'slot': 'That time was just taken. Please choose another.', 'notnow': 'The doctor is no longer available right now.', 'unavailable': 'Bookings are not available at the moment.', 'self': "You can't book yourself."};
      if (mounted) showMessage(context, words['$e'] ?? '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.summary;
    final d = _d;
    final live = asBool(s['available_now']);
    final user = s['doctor'] is Map ? EvUser.fromJson(s['doctor'] as Map) : EvUser(guid: widget.guid, fullname: _name(s['doctor']));
    final days = listOf(d?['slots']);
    final cards = d != null && asBool(d['card_payments']) && !AppConfig.storeSafe;
    Widget choice(String value, String label) => ChoiceChip(label: Text(label), selected: _when == value, onSelected: (_) => setState(() => _when = value), selectedColor: EvColors.ember2, labelStyle: TextStyle(color: _when == value ? Colors.white : EvColors.ink, fontSize: 12.5));
    return Scaffold(
      appBar: AppBar(title: Text('Dr ${user.fullname}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [Avatar(user, size: 64), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Dr ${user.fullname}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)), Text('${str(s, 'specialty_label')} · MDCN ${str(s, 'mdcn', '—')}', style: const TextStyle(color: EvColors.muted, fontSize: 12.5)), Text('${naira(asDouble(s['fee']))} per consultation', style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700))]))]),
        if (str(s, 'bio').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(str(s, 'bio'), style: const TextStyle(height: 1.5, color: EvColors.ink2))),
        const SizedBox(height: 16),
        const Text('When', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        if (live) Padding(padding: const EdgeInsets.only(bottom: 8), child: choice('now', 'Talk now')),
        if (d == null) const LinearProgressIndicator(color: EvColors.ember2),
        for (final day in days) ...[
          Padding(padding: const EdgeInsets.only(top: 6, bottom: 4), child: Text(str(day, 'label', str(day, 'date')), style: const TextStyle(color: EvColors.muted, fontSize: 12.5))),
          Wrap(spacing: 6, runSpacing: 6, children: [for (final t in listOf(day['times'])) choice(str(t, 'when'), str(t, 'time'))]),
        ],
        if (d != null && days.isEmpty && !live) const Text('No times available in the next few days.', style: TextStyle(color: EvColors.muted)),
        const SizedBox(height: 16),
        const Text('Consultation', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'video', label: Text('Video call'), icon: Icon(Icons.videocam_outlined)), ButtonSegment(value: 'chat', label: Text('Chat'), icon: Icon(Icons.chat_bubble_outline_rounded))], selected: {_mode}, onSelectionChanged: (v) => setState(() => _mode = v.first)),
        const SizedBox(height: 12),
        TextField(controller: _reason, maxLines: 2, decoration: const InputDecoration(hintText: 'What would you like to discuss? (optional)')),
        const SizedBox(height: 18),
        if (AppConfig.storeSafe)
          const Text('Consultations can be booked on the Evinie website.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))
        else ...[
          EmberButton(d == null ? 'Pay from Wallet' : 'Pay from Wallet · balance ${naira(asDouble(d['wallet_balance']))}', icon: Icons.account_balance_wallet_outlined, loading: _busy, onPressed: () => _book('wallet')),
          if (cards) ...[const SizedBox(height: 8), OutlineEmberButton('Pay by card, transfer or USSD', onPressed: _busy ? null : () => _book('card'))],
          const SizedBox(height: 8),
          const Text('Held by Evinie until the consultation is completed. Full refund to your Wallet if the doctor does not reply.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontSize: 12)),
        ],
      ]),
    );
  }
}

class _Appointments extends StatefulWidget {
  const _Appointments();
  @override
  State<_Appointments> createState() => _AppointmentsState();
}

class _AppointmentsState extends State<_Appointments> with AutomaticKeepAliveClientMixin {
  List<Map>? _mine, _patients;
  String? _error;
  @override
  bool get wantKeepAlive => true;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final a = await MoreApi.instance.appointments();
      if (mounted) {
        setState(() {
          _mine = listOf(a['mine']);
          _patients = listOf(a['patients']);
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  Widget _row(Map b, bool asDoctor) {
    final other = asDoctor ? (b['patient'] ?? b['member']) : (b['doctor'] ?? b['doctor_name']);
    final status = str(b, 'status', 'booked');
    return EvCard(
      padding: EdgeInsets.zero,
      child: ListTile(
        onTap: () => push(context, _Consultation(booking: b, asDoctor: asDoctor)),
        leading: Tile(str(b, 'mode') == 'chat' ? Icons.chat_bubble_outline_rounded : Icons.videocam_outlined, EvColors.ember2),
        title: Text(asDoctor ? _name(other) : 'Dr ${_name(other)}', style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(str(b, 'slot_text', str(b, 'when_text', str(b, 'time'))), style: const TextStyle(color: EvColors.muted, fontSize: 12)),
        trailing: StatusChip(status),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    if (_error != null) return StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load appointments", body: _error!, action: 'Try again', onAction: _load);
    if (_mine == null) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    if (_mine!.isEmpty && _patients!.isEmpty) return const StateMessage(icon: Icons.event_available_outlined, title: 'No appointments yet', body: 'Book a doctor from the Doctors tab.');
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        if (_patients!.isNotEmpty) ...[const Text('Your patients', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8), for (final b in _patients!) Padding(padding: const EdgeInsets.only(bottom: 8), child: _row(b, true)), const SizedBox(height: 10)],
        if (_mine!.isNotEmpty) ...[const Text('My appointments', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 8), for (final b in _mine!) Padding(padding: const EdgeInsets.only(bottom: 8), child: _row(b, false))],
      ]),
    );
  }
}

class _Consultation extends StatefulWidget {
  final Map booking;
  final bool asDoctor;
  const _Consultation({required this.booking, required this.asDoctor});
  @override
  State<_Consultation> createState() => _ConsultationState();
}

class _ConsultationState extends State<_Consultation> {
  final _text = TextEditingController();
  List<Map> _msgs = [];
  Map _info = const {};
  bool _sending = false;
  int get _id => asInt(widget.booking['guid'] ?? widget.booking['booking']);

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final c = await MoreApi.instance.consultation(_id);
      if (mounted) {
        setState(() {
          _info = c;
          _msgs = listOf(c['messages'] ?? c['list']);
        });
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  Future<void> _send() async {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    setState(() => _sending = true);
    try {
      await MoreApi.instance.consultSend(_id, t);
      _text.clear();
      await _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final b = {...widget.booking, ...mapOf(_info['booking'])};
    final video = str(b, 'video_url', str(b, 'join_url', str(b, 'room_url', str(_info, 'video_url'))));
    final status = str(b, 'status', 'booked').toLowerCase();
    final me = Scope.of(context).current.guid;
    return Scaffold(
      appBar: AppBar(title: const Text('Consultation'), actions: [StatusChip(status), const SizedBox(width: 12)]),
      body: Column(children: [
        if (video.isNotEmpty && !status.contains('complete') && !status.contains('cancel'))
          Padding(padding: const EdgeInsets.all(12), child: EmberButton('Join video call', icon: Icons.videocam_rounded, onPressed: () => openExternal(video))),
        Expanded(
          child: _msgs.isEmpty
              ? const StateMessage(icon: Icons.chat_bubble_outline_rounded, title: 'No messages yet', body: 'Messages with your doctor appear here.')
              : ListView(padding: const EdgeInsets.all(12), children: [
                  for (final m in _msgs)
                    Builder(builder: (_) {
                      final mine = asBool(m['mine']) || asInt(m['owner_guid'] ?? m['from']) == me;
                      return Align(
                        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                          decoration: BoxDecoration(gradient: mine ? EvColors.emberGradient : null, color: mine ? null : Colors.white, borderRadius: BorderRadius.circular(16)),
                          child: Text(str(m, 'text', str(m, 'message')), style: TextStyle(color: mine ? Colors.white : EvColors.ink, height: 1.4)),
                        ),
                      );
                    }),
                ]),
        ),
        if (!widget.asDoctor && status.contains('complete'))
          Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: OutlineEmberButton('Send prescription to a pharmacy', onPressed: () => sendPrescription(context, _id))),
        if (!widget.asDoctor && (status == 'booked' || status == 'pending'))
          TextButton(
            onPressed: () async {
              try {
                await MoreApi.instance.cancelBooking(_id);
                if (mounted) {
                  showMessage(context, 'Cancelled. The full amount goes back to your Wallet.');
                  Navigator.of(context).pop();
                }
              } catch (e) {
                if (mounted) showMessage(context, '$e');
              }
            },
            child: const Text('Cancel booking', style: TextStyle(color: EvColors.red)),
          ),
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(12, 8, 12, 8 + MediaQuery.of(context).padding.bottom),
          child: Row(children: [
            Expanded(child: TextField(controller: _text, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'Write a message…'))),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: _sending ? null : _send, icon: const Icon(Icons.send_rounded), style: IconButton.styleFrom(backgroundColor: EvColors.ember2)),
          ]),
        ),
      ]),
    );
  }
}


/// iHealth Assist: apply as a doctor, or update the doctor profile
/// (EndPoints 4.40 ihealth/apply - the same form as the website).
class DoctorApplyScreen extends StatefulWidget {
  const DoctorApplyScreen({super.key});
  @override
  State<DoctorApplyScreen> createState() => _DoctorApplyScreenState();
}

class _DoctorApplyScreenState extends State<DoctorApplyScreen> {
  static const _days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  Map? _doctor;
  List<Map> _specs = [];
  String? _error;
  bool _loading = true, _busy = false;
  String _specialty = 'general';
  int _minutes = 30;
  final _mdcn = TextEditingController(), _years = TextEditingController(), _langs = TextEditingController(), _fee = TextEditingController(), _bio = TextEditingController();
  final Map<int, (TimeOfDay?, TimeOfDay?)> _hours = {};
  File? _licence;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_mdcn, _years, _langs, _fee, _bio]) {
      c.dispose();
    }
    super.dispose();
  }

  TimeOfDay? _t(dynamic v) {
    final p = asStr(v).split(':');
    if (p.length < 2) return null;
    final h = int.tryParse(p[0]), m = int.tryParse(p[1]);
    return (h == null || m == null) ? null : TimeOfDay(hour: h, minute: m);
  }

  String _hm(TimeOfDay? t) => t == null ? '' : '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  void _fill(Map r) {
    _specs = listOf(r['specialties']);
    final d = r['doctor'] is Map ? r['doctor'] as Map : null;
    _doctor = d;
    if (d != null) {
      _specialty = str(d, 'specialty', 'general');
      _minutes = asInt(d['minutes']) > 0 ? asInt(d['minutes']) : 30;
      _mdcn.text = str(d, 'mdcn');
      _years.text = asInt(d['years']) > 0 ? '${asInt(d['years'])}' : '';
      _langs.text = str(d, 'languages');
      _fee.text = asDouble(d['fee']) > 0 ? asDouble(d['fee']).toStringAsFixed(0) : '';
      _bio.text = str(d, 'bio');
      final h = d['hours'] is Map ? d['hours'] as Map : const {};
      _hours.clear();
      h.forEach((k, v) {
        final day = int.tryParse('$k') ?? 0;
        if (day >= 1 && day <= 7 && v is List && v.length >= 2) _hours[day] = (_t(v[0]), _t(v[1]));
      });
    }
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final r = mapOf(await ApiClient.instance.post('ihealth/apply', {'mode': 'get'}));
      if (mounted) setState(() => _fill(r));
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pickLicence() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png']);
    final path = r?.files.single.path;
    if (path != null && mounted) setState(() => _licence = File(path));
  }

  Future<void> _pickTime(int day, bool start) async {
    final cur = _hours[day] ?? (null, null);
    final t = await showTimePicker(context: context, initialTime: (start ? cur.$1 : cur.$2) ?? TimeOfDay(hour: start ? 9 : 17, minute: 0));
    if (t == null || !mounted) return;
    setState(() => _hours[day] = start ? (t, cur.$2) : (cur.$1, t));
  }

  Future<void> _save() async {
    if (_mdcn.text.trim().isEmpty) return showMessage(context, 'Please enter your MDCN registration number.');
    if (_doctor == null && _licence == null) return showMessage(context, 'Please upload your practising licence (JPG, PNG or PDF).');
    final fields = <String, Object?>{
      'specialty': _specialty,
      'mdcn': _mdcn.text.trim(),
      'years': _years.text.trim(),
      'languages': _langs.text.trim(),
      'fee': _fee.text.trim().replaceAll(',', ''),
      'minutes': _minutes,
      'bio': _bio.text.trim(),
      for (var d = 1; d <= 7; d++) ...{
        'hours_${d}_start': _hm(_hours[d]?.$1),
        'hours_${d}_end': _hm(_hours[d]?.$2),
      },
    };
    setState(() => _busy = true);
    try {
      final r = mapOf(_licence != null ? await ApiClient.instance.upload('ihealth/apply', fields, 'licence', _licence!) : await ApiClient.instance.post('ihealth/apply', fields));
      if (!mounted) return;
      setState(() {
        _fill(r);
        _licence = null;
      });
      showMessage(context, str(r, 'message', 'Saved.'));
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _availability(int hours) async {
    try {
      await ApiClient.instance.post('ihealth/available', {'hours': hours});
      if (mounted) showMessage(context, hours > 0 ? 'You are available for Talk now for $hours hour${hours == 1 ? '' : 's'}.' : 'Talk now is off.');
      _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  Widget _label(String t) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 6), child: Text(t, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)));

  @override
  Widget build(BuildContext context) {
    final d = _doctor;
    final status = d == null ? '' : str(d, 'status');
    final approved = status == 'approved';
    return Scaffold(
      appBar: AppBar(title: Text(d == null ? 'Apply as a doctor' : 'My doctor profile')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: _gold, strokeWidth: 2.4))
          : _error != null
              ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load", body: _error!, action: 'Try again', onAction: _load)
              : ListView(padding: EdgeInsets.fromLTRB(16, 12, 16, 32 + MediaQuery.of(context).padding.bottom), children: [
                  if (d == null)
                    const Text('Consult with Evinie members by chat or video. Fill in your details and upload your practising licence. Evinie checks every application before your profile goes live.', style: TextStyle(color: EvColors.muted, height: 1.4))
                  else
                    EvCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Icon(approved ? Icons.verified_rounded : (status == 'rejected' ? Icons.cancel_rounded : Icons.hourglass_top_rounded), color: approved ? EvColors.green : (status == 'rejected' ? EvColors.red : _gold)),
                          const SizedBox(width: 8),
                          Expanded(child: Text(str(d, 'status_label', status), style: const TextStyle(fontWeight: FontWeight.w700))),
                        ]),
                        if (status == 'rejected' && str(d, 'decision').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Reason: ${str(d, 'decision')}', style: const TextStyle(color: EvColors.muted))),
                        if (status == 'pending') const Padding(padding: EdgeInsets.only(top: 6), child: Text('Evinie is checking your details. You will be told when it is done.', style: TextStyle(color: EvColors.muted, fontSize: 12.5))),
                        if (approved) ...[
                          const SizedBox(height: 10),
                          Text(asBool(d['available_now']) ? 'You are available for Talk now.' : 'Turn on Talk now so members can reach you straight away.', style: const TextStyle(fontSize: 12.5)),
                          const SizedBox(height: 8),
                          Wrap(spacing: 8, runSpacing: 8, children: [
                            if (asBool(d['available_now']) || asInt(d['available_until']) * 1000 > DateTime.now().millisecondsSinceEpoch)
                              OutlinedButton(onPressed: () => _availability(0), child: const Text('Turn off'))
                            else
                              for (final h in const [1, 2, 4, 8]) OutlinedButton(onPressed: () => _availability(h), child: Text('$h h')),
                          ]),
                        ],
                      ]),
                    ),
                  _label('Specialty'),
                  DropdownButtonFormField<String>(
                    value: _specs.any((x) => str(x, 'key') == _specialty) ? _specialty : (_specs.isNotEmpty ? str(_specs.first, 'key') : null),
                    isExpanded: true,
                    items: [for (final x in _specs) DropdownMenuItem(value: str(x, 'key'), child: Text(str(x, 'label', str(x, 'key'))))],
                    onChanged: (v) => setState(() => _specialty = v ?? 'general'),
                  ),
                  _label('MDCN registration number'),
                  TextField(controller: _mdcn, textCapitalization: TextCapitalization.characters, maxLength: 40, decoration: const InputDecoration(counterText: '', hintText: 'e.g. MDCN/R/12345')),
                  Row(children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_label('Years of practice'), TextField(controller: _years, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: '0'))])),
                    const SizedBox(width: 10),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_label('Fee per consultation (₦)'), TextField(controller: _fee, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(hintText: '0 = free'))])),
                  ]),
                  _label('Consultation length'),
                  DropdownButtonFormField<int>(
                    value: const [15, 20, 30, 45, 60].contains(_minutes) ? _minutes : 30,
                    items: [for (final m in const [15, 20, 30, 45, 60]) DropdownMenuItem(value: m, child: Text('$m minutes'))],
                    onChanged: (v) => setState(() => _minutes = v ?? 30),
                  ),
                  _label('Languages'),
                  TextField(controller: _langs, maxLength: 120, decoration: const InputDecoration(counterText: '', hintText: 'English, Yoruba')),
                  _label('About you'),
                  TextField(controller: _bio, maxLines: 4, maxLength: 800, decoration: const InputDecoration(hintText: 'Your experience and what you can help with')),
                  _label('Weekly hours'),
                  const Text('Leave a day empty if you are not available that day.', style: TextStyle(color: EvColors.muted, fontSize: 12)),
                  const SizedBox(height: 6),
                  for (var day = 1; day <= 7; day++)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Row(children: [
                        SizedBox(width: 92, child: Text(_days[day - 1], style: const TextStyle(fontSize: 13))),
                        Expanded(child: OutlinedButton(onPressed: () => _pickTime(day, true), child: Text(_hours[day]?.$1 == null ? 'Start' : _hm(_hours[day]!.$1)))),
                        const Padding(padding: EdgeInsets.symmetric(horizontal: 6), child: Text('–')),
                        Expanded(child: OutlinedButton(onPressed: () => _pickTime(day, false), child: Text(_hours[day]?.$2 == null ? 'End' : _hm(_hours[day]!.$2)))),
                        IconButton(tooltip: 'Clear', icon: const Icon(Icons.close_rounded, size: 18), onPressed: _hours[day] == null ? null : () => setState(() => _hours.remove(day))),
                      ]),
                    ),
                  _label(d == null ? 'Practising licence' : 'Replace practising licence (optional)'),
                  OutlinedButton.icon(
                    onPressed: _pickLicence,
                    icon: const Icon(Icons.upload_file_rounded),
                    label: Text(_licence == null ? (d != null && asBool(d['has_licence']) ? 'Licence uploaded · choose a new file' : 'Choose file (JPG, PNG or PDF)') : _licence!.path.split(Platform.pathSeparator).last, overflow: TextOverflow.ellipsis),
                  ),
                  if (d != null && approved) const Padding(padding: EdgeInsets.only(top: 6), child: Text('Changing your MDCN number or licence sends your profile back to Evinie for checking.', style: TextStyle(color: EvColors.muted, fontSize: 12))),
                  const SizedBox(height: 20),
                  EmberButton(d == null ? 'Submit application' : 'Save changes', loading: _busy, onPressed: _busy ? null : _save),
                ]),
    );
  }
}
