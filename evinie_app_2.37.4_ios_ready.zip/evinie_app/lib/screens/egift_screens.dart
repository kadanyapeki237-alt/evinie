import '../state/media_cache.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../api/money_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../models/money.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';

class GiftIcon extends StatelessWidget {
  final String url;
  final double size;
  final String title;
  const GiftIcon(this.url, {super.key, this.size = 44, this.title = ''});

  /// A picture for a gift without one: emoji matched to the gift's name.
  static String emojiFor(String title) {
    final t = title.toLowerCase();
    const map = {
      'rose': '🌹', 'flower': '💐', 'bouquet': '💐', 'cake': '🎂', 'birthday': '🎂', 'teddy': '🧸', 'bear': '🧸',
      'heart': '❤️', 'love': '💖', 'kiss': '💋', 'coffee': '☕', 'tea': '🍵', 'drink': '🥤', 'wine': '🍷', 'champagne': '🍾',
      'beer': '🍺', 'pizza': '🍕', 'burger': '🍔', 'chocolate': '🍫', 'candy': '🍬', 'ice': '🍦', 'car': '🚗', 'plane': '✈️',
      'diamond': '💎', 'ring': '💍', 'crown': '👑', 'king': '👑', 'queen': '👸', 'star': '⭐', 'trophy': '🏆', 'medal': '🏅',
      'balloon': '🎈', 'party': '🎉', 'fire': '🔥', 'money': '💸', 'cash': '💵', 'gold': '🥇', 'music': '🎵', 'phone': '📱', 'perfume': '🌸',
    };
    for (final e in map.entries) {
      if (t.contains(e.key)) return e.value;
    }
    return '🎁';
  }

  Widget _fallback() => Container(
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFFFFE3D1), Color(0xFFFFC7A6)], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: BorderRadius.circular(size * 0.28)),
        alignment: Alignment.center,
        child: Text(emojiFor(title), style: TextStyle(fontSize: size * 0.55)),
      );

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: url.isEmpty ? _fallback() : CachedNetworkImage(cacheManager: evCache, imageUrl: url, fit: BoxFit.contain, errorWidget: (_, __, ___) => _fallback()),
      );
}

/// Catalog, Sent and Received. In a store-safe build the Catalog tab is
/// hidden (sending digital gifts needs the stores' in-app purchases).
class GiftsScreen extends StatelessWidget {
  const GiftsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final tabs = [if (!AppConfig.storeSafe) 'Catalog', 'Received', 'Sent'];
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('eGifts'),
          bottom: TabBar(tabs: [for (final t in tabs) Tab(text: t)], labelColor: EvColors.ember2, indicatorColor: EvColors.ember2, unselectedLabelColor: EvColors.muted, labelStyle: const TextStyle(fontFamily: 'Poppins', fontWeight: FontWeight.w700)),
        ),
        body: TabBarView(children: [
          if (!AppConfig.storeSafe) const _Catalog(),
          const _GiftHistory(received: true),
          const _GiftHistory(received: false),
        ]),
      ),
    );
  }
}

class _Catalog extends StatefulWidget {
  const _Catalog();
  @override
  State<_Catalog> createState() => _CatalogState();
}

class _CatalogState extends State<_Catalog> {
  List<Gift>? _gifts;
  String? _error;
  Gift? _picked;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final g = await MoneyApi.instance.gifts();
      if (mounted) setState(() => _gifts = g);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load gifts", body: _error!, action: 'Try again', onAction: _load);
    if (_gifts == null) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    if (_gifts!.isEmpty) return const StateMessage(icon: Icons.card_giftcard_rounded, title: 'No gifts available', body: 'Gifts will appear here when they are added.');
    return Column(children: [
      const Padding(padding: EdgeInsets.fromLTRB(16, 12, 16, 4), child: Text('Choose a gift. Your friend receives its value, less the platform fee.', style: TextStyle(color: EvColors.muted, fontSize: 12.5))),
      Expanded(
        child: GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.05),
          itemCount: _gifts!.length,
          itemBuilder: (_, i) {
            final g = _gifts![i];
            final on = _picked?.guid == g.guid;
            return GestureDetector(
              onTap: () => setState(() => _picked = g),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: on ? EvColors.ember1 : Colors.transparent, width: 2), boxShadow: const [BoxShadow(color: Color(0x0F1F1A17), blurRadius: 14, offset: Offset(0, 6))]),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  GiftIcon(g.icon, size: 52, title: g.title),
                  const SizedBox(height: 8),
                  Text(g.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text(naira(g.price), style: TextStyle(color: on ? EvColors.ember2 : EvColors.muted, fontWeight: FontWeight.w600, fontSize: 12.5)),
                ]),
              ),
            );
          },
        ),
      ),
      SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: EmberButton(_picked == null ? 'Choose a gift' : 'Continue with ${_picked!.title}', icon: Icons.arrow_forward_rounded, onPressed: _picked == null ? null : () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => _ChooseFriend(gift: _picked!)))),
        ),
      ),
    ]);
  }
}

class _ChooseFriend extends StatefulWidget {
  final Gift gift;
  const _ChooseFriend({required this.gift});
  @override
  State<_ChooseFriend> createState() => _ChooseFriendState();
}

class _ChooseFriendState extends State<_ChooseFriend> {
  List<EvUser>? _friends;
  String _q = '';

  @override
  void initState() {
    super.initState();
    MoneyApi.instance.friends(Scope.read(context).current.guid).then((f) {
      if (mounted) setState(() => _friends = f);
    }).catchError((e) {
      if (mounted) {
        setState(() => _friends = []);
        showMessage(context, '$e');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final list = (_friends ?? []).where((u) => u.fullname.toLowerCase().contains(_q.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Send to')),
      body: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 8), child: TextField(onChanged: (v) => setState(() => _q = v), decoration: const InputDecoration(hintText: 'Search friends', prefixIcon: Icon(Icons.search_rounded)))),
        Expanded(
          child: _friends == null
              ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
              : list.isEmpty
                  ? const StateMessage(icon: Icons.people_outline_rounded, title: 'No friends found', body: 'You can send gifts to people on your friends list.')
                  : ListView.separated(
                      itemCount: list.length,
                      separatorBuilder: (_, __) => const Divider(height: 1, indent: 72),
                      itemBuilder: (_, i) => ListTile(
                        tileColor: Colors.white,
                        leading: Avatar(list[i], size: 44),
                        title: NameLine(list[i], size: 14),
                        subtitle: list[i].username.isEmpty ? null : Text('@${list[i].username}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                        trailing: const Icon(Icons.chevron_right_rounded, color: EvColors.muted),
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => _ConfirmGift(gift: widget.gift, to: list[i]))),
                      ),
                    ),
        ),
      ]),
    );
  }
}

class _ConfirmGift extends StatefulWidget {
  final Gift gift;
  final EvUser to;
  const _ConfirmGift({required this.gift, required this.to});
  @override
  State<_ConfirmGift> createState() => _ConfirmGiftState();
}

class _ConfirmGiftState extends State<_ConfirmGift> {
  double? _balance;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    MoneyApi.instance.balance().then((b) {
      if (mounted) setState(() => _balance = b);
    }).catchError((_) {});
  }

  Future<void> _send() async {
    setState(() => _busy = true);
    try {
      final (sent, _) = await MoneyApi.instance.sendGift(widget.gift.guid, [widget.to.guid]);
      if (!mounted) return;
      if (sent > 0) {
        // Close Payment and Send to, then celebrate; "Back" returns to eGifts.
        final nav = Navigator.of(context);
        nav.pop();
        nav.pop();
        nav.push(MaterialPageRoute(builder: (_) => _GiftSent(gift: widget.gift, to: widget.to)));
      } else {
        showMessage(context, "The gift wasn't sent. Check your balance and try again.");
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final low = _balance != null && _balance! < widget.gift.price;
    return Scaffold(
      appBar: AppBar(title: const Text('Payment')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        EvCard(child: Row(children: [Avatar(widget.to, size: 46), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Sending to', style: TextStyle(color: EvColors.muted, fontSize: 12)), NameLine(widget.to, size: 15)]))])),
        const SizedBox(height: 12),
        EvCard(
          child: Row(children: [
            GiftIcon(widget.gift.icon, size: 46, title: widget.gift.title),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.gift.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)), const Text('eGift', style: TextStyle(color: EvColors.muted, fontSize: 12))])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [const Text('You pay', style: TextStyle(color: EvColors.muted, fontSize: 12)), Text(naira(widget.gift.price), style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 20))]),
          ]),
        ),
        const SizedBox(height: 12),
        EvCard(
          child: Row(children: [
            const Icon(Icons.account_balance_wallet_outlined, color: EvColors.green),
            const SizedBox(width: 10),
            const Expanded(child: Text('Pay from Wallet', style: TextStyle(fontWeight: FontWeight.w600))),
            _balance == null ? const Skeleton(width: 70) : Text(naira(_balance!), style: TextStyle(fontWeight: FontWeight.w700, color: low ? EvColors.red : EvColors.ink)),
          ]),
        ),
        if (low) const Padding(padding: EdgeInsets.only(top: 8), child: Text('Your balance is too low for this gift. Add money to your Wallet first.', style: TextStyle(color: EvColors.red, fontSize: 12.5))),
        const SizedBox(height: 22),
        EmberButton('Send gift', icon: Icons.card_giftcard_rounded, loading: _busy, onPressed: low ? null : _send),
      ]),
    );
  }
}

class _GiftSent extends StatelessWidget {
  final Gift gift;
  final EvUser to;
  const _GiftSent({required this.gift, required this.to});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(children: [
              const Spacer(),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.6, end: 1),
                duration: const Duration(milliseconds: 500),
                curve: Curves.elasticOut,
                builder: (_, v, child) => Transform.scale(scale: v, child: child),
                child: Container(width: 96, height: 96, decoration: BoxDecoration(color: EvColors.green, shape: BoxShape.circle, boxShadow: [BoxShadow(color: EvColors.green.withValues(alpha: 0.25), blurRadius: 0, spreadRadius: 12)]), child: const Icon(Icons.check_rounded, color: Colors.white, size: 52)),
              ),
              const SizedBox(height: 26),
              const Text('Gift sent!', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text('${to.fullname} received your ${gift.title}.', textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted)),
              const Spacer(),
              EmberButton('Back to eGifts', onPressed: () => Navigator.of(context).pop()),
            ]),
          ),
        ),
      );
}

class _GiftHistory extends StatefulWidget {
  final bool received;
  const _GiftHistory({required this.received});
  @override
  State<_GiftHistory> createState() => _GiftHistoryState();
}

class _GiftHistoryState extends State<_GiftHistory> {
  List<GiftEntry>? _list;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = widget.received ? await MoneyApi.instance.giftsReceived() : await MoneyApi.instance.giftsSent();
      if (mounted) setState(() => _list = l);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load gifts", body: _error!, action: 'Try again', onAction: _load);
    if (_list == null) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    if (_list!.isEmpty) {
      return StateMessage(icon: Icons.card_giftcard_rounded, title: widget.received ? 'No gifts yet' : 'You haven\'t sent a gift', body: widget.received ? 'Gifts from your audience will show here.' : 'Send a gift to a friend from the Catalog.');
    }
    final total = _list!.fold<double>(0, (a, g) => a + g.amount);
    return RefreshIndicator(
      color: EvColors.ember2,
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF2A211C), Color(0xFF14110F)]), borderRadius: BorderRadius.circular(22)),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.received ? 'Received in total' : 'Sent in total', style: const TextStyle(color: Colors.white60, fontSize: 12)), Text(naira(total), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w700))])),
            const Icon(Icons.card_giftcard_rounded, color: EvColors.gold, size: 36),
          ]),
        ),
        const SizedBox(height: 12),
        EvCard(
          padding: EdgeInsets.zero,
          child: Column(children: [
            for (var i = 0; i < _list!.length; i++) ...[
              if (i > 0) const Divider(height: 1, indent: 68),
              ListTile(
                leading: GiftIcon(_list![i].icon, size: 38),
                title: Text(_list![i].other?.fullname ?? _list![i].title, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                subtitle: Text('${_list![i].title} · ${timeAgo(_list![i].time)}', style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
                trailing: Text('${widget.received ? '+' : '−'}${naira(_list![i].amount)}', style: TextStyle(fontWeight: FontWeight.w700, color: widget.received ? EvColors.green : EvColors.ink)),
              ),
            ],
          ]),
        ),
      ]),
    );
  }
}
