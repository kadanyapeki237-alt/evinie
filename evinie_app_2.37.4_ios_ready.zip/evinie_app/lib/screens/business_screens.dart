import '../state/media_cache.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:share_plus/share_plus.dart';
import '../api/more_api.dart';
import '../config.dart';
import '../models/models.dart';
import '../models/money.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'money_screens.dart';

/// "paid_this_month" -> "Paid this month".
String humanize(String key) {
  final t = key.replaceAll(RegExp(r'[_\-]+'), ' ').trim();
  return t.isEmpty ? key : t[0].toUpperCase() + t.substring(1);
}

/// Money-looking keys are shown as naira; counts as plain numbers.
String figure(String key, dynamic v) {
  final k = key.toLowerCase();
  final money = ['paid', 'unpaid', 'overdue', 'profit', 'income', 'expense', 'total', 'amount', 'revenue', 'balance', 'sales', 'cost', 'fee', 'salary', 'earn'].any(k.contains);
  return money ? naira(asDouble(v)) : asStr(v);
}

/// Every number in a map, as labelled cards, so new fields from the
/// server still appear without an app update.
class FigureGrid extends StatelessWidget {
  final Map data;
  const FigureGrid(this.data, {super.key});
  @override
  Widget build(BuildContext context) {
    final entries = data.entries.where((e) => e.value is num || (e.value is String && double.tryParse(e.value) != null)).toList();
    if (entries.isEmpty) return const SizedBox.shrink();
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 2.1,
      children: [
        for (final e in entries)
          EvCard(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(figure('${e.key}', e.value), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              Text(humanize('${e.key}'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
            ]),
          ),
      ],
    );
  }
}

class MyBusinessesScreen extends StatefulWidget {
  const MyBusinessesScreen({super.key});
  @override
  State<MyBusinessesScreen> createState() => _MyBusinessesScreenState();
}

class _MyBusinessesScreenState extends State<MyBusinessesScreen> {
  List<Map>? _pages;
  String? _error;
  @override
  void initState() {
    super.initState();
    MoreApi.instance.myPages().then((p) {
      if (mounted) setState(() => _pages = p);
    }).catchError((e) {
      if (mounted) setState(() => _error = '$e');
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('My businesses')),
        body: _error != null
            ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load your pages", body: _error!)
            : _pages == null
                ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
                : _pages!.isEmpty
                    ? const StateMessage(icon: Icons.storefront_outlined, title: 'No business pages yet', body: 'Create a business page on Evinie, then manage it here.')
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _pages!.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, i) {
                          final p = _pages![i];
                          return EvCard(
                            padding: EdgeInsets.zero,
                            child: ListTile(
                              onTap: () => push(context, BusinessScreen(page: asInt(p['guid']), name: str(p, 'name', str(p, 'title')))),
                              leading: const Tile(Icons.storefront_rounded, EvColors.ember2),
                              title: Text(str(p, 'name', str(p, 'title')), style: const TextStyle(fontWeight: FontWeight.w700)),
                              subtitle: Text('${asInt(p['likes_count'])} likes', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                              trailing: const Icon(Icons.chevron_right_rounded),
                            ),
                          );
                        },
                      ),
      );
}

/// Verification first; once verified, Business Hub.
class BusinessScreen extends StatefulWidget {
  final int page;
  final String name;
  const BusinessScreen({super.key, required this.page, required this.name});
  @override
  State<BusinessScreen> createState() => _BusinessScreenState();
}

class _BusinessScreenState extends State<BusinessScreen> {
  Map? _s;
  String? _error;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await MoreApi.instance.suiteStatus(widget.page);
      if (mounted) setState(() => _s = s);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  bool get _verified {
    final s = _s ?? const {};
    final st = str(s, 'status').toLowerCase();
    return asBool(s['verified'] ?? s['is_verified']) || st == 'verified' || st == 'approved' || st == 'active';
  }

  Future<void> _run(Future<Map?> Function() f, String done) async {
    setState(() => _busy = true);
    try {
      final r = await f();
      if (mounted) showMessage(context, r != null && str(r, 'message').isNotEmpty ? str(r, 'message') : done);
      await _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _uploadCac() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 2400, imageQuality: 90);
    if (x == null) return;
    await _run(() async {
      await MoreApi.instance.suiteUploadCac(widget.page, File(x.path));
      return null;
    }, 'Certificate uploaded.');
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return Scaffold(appBar: AppBar(title: Text(widget.name)), body: StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load this business", body: _error!, action: 'Try again', onAction: _load));
    if (_s == null) return Scaffold(appBar: AppBar(title: Text(widget.name)), body: const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    if (_verified) return _Hub(page: widget.page, name: widget.name, status: _s!);
    final s = _s!;
    final st = str(s, 'status', 'not verified').toLowerCase();
    final pending = st.contains('pending') || st.contains('review');
    final fee = asDouble(s['fee'] ?? s['price'] ?? s['amount']);
    final cac = asBool(s['cac_uploaded'] ?? s['has_cac'] ?? s['cac']);
    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        EvCard(child: Column(children: [
          Icon(pending ? Icons.schedule_rounded : Icons.verified_outlined, size: 54, color: pending ? EvColors.gold : EvColors.blue),
          const SizedBox(height: 8),
          Text(pending ? 'Under review' : 'Verify your business', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(pending ? "We're checking your CAC details. This usually takes 1–2 working days." : 'Get the blue badge and unlock Business Hub: invoices, books and online payments.', textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted)),
        ])),
        if (!pending) ...[
          const SizedBox(height: 12),
          EvCard(child: Row(children: [Tile(cac ? Icons.check_rounded : Icons.description_outlined, cac ? EvColors.green : EvColors.red), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('CAC certificate', style: TextStyle(fontWeight: FontWeight.w700)), Text(cac ? 'Uploaded' : 'A clear photo of your certificate', style: const TextStyle(color: EvColors.muted, fontSize: 12))])), TextButton(onPressed: _busy ? null : _uploadCac, child: Text(cac ? 'Replace' : 'Upload'))])),
          const SizedBox(height: 12),
          if (fee > 0) EvCard(child: Row(children: [const Expanded(child: Text('Yearly fee', style: TextStyle(fontWeight: FontWeight.w700))), Text(naira(fee), style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 18))])),
          const SizedBox(height: 18),
          if (AppConfig.storeSafe)
            const Text('Business verification can be completed on the Evinie website.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))
          else
            EmberButton(fee > 0 ? 'Pay ${naira(fee)} from Wallet and submit' : 'Pay and submit', loading: _busy, onPressed: () => _run(() => MoreApi.instance.suitePay(widget.page), 'Submitted for review.')),
        ],
      ]),
    );
  }
}

class _Hub extends StatelessWidget {
  final int page;
  final String name;
  final Map status;
  const _Hub({required this.page, required this.name, required this.status});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 6,
        child: Scaffold(
          appBar: AppBar(
            title: Row(children: [Flexible(child: Text(name, overflow: TextOverflow.ellipsis)), const SizedBox(width: 6), const Icon(Icons.verified_rounded, color: EvColors.blue, size: 18)]),
            bottom: const TabBar(isScrollable: true, tabAlignment: TabAlignment.start, tabs: [Tab(text: 'Overview'), Tab(text: 'Documents'), Tab(text: 'Products'), Tab(text: 'Books'), Tab(text: 'Profit & Loss'), Tab(text: 'Team')], labelColor: EvColors.ember2, indicatorColor: EvColors.ember2, unselectedLabelColor: EvColors.muted),
          ),
          body: TabBarView(children: [_Overview(page: page), _Documents(page: page), _Products(page: page), _Books(page: page), _Report(page: page), _Team(page: page)]),
        ),
      );
}

/// Loads a map once and builds from it, with loading and error states.
class _Loader extends StatefulWidget {
  final Future<Map> Function() load;
  final Widget Function(Map data, Future<void> Function() reload) builder;
  const _Loader({required this.load, required this.builder, super.key});
  @override
  State<_Loader> createState() => _LoaderState();
}

class _LoaderState extends State<_Loader> {
  Map? _d;
  String? _error;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    try {
      final d = await widget.load();
      if (mounted) {
        setState(() {
          _d = d;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) return StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load this", body: _error!, action: 'Try again', onAction: _reload);
    if (_d == null) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    return RefreshIndicator(onRefresh: _reload, child: widget.builder(_d!, _reload));
  }
}

class _Overview extends StatelessWidget {
  final int page;
  const _Overview({required this.page});
  @override
  Widget build(BuildContext context) => _Loader(
        load: () => MoreApi.instance.hubSummary(page),
        builder: (d, _) => ListView(padding: const EdgeInsets.all(16), children: [
          FigureGrid(mapOf(d['summary'])),
          const SizedBox(height: 12),
          _Loader(
            load: () => MoreApi.instance.hubPayments(page),
            builder: (p, __) {
              final link = str(p, 'payment_link');
              return EvCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [const Expanded(child: Text('Online payments', style: TextStyle(fontWeight: FontWeight.w700))), StatusChip(asBool(p['online']) ? 'Active' : 'Off')]),
                  const SizedBox(height: 4),
                  Text('Platform fee ${asStr(p['platform_fee'])}%. Money lands in your Wallet.', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                  if (link.isNotEmpty) ...[const SizedBox(height: 10), OutlineEmberButton('Share payment link', onPressed: () => Share.share('Pay me on Evinie: $link'))],
                ]),
              );
            },
          ),
        ]),
      );
}

class _Documents extends StatelessWidget {
  final int page;
  const _Documents({required this.page});
  @override
  Widget build(BuildContext context) => _Loader(
        load: () async => {'list': await MoreApi.instance.hubDocuments(page)},
        builder: (d, reload) {
          final list = listOf(d['list']);
          Future<void> create() async {
            final type = await showModalBottomSheet<String>(
              context: context,
              backgroundColor: Colors.white,
              builder: (s) => SafeArea(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  ListTile(leading: const Icon(Icons.request_quote_outlined, color: EvColors.ember2), title: const Text('New quotation'), onTap: () => Navigator.pop(s, 'quotation')),
                  ListTile(leading: const Icon(Icons.receipt_long_outlined, color: EvColors.blue), title: const Text('New invoice'), onTap: () => Navigator.pop(s, 'invoice')),
                ]),
              ),
            );
            if (type == null || !context.mounted) return;
            final saved = await Navigator.of(context).push<Map>(MaterialPageRoute(builder: (_) => _DocEditor(page: page, type: type)));
            if (saved != null && context.mounted) {
              await Navigator.of(context).push(MaterialPageRoute(builder: (_) => _DocumentScreen(page: page, guid: asInt(saved['guid']))));
            }
            reload();
          }

          final newButton = Positioned(right: 16, bottom: 16, child: FloatingActionButton.extended(heroTag: 'newdoc', backgroundColor: EvColors.ember2, foregroundColor: Colors.white, onPressed: create, icon: const Icon(Icons.add_rounded), label: const Text('New')));
          if (list.isEmpty) return Stack(children: [ListView(children: const [SizedBox(height: 80), StateMessage(icon: Icons.receipt_long_outlined, title: 'No documents yet', body: 'Tap New to create a quotation or invoice. Receipts are made automatically when an invoice is paid.')]), newButton]);
          return Stack(children: [ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final doc = list[i];
              return EvCard(
                padding: EdgeInsets.zero,
                child: ListTile(
                  onTap: () async {
                    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => _DocumentScreen(page: page, guid: asInt(doc['guid']))));
                    reload();
                  },
                  leading: Tile(Icons.receipt_long_rounded, str(doc, 'type').startsWith('r') ? EvColors.green : EvColors.ember2),
                  title: Text(str(doc, 'number', '#${asInt(doc['guid'])}'), style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${_customer(doc)} · ${str(doc, 'issue_date')}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                  trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [Text(naira(asDouble(doc['total'])), style: const TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 3), StatusChip(str(doc, 'status', 'draft'))]),
                ),
              );
            },
          ), newButton]);
        },
      );
}

String _customer(Map doc) {
  final c = doc['customer'];
  return c is Map ? str(c, 'name', str(c, 'email')) : asStr(c);
}

class _DocumentScreen extends StatelessWidget {
  final int page, guid;
  const _DocumentScreen({required this.page, required this.guid});

  /// Runs a status change; "accept" and "paid" return a new document
  /// (the invoice or the receipt), which is then shown instead.
  Future<void> _change(BuildContext context, Future<void> Function() reload, String action, {String method = ''}) async {
    try {
      final r = await MoreApi.instance.hubStatus(page, guid, action, method: method);
      if (!context.mounted) return;
      final next = asInt(r['guid']);
      if (next > 0 && next != guid) {
        showMessage(context, action == 'accept' ? 'Quotation accepted. Here is the invoice.' : 'Payment recorded. Here is the receipt.');
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => _DocumentScreen(page: page, guid: next)));
        return;
      }
      await reload();
    } catch (e) {
      if (context.mounted) showMessage(context, '$e');
    }
  }

  Future<bool> _confirm(BuildContext context, String title, String body, String yes) async =>
      await showDialog<bool>(
        context: context,
        builder: (d) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(yes))]),
      ) ==
      true;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Document')),
        body: _Loader(
          load: () => MoreApi.instance.hubDocument(page, guid),
          builder: (doc, reload) {
            final c = doc['customer'] is Map ? doc['customer'] as Map : const {};
            final link = str(doc, 'link', str(doc, 'url', str(doc, 'customer_link')));
            final status = str(doc, 'status', 'draft').toLowerCase();
            final type = str(doc, 'type').toLowerCase();
            final draft = status == 'draft';
            final closed = status.contains('paid') || status.contains('cancel') || status.contains('declin') || status.contains('accept');
            final items = listOf(doc['items'] ?? doc['lines']);
            Widget money(String label, double v, {bool bold = false}) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(children: [Expanded(child: Text(label, style: TextStyle(color: bold ? EvColors.ink : EvColors.muted, fontWeight: bold ? FontWeight.w700 : FontWeight.w400))), Text(naira(v), style: TextStyle(fontWeight: bold ? FontWeight.w700 : FontWeight.w600))]),
                );
            return ListView(padding: const EdgeInsets.all(16), children: [
              EvCard(child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${humanize(type)} ${str(doc, 'number')}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 17)), Text(_customer(doc), style: const TextStyle(color: EvColors.muted)), if (str(doc, 'due_date').isNotEmpty) Text('${type == 'quotation' ? 'Valid until' : 'Due'} ${str(doc, 'due_date')}', style: const TextStyle(color: EvColors.muted, fontSize: 12))])), Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(naira(asDouble(doc['total'])), style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700, fontSize: 20)), StatusChip(status)])])),
              if (items.isNotEmpty) ...[
                const SizedBox(height: 12),
                EvCard(
                  child: Column(children: [
                    for (final it in items) Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [Expanded(child: Text('${str(it, 'description', str(it, 'name'))} × ${asStr(it['qty'] ?? it['quantity'])}')), Text(naira(asDouble(it['amount'] ?? it['total'] ?? (asDouble(it['price']) * asDouble(it['qty'])))), style: const TextStyle(fontWeight: FontWeight.w600))])),
                    const Divider(height: 18),
                    money('Subtotal', asDouble(doc['subtotal'])),
                    if (asDouble(doc['discount']) > 0) money('Discount', -asDouble(doc['discount'])),
                    money('VAT (${asStr(doc['vat_rate'])}%)', asDouble(doc['vat_amount'])),
                    money('Total', asDouble(doc['total']), bold: true),
                  ]),
                ),
              ],
              if (str(doc, 'notes').isNotEmpty) ...[const SizedBox(height: 12), EvCard(child: Text(str(doc, 'notes'), style: const TextStyle(color: EvColors.ink2)))],
              const SizedBox(height: 16),
              if (asBool(doc['editable'])) ...[
                OutlineEmberButton('Edit', onPressed: () async {
                  final saved = await Navigator.of(context).push<Map>(MaterialPageRoute(builder: (_) => _DocEditor(page: page, type: type, doc: doc)));
                  if (saved != null) await reload();
                }),
                const SizedBox(height: 8),
              ],
              if (draft) ...[
                EmberButton('Mark as sent', icon: Icons.send_rounded, onPressed: () => _change(context, reload, 'send')),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: () async {
                    if (!await _confirm(context, 'Delete this draft?', 'This cannot be undone.', 'Delete')) return;
                    try {
                      await MoreApi.instance.hubDeleteDocument(page, guid);
                      if (context.mounted) Navigator.of(context).pop();
                    } catch (e) {
                      if (context.mounted) showMessage(context, '$e');
                    }
                  },
                  child: const Text('Delete draft', style: TextStyle(color: EvColors.red)),
                ),
              ] else ...[
                EmberButton('Email to customer', icon: Icons.mail_outline_rounded, onPressed: () async {
                  final ctrl = TextEditingController(text: str(c, 'email'));
                  final email = await showDialog<String>(context: context, builder: (d) => AlertDialog(title: const Text('Email to customer'), content: TextField(controller: ctrl, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'customer@email.com')), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, ctrl.text.trim()), child: const Text('Send'))]));
                  ctrl.dispose();
                  if (email == null || email.isEmpty) return;
                  try {
                    await MoreApi.instance.hubEmail(page, guid, email);
                    if (context.mounted) showMessage(context, 'Sent to $email.');
                  } catch (e) {
                    if (context.mounted) showMessage(context, '$e');
                  }
                }),
                if (link.isNotEmpty) ...[const SizedBox(height: 8), OutlineEmberButton('Share customer link', onPressed: () => Share.share(link))],
                if (type == 'quotation' && !closed) ...[
                  const SizedBox(height: 8),
                  OutlineEmberButton('Customer accepted: make invoice', onPressed: () => _change(context, reload, 'accept')),
                  TextButton(onPressed: () => _change(context, reload, 'decline'), child: const Text('Customer declined', style: TextStyle(color: EvColors.red))),
                ],
                if (type == 'invoice' && !closed) ...[
                  const SizedBox(height: 8),
                  OutlineEmberButton('Record payment', onPressed: () async {
                    final method = await showModalBottomSheet<String>(context: context, builder: (s) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [for (final m in ['transfer', 'cash', 'card', 'pos', 'online', 'other']) ListTile(title: Text(m == 'pos' ? 'POS' : humanize(m)), onTap: () => Navigator.pop(s, m))])));
                    if (method == null || !context.mounted) return;
                    await _change(context, reload, 'paid', method: method);
                  }),
                  TextButton(
                    onPressed: () async {
                      if (await _confirm(context, 'Cancel this invoice?', 'The customer will no longer be able to pay it.', 'Cancel invoice') && context.mounted) await _change(context, reload, 'cancel');
                    },
                    child: const Text('Cancel invoice', style: TextStyle(color: EvColors.red)),
                  ),
                ],
              ],
            ]);
          },
        ),
      );
}

/// Create or edit a quotation or invoice. The server works out VAT and
/// totals; the figures here are a preview.
class _DocEditor extends StatefulWidget {
  final int page;
  final String type;
  final Map? doc;
  const _DocEditor({required this.page, required this.type, this.doc});
  @override
  State<_DocEditor> createState() => _DocEditorState();
}

class _Line {
  final desc = TextEditingController();
  final qty = TextEditingController(text: '1');
  final price = TextEditingController();
  int product = 0;
  void dispose() {
    desc.dispose();
    qty.dispose();
    price.dispose();
  }
}

class _DocEditorState extends State<_DocEditor> {
  final _name = TextEditingController(), _email = TextEditingController(), _phone = TextEditingController(), _address = TextEditingController();
  final _discount = TextEditingController(), _notes = TextEditingController();
  final List<_Line> _lines = [];
  DateTime _issue = DateTime.now();
  DateTime? _due;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final d = widget.doc;
    if (d != null) {
      final c = d['customer'] is Map ? d['customer'] as Map : const {};
      _name.text = str(c, 'name');
      _email.text = str(c, 'email');
      _phone.text = str(c, 'phone');
      _address.text = str(c, 'address');
      if (asDouble(d['discount']) > 0) _discount.text = asStr(d['discount']);
      _notes.text = str(d, 'notes');
      _issue = DateTime.tryParse(str(d, 'issue_date')) ?? _issue;
      _due = DateTime.tryParse(str(d, 'due_date'));
      for (final it in listOf(d['items'])) {
        final l = _Line()
          ..desc.text = str(it, 'description', str(it, 'name'))
          ..qty.text = asStr(it['qty'] ?? 1)
          ..price.text = asStr(it['price'])
          ..product = asInt(it['product_guid']);
        _lines.add(l);
      }
    } else {
      _due = DateTime.now().add(Duration(days: widget.type == 'quotation' ? 30 : 14));
    }
    if (_lines.isEmpty) _lines.add(_Line());
  }

  @override
  void dispose() {
    for (final c in [_name, _email, _phone, _address, _discount, _notes]) {
      c.dispose();
    }
    for (final l in _lines) {
      l.dispose();
    }
    super.dispose();
  }

  String _ymd(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  double _num(String v) => double.tryParse(v.replaceAll(',', '').trim()) ?? 0;
  double get _subtotal => _lines.fold(0, (a, l) => a + _num(l.qty.text) * _num(l.price.text));

  Future<void> _fromProducts() async {
    List<Map> products;
    try {
      products = await MoreApi.instance.hubActiveProducts(widget.page);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
      return;
    }
    if (!mounted) return;
    if (products.isEmpty) return showMessage(context, 'No products yet. Add them in the Products tab.');
    final p = await showModalBottomSheet<Map>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      builder: (s) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(s).size.height * 0.7),
          child: ListView(shrinkWrap: true, children: [
            for (final p in products) ListTile(title: Text(str(p, 'name')), subtitle: Text('${naira(asDouble(p['price']))}${str(p, 'unit').isEmpty ? '' : ' ${str(p, 'unit')}'}'), onTap: () => Navigator.pop(s, p)),
          ]),
        ),
      ),
    );
    if (p == null) return;
    setState(() {
      // Fill an empty first line, otherwise add a new one.
      final empty = _lines.where((l) => l.desc.text.trim().isEmpty && l.price.text.trim().isEmpty).firstOrNull;
      final l = empty ?? _Line();
      l.desc.text = str(p, 'name');
      l.price.text = asStr(p['price']);
      l.product = asInt(p['guid']);
      if (empty == null) _lines.add(l);
    });
  }

  Future<void> _pickDate(bool due) async {
    final now = DateTime.now();
    final d = await showDatePicker(context: context, initialDate: (due ? _due : _issue) ?? now, firstDate: DateTime(now.year - 2), lastDate: DateTime(now.year + 3));
    if (d != null) setState(() => due ? _due = d : _issue = d);
  }

  Future<void> _save() async {
    final items = [
      for (final l in _lines)
        if (l.desc.text.trim().isNotEmpty && _num(l.qty.text) > 0) {'description': l.desc.text.trim(), 'qty': _num(l.qty.text), 'price': _num(l.price.text), if (l.product > 0) 'product_guid': l.product},
    ];
    if (_name.text.trim().isEmpty) return showMessage(context, "Enter the customer's name.");
    if (items.isEmpty) return showMessage(context, 'Add at least one item with a description and quantity.');
    setState(() => _busy = true);
    try {
      final saved = await MoreApi.instance.hubSaveDocument(widget.page, {
        'type': widget.type,
        'customer_name': _name.text.trim(),
        'customer_email': _email.text.trim(),
        'customer_phone': _phone.text.trim(),
        'customer_address': _address.text.trim(),
        'items': jsonEncode(items),
        'discount': _num(_discount.text) > 0 ? _num(_discount.text) : '',
        'issue_date': _ymd(_issue),
        'due_date': _due == null ? '' : _ymd(_due!),
        'notes': _notes.text.trim(),
      }, guid: asInt(widget.doc?['guid']));
      if (mounted) Navigator.of(context).pop(saved);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  InputDecoration _dec(String label) => InputDecoration(labelText: label, isDense: true, filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: EvColors.line)), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: EvColors.line)));

  @override
  Widget build(BuildContext context) {
    final sub = _subtotal;
    final disc = _num(_discount.text).clamp(0, sub).toDouble();
    final vat = (sub - disc) * 0.075;
    final title = '${widget.doc == null ? 'New' : 'Edit'} ${widget.type == 'quotation' ? 'quotation' : 'invoice'}';
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Customer', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(controller: _name, textCapitalization: TextCapitalization.words, decoration: _dec('Name *')),
        const SizedBox(height: 8),
        TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: _dec('Email')),
        const SizedBox(height: 8),
        TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: _dec('Phone')),
        const SizedBox(height: 8),
        TextField(controller: _address, decoration: _dec('Address')),
        const SizedBox(height: 18),
        Row(children: [const Expanded(child: Text('Items', style: TextStyle(fontWeight: FontWeight.w700))), TextButton.icon(onPressed: _fromProducts, icon: const Icon(Icons.inventory_2_outlined, size: 18), label: const Text('From products'))]),
        for (var i = 0; i < _lines.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: EvCard(
              padding: const EdgeInsets.all(10),
              child: Column(children: [
                Row(children: [
                  Expanded(child: TextField(controller: _lines[i].desc, onChanged: (_) => setState(() => _lines[i].product = 0), decoration: _dec('Description'))),
                  if (_lines.length > 1)
                    IconButton(
                      tooltip: 'Remove',
                      icon: const Icon(Icons.close_rounded, color: EvColors.muted),
                      onPressed: () => setState(() => _lines.removeAt(i).dispose()),
                    ),
                ]),
                const SizedBox(height: 8),
                Row(children: [
                  SizedBox(width: 90, child: TextField(controller: _lines[i].qty, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}), decoration: _dec('Qty'))),
                  const SizedBox(width: 8),
                  Expanded(child: TextField(controller: _lines[i].price, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}), decoration: _dec('Price (₦)'))),
                ]),
              ]),
            ),
          ),
        Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: () => setState(() => _lines.add(_Line())), icon: const Icon(Icons.add_rounded), label: const Text('Add item'))),
        const SizedBox(height: 8),
        TextField(controller: _discount, keyboardType: const TextInputType.numberWithOptions(decimal: true), onChanged: (_) => setState(() {}), decoration: _dec('Discount (₦, optional)')),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: OutlinedButton(onPressed: () => _pickDate(false), child: Text('Date: ${_ymd(_issue)}'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton(onPressed: () => _pickDate(true), child: Text('${widget.type == 'quotation' ? 'Valid until' : 'Due'}: ${_due == null ? '—' : _ymd(_due!)}'))),
        ]),
        const SizedBox(height: 12),
        TextField(controller: _notes, minLines: 2, maxLines: 5, decoration: _dec('Notes (optional)')),
        const SizedBox(height: 16),
        EvCard(
          child: Column(children: [
            Row(children: [const Expanded(child: Text('Subtotal', style: TextStyle(color: EvColors.muted))), Text(naira(sub))]),
            if (disc > 0) Row(children: [const Expanded(child: Text('Discount', style: TextStyle(color: EvColors.muted))), Text('-${naira(disc)}')]),
            Row(children: [const Expanded(child: Text('VAT (7.5%)', style: TextStyle(color: EvColors.muted))), Text(naira(vat))]),
            const Divider(),
            Row(children: [const Expanded(child: Text('Total', style: TextStyle(fontWeight: FontWeight.w700))), Text(naira(sub - disc + vat), style: const TextStyle(fontWeight: FontWeight.w700, color: EvColors.ember2))]),
          ]),
        ),
        const SizedBox(height: 16),
        EmberButton(widget.doc == null ? 'Save as draft' : 'Save changes', loading: _busy, onPressed: _save),
        const SizedBox(height: 6),
        const Text('Saved as a draft. Open it and tap "Mark as sent" when it is ready for the customer.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontSize: 12)),
      ]),
    );
  }
}

/// Products and services: used on quotations and invoices.
class _Products extends StatelessWidget {
  final int page;
  const _Products({required this.page});
  @override
  Widget build(BuildContext context) => _Loader(
        load: () async => {'list': await MoreApi.instance.hubProducts(page)},
        builder: (d, reload) {
          final list = listOf(d['list']);
          Future<void> open([Map? p]) async {
            final changed = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => _ProductEditor(page: page, product: p)));
            if (changed == true) reload();
          }

          final addButton = Positioned(right: 16, bottom: 16, child: FloatingActionButton.extended(heroTag: 'newproduct', backgroundColor: EvColors.ember2, foregroundColor: Colors.white, onPressed: () => open(), icon: const Icon(Icons.add_rounded), label: const Text('Add')));
          if (list.isEmpty) return Stack(children: [ListView(children: const [SizedBox(height: 80), StateMessage(icon: Icons.inventory_2_outlined, title: 'No products yet', body: 'Add the products and services you sell, then pick them when you make a quotation or invoice.')]), addButton]);
          return Stack(children: [
            ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
              itemCount: list.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final p = list[i];
                final img = str(p, 'image');
                return EvCard(
                  padding: EdgeInsets.zero,
                  child: ListTile(
                    onTap: () => open(p),
                    leading: ClipRRect(borderRadius: BorderRadius.circular(10), child: SizedBox(width: 48, height: 48, child: img.isEmpty ? Container(color: EvColors.sand2, child: Icon(str(p, 'kind') == 'service' ? Icons.handyman_outlined : Icons.inventory_2_outlined, color: EvColors.muted)) : CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(img), fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: EvColors.sand2)))),
                    title: Text(str(p, 'name'), style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                      Text('${humanize(str(p, 'kind', 'product'))}${str(p, 'unit').isEmpty ? '' : ' · ${str(p, 'unit')}'}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                      // Business Hub 1.3 lists active products with a price
                      // and a picture on the Marketplace automatically.
                      if (asInt(p['marketplace_guid']) > 0)
                        const Text('On Marketplace', style: TextStyle(color: EvColors.green, fontSize: 11.5, fontWeight: FontWeight.w700))
                      else if (str(p, 'kind', 'product') == 'product' && asBool(p['active']) && p.containsKey('marketplace_guid'))
                        const Text('Add a price and a picture to list it on Marketplace', style: TextStyle(color: EvColors.muted, fontSize: 11)),
                    ]),
                    trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [Text(naira(asDouble(p['price'])), style: const TextStyle(fontWeight: FontWeight.w700)), if (!asBool(p['active'])) const Padding(padding: EdgeInsets.only(top: 3), child: StatusChip('hidden'))]),
                  ),
                );
              },
            ),
            addButton,
          ]);
        },
      );
}

class _ProductEditor extends StatefulWidget {
  final int page;
  final Map? product;
  const _ProductEditor({required this.page, this.product});
  @override
  State<_ProductEditor> createState() => _ProductEditorState();
}

class _ProductEditorState extends State<_ProductEditor> {
  final _name = TextEditingController(), _price = TextEditingController(), _unit = TextEditingController(), _desc = TextEditingController();
  String _kind = 'product';
  bool _active = true, _busy = false;
  File? _image;

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    if (p != null) {
      _name.text = str(p, 'name');
      _price.text = asStr(p['price']);
      _unit.text = str(p, 'unit');
      _desc.text = str(p, 'description');
      _kind = str(p, 'kind', 'product') == 'service' ? 'service' : 'product';
      _active = asBool(p['active']);
    }
  }

  @override
  void dispose() {
    for (final c in [_name, _price, _unit, _desc]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final price = double.tryParse(_price.text.replaceAll(',', '').trim());
    if (_name.text.trim().isEmpty || price == null) return showMessage(context, 'Enter a name and a price.');
    setState(() => _busy = true);
    try {
      await MoreApi.instance.hubSaveProduct(widget.page, {'name': _name.text.trim(), 'price': price, 'kind': _kind, 'unit': _unit.text.trim(), 'description': _desc.text.trim(), 'active': _active ? '1' : '0'}, guid: asInt(widget.product?['guid']), image: _image);
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: const Text('Delete this product?'), content: const Text('It will no longer be available for new quotations and invoices.'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete', style: TextStyle(color: EvColors.red)))]));
    if (ok != true || !mounted) return;
    try {
      await MoreApi.instance.hubDeleteProduct(widget.page, asInt(widget.product!['guid']));
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final existing = str(widget.product ?? const {}, 'image');
    InputDecoration dec(String l) => InputDecoration(labelText: l, filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)));
    return Scaffold(
      appBar: AppBar(title: Text(widget.product == null ? 'Add product' : 'Edit product'), actions: [if (widget.product != null) IconButton(tooltip: 'Delete', onPressed: _delete, icon: const Icon(Icons.delete_outline_rounded, color: EvColors.red))]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        GestureDetector(
          onTap: () async {
            final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1600, imageQuality: 85);
            if (x != null) setState(() => _image = File(x.path));
          },
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: _image != null
                  ? Image.file(_image!, fit: BoxFit.cover)
                  : existing.isNotEmpty
                      ? CachedNetworkImage(cacheManager: evCache, imageUrl: absUrl(existing), fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: EvColors.sand2))
                      : Container(color: EvColors.sand2, child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_photo_alternate_outlined, color: EvColors.muted, size: 36), Text('Add a picture (optional)', style: TextStyle(color: EvColors.muted))])),
            ),
          ),
        ),
        const SizedBox(height: 14),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'product', label: Text('Product')), ButtonSegment(value: 'service', label: Text('Service'))], selected: {_kind}, onSelectionChanged: (v) => setState(() => _kind = v.first)),
        const SizedBox(height: 12),
        TextField(controller: _name, textCapitalization: TextCapitalization.sentences, decoration: dec('Name *')),
        const SizedBox(height: 10),
        TextField(controller: _price, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: dec('Price (₦) *')),
        const SizedBox(height: 10),
        TextField(controller: _unit, decoration: dec('Unit (optional, e.g. per hour)')),
        const SizedBox(height: 10),
        TextField(controller: _desc, minLines: 2, maxLines: 5, decoration: dec('Description (optional)')),
        const SizedBox(height: 6),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: _active, onChanged: (v) => setState(() => _active = v), title: const Text('Available on quotations and invoices')),
        const SizedBox(height: 12),
        EmberButton('Save', loading: _busy, onPressed: _save),
      ]),
    );
  }
}

class _Books extends StatefulWidget {
  final int page;
  const _Books({required this.page});
  @override
  State<_Books> createState() => _BooksState();
}

class _BooksState extends State<_Books> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  String get _key => '${_month.year}-${_month.month.toString().padLeft(2, '0')}';
  @override
  Widget build(BuildContext context) {
    const names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return Column(children: [
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        IconButton(onPressed: () => setState(() => _month = DateTime(_month.year, _month.month - 1)), icon: const Icon(Icons.chevron_left_rounded)),
        Text('${names[_month.month - 1]} ${_month.year}', style: const TextStyle(fontWeight: FontWeight.w700)),
        IconButton(onPressed: () => setState(() => _month = DateTime(_month.year, _month.month + 1)), icon: const Icon(Icons.chevron_right_rounded)),
      ]),
      Expanded(
        child: _Loader(
          key: ValueKey(_key),
          load: () => MoreApi.instance.hubBooks(widget.page, _key),
          builder: (d, _) {
            final entries = listOf(d['entries']);
            return ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
              FigureGrid(mapOf(d['totals'])),
              const SizedBox(height: 12),
              if (entries.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('No entries this month.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))),
              for (final e in entries)
                Builder(builder: (_) {
                  final income = str(e, 'kind', str(e, 'type')).toLowerCase().startsWith('inc');
                  return ListTile(
                    tileColor: Colors.white,
                    leading: Tile(income ? Icons.south_west_rounded : Icons.north_east_rounded, income ? EvColors.green : EvColors.red),
                    title: Text(str(e, 'description', str(e, 'title', str(e, 'category'))), maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(str(e, 'category'), style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                    trailing: Text('${income ? '+' : '−'}${naira(asDouble(e['amount']))}', style: TextStyle(fontWeight: FontWeight.w700, color: income ? EvColors.green : EvColors.ink)),
                  );
                }),
            ]);
          },
        ),
      ),
    ]);
  }
}

class _Report extends StatefulWidget {
  final int page;
  const _Report({required this.page});
  @override
  State<_Report> createState() => _ReportState();
}

class _ReportState extends State<_Report> {
  String _period = 'month';
  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: SegmentedButton<String>(segments: const [ButtonSegment(value: 'month', label: Text('Month')), ButtonSegment(value: 'quarter', label: Text('Quarter')), ButtonSegment(value: 'year', label: Text('Year'))], selected: {_period}, onSelectionChanged: (v) => setState(() => _period = v.first)),
        ),
        Expanded(
          child: _Loader(
            key: ValueKey(_period),
            load: () => MoreApi.instance.hubReport(widget.page, _period),
            builder: (d, _) {
              final r = mapOf(d['report']);
              final income = mapOf(r['income']);
              final expense = mapOf(r['expense'] ?? r['expenses']);
              Widget section(String title, Map m, Color c) => EvCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: EvColors.muted, fontSize: 12.5)), for (final e in m.entries) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [Expanded(child: Text(humanize('${e.key}'))), Text(naira(asDouble(e.value)), style: TextStyle(color: c, fontWeight: FontWeight.w600))]))]));
              return ListView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), children: [
                FigureGrid({for (final e in r.entries) if (e.value is! Map && e.value is! List) e.key: e.value}),
                if (income.isNotEmpty) ...[const SizedBox(height: 10), section('Income', income, EvColors.green)],
                if (expense.isNotEmpty) ...[const SizedBox(height: 10), section('Expenses', expense, EvColors.red)],
              ]);
            },
          ),
        ),
      ]);
}

class _Team extends StatelessWidget {
  final int page;
  const _Team({required this.page});
  @override
  Widget build(BuildContext context) => _Loader(
        load: () => MoreApi.instance.suiteTeam(page),
        builder: (d, reload) {
          final team = listOf(d['team']);
          final isOwner = str(d, 'your_role').toLowerCase() == 'owner';
          return ListView(padding: const EdgeInsets.all(16), children: [
            EvCard(
              padding: EdgeInsets.zero,
              child: Column(children: [
                for (final m in team)
                  ListTile(
                    leading: Avatar(EvUser.fromJson(m), size: 40),
                    title: Text(EvUser.fromJson(m).fullname, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Text(humanize(str(m, 'role', 'manager')), style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                    trailing: !isOwner || str(m, 'role').toLowerCase() == 'owner'
                        ? null
                        : TextButton(
                            onPressed: () async {
                              try {
                                await MoreApi.instance.suiteRemoveManager(page, asInt(m['guid'] ?? m['member_guid']));
                                reload();
                              } catch (e) {
                                if (context.mounted) showMessage(context, '$e');
                              }
                            },
                            child: const Text('Remove', style: TextStyle(color: EvColors.red)),
                          ),
                  ),
              ]),
            ),
            if (isOwner) ...[
              const SizedBox(height: 14),
              OutlineEmberButton('Add a manager', onPressed: () async {
                final ctrl = TextEditingController();
                final username = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: const Text('Add a manager'), content: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'Their Evinie username')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, ctrl.text.trim()), child: const Text('Add'))]));
                ctrl.dispose();
                if (username == null || username.isEmpty) return;
                try {
                  await MoreApi.instance.suiteAddManager(page, username, 'manager');
                  reload();
                } catch (e) {
                  if (context.mounted) showMessage(context, '$e');
                }
              }),
              const SizedBox(height: 6),
              const Text('Managers can use Business Hub and post as the page. Only the owner can verify, renew or remove people.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontSize: 12)),
            ],
          ]);
        },
      );
}
