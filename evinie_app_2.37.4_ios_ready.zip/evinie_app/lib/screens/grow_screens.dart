import 'package:url_launcher/url_launcher.dart';
import '../config.dart';
import 'package:http/http.dart' as http;
import '../api/money_api.dart';
import '../api/api_client.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../api/more_api.dart';
import '../models/models.dart';
import '../models/money.dart';
import '../state/cache.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'business_screens.dart';
import 'money_screens.dart';
import 'settings_screens.dart';
import 'auth_screens.dart' show passwordProblem, showForgotPassword;

class _Load extends StatefulWidget {
  final Future<Map> Function() load;
  final Widget Function(Map d, Future<void> Function() reload) builder;
  const _Load({required this.load, required this.builder, super.key});
  @override
  State<_Load> createState() => _LoadState();
}

class _LoadState extends State<_Load> {
  Map? _d;
  String? _e;
  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    try {
      final d = await widget.load();
      if (mounted) {
        setState(() {
          _d = d;
          _e = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _e = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => _e != null
      ? StateMessage(icon: Icons.info_outline_rounded, title: 'Not available', body: _e!, action: 'Try again', onAction: _reload)
      : _d == null
          ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
          : RefreshIndicator(onRefresh: _reload, child: widget.builder(_d!, _reload));
}

class ReferralScreen extends StatelessWidget {
  const ReferralScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Refer & earn')),
        body: _Load(
          load: () async {
            final code = await MoreApi.instance.referralCode();
            final stats = await MoreApi.instance.referralStats();
            return {...code, ...stats};
          },
          builder: (d, _) {
            final link = str(d, 'share_link');
            final users = listOf(d['referred_users']);
            return ListView(padding: const EdgeInsets.all(16), children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(24)),
                child: Column(children: [
                  const Icon(Icons.card_giftcard_rounded, color: Colors.white, size: 40),
                  const SizedBox(height: 6),
                  const Text('Invite friends, earn points', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  Row(children: [
                    Expanded(child: Column(children: [Text('${asInt(d['referral_count'])}', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)), const Text('Joined', style: TextStyle(color: Colors.white70, fontSize: 12))])),
                    Expanded(child: Column(children: [Text('${asInt(d['total_earned'])}', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)), const Text('Points earned', style: TextStyle(color: Colors.white70, fontSize: 12))])),
                  ]),
                ]),
              ),
              const SizedBox(height: 14),
              EvCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Your referral link', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  SelectableText(link.isEmpty ? str(d, 'code') : link, style: const TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: OutlineEmberButton('Copy', onPressed: () {
                      Clipboard.setData(ClipboardData(text: link));
                      showMessage(context, 'Link copied.');
                    })),
                    const SizedBox(width: 8),
                    Expanded(child: EmberButton('Share', icon: Icons.share_rounded, onPressed: () => Share.share('Join me on Evinie, the warmest place to connect, share and earn: $link'))),
                  ]),
                ]),
              ),
              const SizedBox(height: 14),
              _WhatsAppInvite(link: link),
              const SizedBox(height: 14),
              const _EmailInvite(),
              if (users.isNotEmpty) ...[
                const SizedBox(height: 16),
                const Text('People you invited', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 8),
                EvCard(padding: EdgeInsets.zero, child: Column(children: [for (final u in users) ListTile(leading: Avatar(EvUser.fromJson(u), size: 38), title: Text(EvUser.fromJson(u).fullname), subtitle: Text('Joined ${timeAgo(asTime(u['time']))}', style: const TextStyle(color: EvColors.muted, fontSize: 12)))])),
              ],
            ]);
          },
        ),
      );
}

class CreatorsScreen extends StatelessWidget {
  const CreatorsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Creators')),
        body: _Load(
          load: () => MoreApi.instance.creatorStatus(),
          builder: (s, reload) {
            if (!asBool(s['is_creator'])) {
              final pending = asBool(s['has_pending_application']);
              return ListView(padding: const EdgeInsets.all(20), children: [
                const SizedBox(height: 20),
                const Center(child: Tile(Icons.auto_graph_rounded, EvColors.ember2, size: 80)),
                const SizedBox(height: 14),
                Text(pending ? 'Application under review' : 'Become an Evinie creator', textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Text(pending ? "We'll let you know once your application has been reviewed." : 'Creators earn from the monthly creator pool based on views, engagement and referrals.', textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted, height: 1.5)),
                const SizedBox(height: 20),
                if (!pending && asBool(s['can_apply'] ?? true))
                  EmberButton('Apply now', onPressed: () async {
                    final ctrl = TextEditingController();
                    final msg = await showDialog<String>(context: context, builder: (_) => AlertDialog(title: const Text('Apply to be a creator'), content: TextField(controller: ctrl, maxLines: 4, decoration: const InputDecoration(hintText: 'Tell us what you create and who your audience is.')), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, ctrl.text.trim()), child: const Text('Send'))]));
                    ctrl.dispose();
                    if (msg == null) return;
                    try {
                      await MoreApi.instance.creatorApply(msg);
                      reload();
                    } catch (e) {
                      if (context.mounted) showMessage(context, '$e');
                    }
                  }),
              ]);
            }
            return _Load(
              load: () => MoreApi.instance.creatorDashboard(),
              builder: (d, _) {
                // The server sends this month's money as earned_so_far, and the
                // score, RPM and estimate inside "performance" (the app used to
                // look elsewhere, so everything showed ₦0).
                final month = mapOf(d['this_month']);
                final perf = mapOf(month['performance']);
                final score = asDouble(perf['score']);
                Widget target(String label, Map t) {
                  final actual = asDouble(t['actual']), goal = asDouble(t['target']);
                  final met = goal > 0 && actual >= goal;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
                        if (met) const Padding(padding: EdgeInsets.only(right: 6), child: Icon(Icons.check_circle_rounded, color: EvColors.green, size: 16)),
                        Text('${actual.round()} / ${goal.round()}', style: TextStyle(fontWeight: FontWeight.w700, color: met ? EvColors.green : EvColors.ink)),
                      ]),
                      const SizedBox(height: 5),
                      ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: goal <= 0 ? 0 : (actual / goal).clamp(0, 1).toDouble(), minHeight: 7, backgroundColor: EvColors.sand2, color: met ? EvColors.green : EvColors.ember1)),
                      Text('${asDouble(t['points']).toStringAsFixed(1)} of ${asDouble(t['max_points']).toStringAsFixed(0)} points', style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
                    ]),
                  );
                }

                return ListView(padding: const EdgeInsets.all(16), children: [
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: EvColors.ink, borderRadius: BorderRadius.circular(22)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Earned this month', style: TextStyle(color: Colors.white60, fontSize: 12)),
                      Text(naira(asDouble(month['earned_so_far'])), style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700)),
                      if (asDouble(perf['estimated_earning']) > 0) Text('Estimated at month end: ${naira(asDouble(perf['estimated_earning']))}', style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
                      const SizedBox(height: 14),
                      Row(children: [
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Performance score', style: TextStyle(color: Colors.white60, fontSize: 12)), Text('${score.toStringAsFixed(score % 1 == 0 ? 0 : 1)} / 100', style: const TextStyle(color: EvColors.gold, fontSize: 20, fontWeight: FontWeight.w700))])),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('RPM', style: TextStyle(color: Colors.white60, fontSize: 12)), Text(naira(asDouble(perf['rpm'])), style: const TextStyle(color: EvColors.gold, fontSize: 20, fontWeight: FontWeight.w700))])),
                      ]),
                      const SizedBox(height: 4),
                      const Text('RPM is what you earn per ₦1,000 of the creator pool; a higher score gives a higher RPM.', style: TextStyle(color: Colors.white54, fontSize: 11)),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  _ThreeMonths(listOf(d['history'])),
                  if (perf.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    EvCard(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Score targets this month', style: TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        if (perf['reel_views'] is Map) target('Reel views', perf['reel_views'] as Map),
                        if (perf['posts'] is Map) target('Posts', perf['posts'] as Map),
                        if (perf['likes_received'] is Map) target('Likes received', perf['likes_received'] as Map),
                        if (perf['comments_received'] is Map) target('Comments received', perf['comments_received'] as Map),
                      ]),
                    ),
                  ],
                  const SizedBox(height: 12),
                  const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('This month', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
                  FigureGrid({for (final e in month.entries) if (e.key != 'earned_so_far' && (e.value is num || double.tryParse('${e.value}') != null)) e.key: e.value}),
                  const SizedBox(height: 12),
                  const Padding(padding: EdgeInsets.only(top: 6, bottom: 8), child: Text('Overall', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
                  FigureGrid(mapOf(d['totals'])),
                ]);
              },
            );
          },
        ),
      );
}

class StaffScreen extends StatefulWidget {
  const StaffScreen({super.key});
  @override
  State<StaffScreen> createState() => _StaffScreenState();
}

class _StaffScreenState extends State<StaffScreen> {
  DateTime _m = DateTime(DateTime.now().year, DateTime.now().month);
  String get _key => '${_m.year}-${_m.month.toString().padLeft(2, '0')}';
  @override
  Widget build(BuildContext context) {
    const names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return Scaffold(
      appBar: AppBar(title: const Text('Staff scorecard')),
      body: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton(onPressed: () => setState(() => _m = DateTime(_m.year, _m.month - 1)), icon: const Icon(Icons.chevron_left_rounded)),
          Text('${names[_m.month - 1]} ${_m.year}', style: const TextStyle(fontWeight: FontWeight.w700)),
          IconButton(onPressed: () => setState(() => _m = DateTime(_m.year, _m.month + 1)), icon: const Icon(Icons.chevron_right_rounded)),
        ]),
        Expanded(
          child: _Load(
            key: ValueKey(_key),
            load: () async => mapOf(await ApiClient.instance.post('staff/scorecard', {'month': _key})),
            builder: (d, _) {
              if (d['rows'] is List) return _Scorecard(d);
              final s = mapOf(d['summary']);
              final targets = s['targets'] is Map ? s['targets'] as Map : s;
              final rows = <Widget>[];
              targets.forEach((k, v) {
                if (v is Map && (v.containsKey('count') || v.containsKey('target'))) {
                  final count = asInt(v['count'] ?? v['done']), target = asInt(v['target'] ?? v['goal']);
                  final met = target > 0 && count >= target;
                  rows.add(Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [Expanded(child: Text(humanize('$k'), style: const TextStyle(fontWeight: FontWeight.w600))), Text('$count / $target', style: TextStyle(fontWeight: FontWeight.w700, color: met ? EvColors.green : EvColors.ink))]),
                      const SizedBox(height: 5),
                      ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: target == 0 ? 0 : (count / target).clamp(0, 1).toDouble(), minHeight: 7, backgroundColor: EvColors.sand2, color: met ? EvColors.green : EvColors.ember1)),
                    ]),
                  ));
                }
              });
              return ListView(padding: const EdgeInsets.all(16), children: [
                FigureGrid(Map.fromEntries(s.entries.where((e) => e.value is! Map && e.value is! List && (e.value is num || double.tryParse('${e.value}') != null)).take(5))),
                const SizedBox(height: 12),
                const _StaffLog(),
                const SizedBox(height: 12),
                if (rows.isNotEmpty) EvCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Targets', style: TextStyle(fontWeight: FontWeight.w700)), ...rows])),
                if (rows.isEmpty && s.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('No activity recorded this month.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))),
              ]);
            },
          ),
        ),
      ]),
    );
  }
}

class RewardsScreen extends StatelessWidget {
  const RewardsScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Profile rewards')),
        body: _Load(
          load: () => MoreApi.instance.rewards(),
          builder: (d, _) {
            final steps = listOf(d['steps']);
            final done = steps.where((s) => asBool(s['done'])).length;
            return ListView(padding: const EdgeInsets.all(16), children: [
              EvCard(child: Column(children: [
                SizedBox(width: 96, height: 96, child: Stack(alignment: Alignment.center, children: [CircularProgressIndicator(value: steps.isEmpty ? 0 : done / steps.length, strokeWidth: 9, backgroundColor: EvColors.sand2, color: EvColors.ember2), Text('$done/${steps.length}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700))])),
                const SizedBox(height: 10),
                const Text('Complete your profile', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                Text('${asInt(d['points_earned'])} of ${asInt(d['points_total'])} points earned · 3,000 points = ${naira(1000)}', textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted, fontSize: 12.5)),
              ])),
              const SizedBox(height: 12),
              EvCard(padding: EdgeInsets.zero, child: Column(children: [
                for (final s in steps)
                  ListTile(
                    leading: Tile(asBool(s['done']) ? Icons.check_rounded : Icons.flag_outlined, asBool(s['done']) ? EvColors.green : EvColors.ember2),
                    title: Text(str(s, 'label', humanize(str(s, 'step'))), style: TextStyle(fontWeight: FontWeight.w600, decoration: asBool(s['done']) ? TextDecoration.lineThrough : null, color: asBool(s['done']) ? EvColors.muted : EvColors.ink)),
                    subtitle: s['goal'] != null ? Text('${asInt(s['progress'])} of ${asInt(s['goal'])}', style: const TextStyle(color: EvColors.muted, fontSize: 12)) : null,
                    trailing: StatusChip(asBool(s['done']) ? 'Done' : '+${asInt(s['points'])} pts'),
                  ),
              ])),
            ]);
          },
        ),
      );
}

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Widget _section(String t) => Padding(padding: const EdgeInsets.fromLTRB(4, 18, 4, 8), child: Text(t, style: const TextStyle(color: EvColors.muted, fontSize: 12, fontWeight: FontWeight.w700)));
  Widget _row(BuildContext c, IconData i, Color col, String t, String sub, VoidCallback onTap) => ListTile(
        onTap: onTap,
        leading: Tile(i, col, size: 34),
        title: Text(t, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        subtitle: Text(sub, style: const TextStyle(fontSize: 11.5, color: EvColors.muted)),
        trailing: const Icon(Icons.chevron_right_rounded, color: EvColors.muted),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Settings')),
        body: ListView(padding: EdgeInsets.fromLTRB(16, 0, 16, 48 + MediaQuery.of(context).padding.bottom), children: [
          _section('ACCOUNT'),
          EvCard(padding: EdgeInsets.zero, child: Column(children: [
            _row(context, Icons.person_outline_rounded, EvColors.ember2, 'Edit profile', 'Name, email, photo', () => push(context, const EditProfileScreen())),
            _row(context, Icons.shield_outlined, EvColors.blue, 'Security & login', 'Password, devices, delete account', () => push(context, const SecurityScreen())),
          ])),
          _section('PRIVACY & SAFETY'),
          EvCard(padding: EdgeInsets.zero, child: Column(children: [
            _row(context, Icons.lock_outline_rounded, EvColors.blue, 'Privacy', 'Who can see your posts', () => push(context, const PrivacyScreen())),
            _row(context, Icons.block_rounded, EvColors.red, 'Blocked accounts', 'People you have blocked', () => push(context, const BlockedScreen())),
          ])),
          _section('PREFERENCES'),
          EvCard(padding: EdgeInsets.zero, child: Column(children: [
            _row(context, Icons.notifications_none_rounded, EvColors.gold, 'Notifications', 'Turn notifications on or off', () => push(context, const NotificationSettingsScreen())),
            _row(context, Icons.workspace_premium_rounded, EvColors.ember2, 'Membership', 'EviMember or EviEarner', () => push(context, const MembershipScreen())),
          ])),
          _section('SUPPORT'),
          EvCard(padding: EdgeInsets.zero, child: Column(children: [
            _row(context, Icons.help_outline_rounded, EvColors.green, 'Help & support', 'Answers to common questions', () => push(context, const HelpScreen())),
            _row(context, Icons.description_outlined, EvColors.muted, 'Terms of service', 'The rules for using Evinie', () => push(context, const LegalScreen(title: 'Terms of service', path: 'site/terms'))),
            _row(context, Icons.privacy_tip_outlined, EvColors.muted, 'Privacy policy', 'How we handle your data', () => push(context, const LegalScreen(title: 'Privacy policy', path: 'site/privacy'))),
            _row(context, Icons.info_outline_rounded, EvColors.muted, 'About Evinie', 'Who we are', () => push(context, const LegalScreen(title: 'About Evinie', path: 'site/about'))),
          ])),
          _section('SAVED DATA'),
          const _SavedData(),
          const SizedBox(height: 18),
          EvCard(padding: EdgeInsets.zero, child: ListTile(onTap: () => Scope.read(context).signOut(), leading: const Icon(Icons.logout_rounded, color: EvColors.red), title: const Text('Log out', style: TextStyle(color: EvColors.red, fontWeight: FontWeight.w700)))),
        ]),
      );
}

class SecurityScreen extends StatelessWidget {
  const SecurityScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Security & login')),
        body: _Load(
          load: () async => {'list': await MoreApi.instance.sessions()},
          builder: (d, reload) => ListView(padding: const EdgeInsets.all(16), children: [
            EvCard(padding: EdgeInsets.zero, child: Column(children: [
              ListTile(onTap: () => push(context, const ChangePasswordScreen()), leading: const Tile(Icons.key_rounded, EvColors.ember2, size: 34), title: const Text('Password', style: TextStyle(fontWeight: FontWeight.w600)), subtitle: const Text('Change your password', style: TextStyle(fontSize: 12)), trailing: const Icon(Icons.chevron_right_rounded)),
              ListTile(onTap: () => showForgotPassword(context, prefill: Scope.read(context).current.username), leading: const Tile(Icons.lock_reset_rounded, EvColors.blue, size: 34), title: const Text('Reset password', style: TextStyle(fontWeight: FontWeight.w600)), subtitle: const Text("Forgot it? We'll email you a reset link", style: TextStyle(fontSize: 12)), trailing: const Icon(Icons.chevron_right_rounded)),
            ])),
            const Padding(padding: EdgeInsets.fromLTRB(4, 18, 4, 8), child: Text('SIGNED-IN DEVICES', style: TextStyle(color: EvColors.muted, fontSize: 12, fontWeight: FontWeight.w700))),
            EvCard(padding: EdgeInsets.zero, child: Column(children: [
              for (final s in listOf(d['list']))
                ListTile(
                  leading: Tile(Icons.smartphone_rounded, asBool(s['this_device']) ? EvColors.green : EvColors.muted, size: 34),
                  title: Text(str(s, 'device', 'Phone') + (asBool(s['this_device']) ? ' (this device)' : '')),
                  subtitle: Text('Last active ${timeAgo(asTime(s['last_used']))}', style: const TextStyle(fontSize: 12)),
                  trailing: asBool(s['this_device'])
                      ? null
                      : TextButton(onPressed: () async {
                          try {
                            await MoreApi.instance.revokeSession(asInt(s['session']));
                            reload();
                          } catch (e) {
                            if (context.mounted) showMessage(context, '$e');
                          }
                        }, child: const Text('Sign out', style: TextStyle(color: EvColors.red))),
                ),
            ])),
            const Padding(padding: EdgeInsets.fromLTRB(4, 18, 4, 8), child: Text('DANGER ZONE', style: TextStyle(color: EvColors.red, fontSize: 12, fontWeight: FontWeight.w700))),
            EvCard(padding: EdgeInsets.zero, child: ListTile(onTap: () => push(context, const DeleteAccountScreen()), leading: const Tile(Icons.delete_forever_rounded, EvColors.red, size: 34), title: const Text('Delete account', style: TextStyle(color: EvColors.red, fontWeight: FontWeight.w600)), subtitle: const Text('Permanently remove your account', style: TextStyle(fontSize: 12)))),
          ]),
        ),
      );
}

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});
  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final _cur = TextEditingController(), _new = TextEditingController(), _again = TextEditingController();
  bool _busy = false, _show = false;

  Future<void> _save() async {
    if (_cur.text.isEmpty) return showMessage(context, 'Enter your current password.');
    final problem = passwordProblem(_new.text);
    if (problem != null) return showMessage(context, 'New password: $problem');
    if (_new.text != _again.text) return showMessage(context, 'The new passwords do not match.');
    setState(() => _busy = true);
    try {
      final me = Scope.read(context).current;
      final p = mapOf(await ApiClient.instance.post('user_details', {'guid': me.guid}));
      final u = mapOf(p['user']).isNotEmpty ? mapOf(p['user']) : p;
      await ApiClient.instance.post('user_edit', {
        'guid': me.guid,
        'new_first_name': str(u, 'first_name', me.firstName),
        'new_last_name': str(u, 'last_name'),
        'new_email': str(u, 'email'),
        'new_gender': str(u, 'gender', 'male'),
        'current_password': _cur.text,
        'new_password': _new.text,
      });
      if (!mounted) return;
      showMessage(context, 'Password updated.');
      Navigator.of(context).pop();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _cur.dispose();
    _new.dispose();
    _again.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    InputDecoration dec(String h) => InputDecoration(hintText: h, suffixIcon: IconButton(icon: Icon(_show ? Icons.visibility_off_outlined : Icons.visibility_outlined), onPressed: () => setState(() => _show = !_show)));
    return Scaffold(
      appBar: AppBar(title: const Text('Change password')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Current password', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
        const SizedBox(height: 4),
        TextField(controller: _cur, obscureText: !_show, decoration: dec('Enter current password')),
        const SizedBox(height: 14),
        const Text('New password', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
        const SizedBox(height: 4),
        TextField(controller: _new, obscureText: !_show, decoration: dec('8+ characters with A–Z, a–z and 0–9')),
        const SizedBox(height: 14),
        const Text('Confirm new password', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
        const SizedBox(height: 4),
        TextField(controller: _again, obscureText: !_show, decoration: dec('Re-enter new password')),
        const SizedBox(height: 20),
        EmberButton('Update password', loading: _busy, onPressed: _save),
        Center(child: TextButton(onPressed: () => showForgotPassword(context, prefill: Scope.read(context).current.username), child: const Text('Forgot your current password? Reset it by email', style: TextStyle(color: EvColors.ember2)))),
        const SizedBox(height: 4),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(12)), child: const Text('Use a password you do not use anywhere else, with letters, numbers and a symbol.', style: TextStyle(fontSize: 12.5))),
      ]),
    );
  }
}

class DeleteAccountScreen extends StatefulWidget {
  const DeleteAccountScreen({super.key});
  @override
  State<DeleteAccountScreen> createState() => _DeleteAccountScreenState();
}

class _DeleteAccountScreenState extends State<DeleteAccountScreen> {
  final _pw = TextEditingController();
  bool _agree = false, _busy = false;
  double? _balance;

  @override
  void initState() {
    super.initState();
    MoneyApi.instance.balance().then((b) {
      if (mounted) setState(() => _balance = b);
    }).catchError((_) {});
  }

  @override
  void dispose() {
    _pw.dispose();
    super.dispose();
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(title: const Text('Delete account permanently?'), content: const Text('This is your final confirmation. Your Evinie account and all its data will be erased.'), actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(d, true), style: FilledButton.styleFrom(backgroundColor: EvColors.red), child: const Text('Delete forever'))]));
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    try {
      await ApiClient.instance.post('auth/delete', {'password': _pw.text});
      if (!mounted) return;
      await Scope.read(context).signOut();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Delete account')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: EvColors.red.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(14), border: Border.all(color: EvColors.red.withValues(alpha: 0.4))), child: const Text('This is permanent. Deleting your account cannot be undone. Make sure you have saved anything you want to keep.', style: TextStyle(height: 1.45))),
          const SizedBox(height: 12),
          EvCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('What will be deleted', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            for (final t in ['Your profile, posts, photos and videos', 'Your friends, messages and groups you own', 'Your points, eGifts and membership'])
              Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [const Icon(Icons.cancel_rounded, color: EvColors.red, size: 16), const SizedBox(width: 8), Expanded(child: Text(t, style: const TextStyle(fontSize: 13)))])),
          ])),
          if ((_balance ?? 0) > 0) ...[
            const SizedBox(height: 12),
            Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(14)), child: Text('You still have ${naira(_balance!)} in your Wallet. Cash out first: it cannot be recovered after deletion.', style: const TextStyle(fontWeight: FontWeight.w600))),
          ],
          const SizedBox(height: 16),
          const Text('Confirm your password', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 12.5)),
          const SizedBox(height: 4),
          TextField(controller: _pw, obscureText: true, onChanged: (_) => setState(() {}), decoration: const InputDecoration(hintText: 'Enter your password')),
          CheckboxListTile(value: _agree, onChanged: (v) => setState(() => _agree = v ?? false), contentPadding: EdgeInsets.zero, controlAffinity: ListTileControlAffinity.leading, activeColor: EvColors.red, title: const Text('I understand my account and all its data will be deleted permanently.', style: TextStyle(fontSize: 12.5))),
          const SizedBox(height: 8),
          FilledButton(onPressed: !_agree || _pw.text.isEmpty || _busy ? null : _delete, style: FilledButton.styleFrom(backgroundColor: EvColors.red, minimumSize: const Size.fromHeight(48)), child: Text(_busy ? 'Deleting…' : 'Delete my account')),
          const SizedBox(height: 8),
          OutlineEmberButton('Cancel, keep my account', onPressed: () => Navigator.of(context).pop()),
        ]),
      );
}

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});
  @override
  Widget build(BuildContext context) {
    const faq = [
      ('How do I become an EviEarner?', 'Open Menu → Membership and choose EviEarner. EviEarners can sell on Marketplace, earn from their activity and cash out.'),
      ('How do I cash out?', 'EviEarners can open Wallet → Cash out and request a payout to their bank account.'),
      ('How do I get verified?', 'Open Menu → Get verified, add a photo of your government ID and choose a plan. You can pay once the Evinie team approves your ID.'),
      ('What are UserPoints?', 'You earn points for activity on Evinie. 3,000 points are worth ₦1,000 and can be converted in UserPoints.'),
      ('How do I secure my account?', 'Use a strong password, check Settings → Security & login for unknown devices, and sign them out.'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Help & support')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Frequently asked', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        for (final f in faq) EvCard(padding: EdgeInsets.zero, child: ExpansionTile(shape: const Border(), title: Text(f.$1, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)), childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14), children: [Text(f.$2, style: const TextStyle(height: 1.5, color: EvColors.ink2))])),
        const SizedBox(height: 16),
        OutlineEmberButton('Terms of service', onPressed: () => push(context, const LegalScreen(title: 'Terms of service', path: 'site/terms'))),
        const SizedBox(height: 8),
        OutlineEmberButton('Privacy policy', onPressed: () => push(context, const LegalScreen(title: 'Privacy policy', path: 'site/privacy'))),
      ]),
    );
  }
}

/// Today's prompt at the top of the feed. Refresh asks the server again.
class DailyPromptCard extends StatefulWidget {
  final void Function(String prompt) onAnswer;
  const DailyPromptCard({super.key, required this.onAnswer});
  @override
  State<DailyPromptCard> createState() => _DailyPromptCardState();
}

class _DailyPromptCardState extends State<DailyPromptCard> {
  String? _prompt;
  bool _hidden = false, _busy = false;
  @override
  void initState() {
    super.initState();
    _load();
  }

  static const _store = FlutterSecureStorage();
  String get _today => DateTime.now().toIso8601String().substring(0, 10);

  Future<void> _close() async {
    setState(() => _hidden = true);
    await _store.write(key: 'prompt_closed_on', value: _today);
  }

  Future<void> _load() async {
    if (await _store.read(key: 'prompt_closed_on') == _today) {
      if (mounted) setState(() => _hidden = true);
      return;
    }
    setState(() => _busy = true);
    try {
      final d = await MoreApi.instance.dailyPrompt();
      final p = d['prompt'];
      if (mounted) setState(() => _prompt = p is Map ? str(p, 'text', str(p, 'prompt', str(p, 'title'))) : asStr(p));
    } catch (_) {
      if (mounted) setState(() => _hidden = true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_hidden || (_prompt ?? '').isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(20)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.auto_awesome_rounded, color: Colors.white70, size: 16), const SizedBox(width: 6), const Expanded(child: Text("Today's prompt", style: TextStyle(color: Colors.white70, fontSize: 12))), GestureDetector(onTap: _close, child: const Icon(Icons.close_rounded, color: Colors.white70, size: 18))]),
        const SizedBox(height: 6),
        Text(_prompt!, style: const TextStyle(color: Colors.white, fontSize: 16.5, fontWeight: FontWeight.w700, height: 1.35)),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: SizedBox(height: 40, child: ElevatedButton.icon(onPressed: () => widget.onAnswer(_prompt!), icon: const Icon(Icons.edit_rounded, size: 17), label: const Text('Answer'), style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: EvColors.ember2, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)))))),
          const SizedBox(width: 8),
          SizedBox(height: 40, child: OutlinedButton.icon(onPressed: _busy ? null : _load, icon: const Icon(Icons.refresh_rounded, size: 17), label: const Text('New prompt'), style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white70), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))))),
        ]),
      ]),
    );
  }
}

/// Settings > Saved data: size, and the owner's "Clear saved data".
class _SavedData extends StatefulWidget {
  const _SavedData();
  @override
  State<_SavedData> createState() => _SavedDataState();
}

class _SavedDataState extends State<_SavedData> {
  int? _bytes;
  @override
  void initState() {
    super.initState();
    _measure();
  }

  Future<void> _measure() async {
    final b = await LocalCache.sizeInBytes();
    if (mounted) setState(() => _bytes = b);
  }

  String get _size {
    final b = _bytes ?? 0;
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
    return '${(b / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  @override
  Widget build(BuildContext context) => EvCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Tile(Icons.sd_storage_outlined, EvColors.blue),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Saved on this phone', style: TextStyle(fontWeight: FontWeight.w600)), Text(_bytes == null ? 'Checking…' : '$_size · encrypted', style: const TextStyle(color: EvColors.muted, fontSize: 12))])),
          ]),
          const SizedBox(height: 8),
          const Text('Evinie keeps what you have seen so it opens fast and works offline. Health chats are never saved.', style: TextStyle(color: EvColors.muted, fontSize: 12, height: 1.45)),
          const SizedBox(height: 10),
          OutlineEmberButton('Clear saved data', onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (_) => AlertDialog(
                title: const Text('Clear saved data?'),
                content: const Text('This removes everything Evinie has saved on this phone, for every account. You stay signed in, and content loads again from the internet.'),
                actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear', style: TextStyle(color: EvColors.red)))],
              ),
            );
            if (ok != true) return;
            await LocalCache.clearAll();
            if (context.mounted) showMessage(context, 'Saved data cleared.');
            _measure();
          }),
        ]),
      );
}


/// Earnings for the last 3 paid months, as bars (from creators/dashboard
/// history: each payout cycle, newest first, with cycle_time and earning).
class _ThreeMonths extends StatelessWidget {
  final List<Map> history;
  const _ThreeMonths(this.history);
  @override
  Widget build(BuildContext context) {
    const names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    final cycles = history.where((h) => asInt(h['cycle_time'] ?? h['time']) > 0).take(3).toList().reversed.toList();
    final top = cycles.fold<double>(0, (a, h) => asDouble(h['earning']) > a ? asDouble(h['earning']) : a);
    return EvCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Last 3 months', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        if (cycles.isEmpty)
          const Text('Your earnings will appear here after your first monthly payout.', style: TextStyle(color: EvColors.muted, fontSize: 12))
        else
          SizedBox(
            height: 170,
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (final h in cycles)
                Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text(naira(asDouble(h['earning'])), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700)),
                    Text('Score ${asDouble(h['score']).toStringAsFixed(0)} · RPM ${asDouble(h['rpm']).toStringAsFixed(0)}', style: const TextStyle(fontSize: 9.5, color: EvColors.muted)),
                    const SizedBox(height: 4),
                    Container(
                      height: top == 0 ? 4 : 4 + 100 * asDouble(h['earning']) / top,
                      margin: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(8)),
                    ),
                    const SizedBox(height: 6),
                    Text(() {
                      final t = asTime(h['cycle_time'] ?? h['time']);
                      return '${names[t.month - 1]} ${t.year}';
                    }(), style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                  ]),
                ),
            ]),
          ),
      ]),
    );
  }
}


/// Staff: log a user you brought in (admin-reviewed) and see this month's log.
class _StaffLog extends StatefulWidget {
  const _StaffLog();
  @override
  State<_StaffLog> createState() => _StaffLogState();
}

class _StaffLogState extends State<_StaffLog> {
  final _q = TextEditingController();
  List<Map> _found = [], _history = [];
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    try {
      final r = mapOf(await ApiClient.instance.post('staff/acquisitions'));
      if (mounted) setState(() => _history = listOf(r['list']));
    } catch (_) {}
  }

  Future<void> _search() async {
    if (_q.text.trim().length < 2) return showMessage(context, 'Type at least 2 letters of their name, username or email.');
    FocusScope.of(context).unfocus();
    setState(() => _busy = true);
    try {
      final r = mapOf(await ApiClient.instance.post('staff/search', {'q': _q.text.trim()}));
      if (mounted) setState(() => _found = listOf(r['list']));
      if (mounted && _found.isEmpty) showMessage(context, 'No one found who has not been logged already. Try their username or email.');
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _log(Map u) async {
    try {
      await ApiClient.instance.post('staff/log_user', {'user_guid': asInt(u['guid'])});
      if (!mounted) return;
      showMessage(context, 'Logged. An admin will review it.');
      setState(() => _found = []);
      _q.clear();
      _loadHistory();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        EvCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Log a user you brought in', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            const Text('A logged user is reviewed by an admin before it counts toward your monthly target.', style: TextStyle(color: EvColors.muted, fontSize: 12)),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: TextField(controller: _q, textInputAction: TextInputAction.search, onSubmitted: (_) => _search(), decoration: const InputDecoration(hintText: 'Name, username or email', prefixIcon: Icon(Icons.search_rounded)))),
              const SizedBox(width: 8),
              FilledButton(onPressed: _busy ? null : _search, style: FilledButton.styleFrom(backgroundColor: EvColors.ember2), child: const Text('Search')),
            ]),
            for (final u in _found)
              ListTile(contentPadding: EdgeInsets.zero, leading: Avatar(EvUser.fromJson(u), size: 36), title: Text(EvUser.fromJson(u).fullname), subtitle: Text('@${str(u, 'username')}', style: const TextStyle(fontSize: 12)), trailing: FilledButton(onPressed: () => _log(u), style: FilledButton.styleFrom(backgroundColor: EvColors.ember2, visualDensity: VisualDensity.compact), child: const Text('Log'))),
          ]),
        ),
        const SizedBox(height: 12),
        EvCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Your logged users this month', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            if (_history.isEmpty) const Text('Nothing logged yet.', style: TextStyle(color: EvColors.muted, fontSize: 12.5)),
            for (final h in _history)
              ListTile(contentPadding: EdgeInsets.zero, leading: Avatar(EvUser.fromJson(h), size: 34), title: Text(EvUser.fromJson(h).fullname), trailing: StatusChip(str(h, 'status', 'pending'))),
          ]),
        ),
      ]);
}


/// Terms, Privacy policy and About, shown as app text (kept current from
/// the website's own pages, read without opening a browser).
class LegalScreen extends StatefulWidget {
  final String title, path;
  const LegalScreen({super.key, required this.title, required this.path});
  @override
  State<LegalScreen> createState() => _LegalScreenState();
}

class _LegalScreenState extends State<LegalScreen> {
  String? _text;
  /// Plain, readable text from page HTML.
  static String _plain(String h) {
    h = h.replaceAll(RegExp(r'<(script|style|header|footer|nav)[\s\S]*?</\1>', caseSensitive: false), '');
    h = h.replaceAll(RegExp(r'</(p|div|h[1-6]|li|tr|ul|ol)>', caseSensitive: false), '\n\n').replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n').replaceAll(RegExp(r'<li[^>]*>', caseSensitive: false), '• ');
    return decodeHtml(h.replaceAll(RegExp(r'<[^>]+>'), ''))
        .replaceAll('\u00a0', ' ')
        .replaceAll(RegExp(r'[ \t]+'), ' ')
        .replaceAll(RegExp(r' *\n *'), '\n')
        .replaceAll(RegExp(r'\n{3,}'), '\n\n')
        .trim();
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    // 4.40: the page text exactly as saved in Administration > Site Pages.
    try {
      final r = mapOf(await ApiClient.instance.post('sitepage/get', {'name': widget.path.split('/').last}));
      final t = _plain(str(r, 'html'));
      if (t.isNotEmpty) {
        if (mounted) setState(() => _text = t);
        return;
      }
    } catch (_) {}
    // Older servers: read the website page.
    try {
      final r = await http.get(Uri.parse('${AppConfig.siteUrl}/${widget.path}'));
      var h = r.body;
      final body = RegExp(r'<div[^>]*class="[^"]*(ossn-site-pages-body|ossn-page-contents)[^"]*"[^>]*>([\s\S]*?)</div>\s*</div>', caseSensitive: false).firstMatch(h);
      final t = body == null ? '' : _plain(body.group(2)!);
      if (mounted) setState(() => _text = t.isEmpty ? 'This page is not available yet.' : t);
    } catch (_) {
      if (mounted) setState(() => _text = 'Could not load this page. Check your connection and try again.');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: _text == null
            ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
            : SingleChildScrollView(padding: EdgeInsets.fromLTRB(18, 16, 18, 40 + MediaQuery.of(context).padding.bottom), child: SelectableText(_text!, style: const TextStyle(fontSize: 14, height: 1.6))),
      );
}


/// Staff scorecard: the six monthly targets as "value / target".
class _Scorecard extends StatelessWidget {
  final Map d;
  const _Scorecard(this.d);
  @override
  Widget build(BuildContext context) {
    final rows = listOf(d['rows']);
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    final parts = str(d, 'month').split('-');
    final label = parts.length == 2 ? '${months[(int.tryParse(parts[1]) ?? 1) - 1]} ${parts[0]}' : str(d, 'month');
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(18)),
        child: Row(children: [
          const Icon(Icons.calendar_month_rounded, color: Colors.white),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)), const Text('Targets reset at the start of every month', style: TextStyle(color: Colors.white70, fontSize: 12))])),
        ]),
      ),
      const SizedBox(height: 12),
      if (rows.isNotEmpty)
        Builder(builder: (_) {
          final withTarget = rows.where((r) => asInt(r['target']) > 0).toList();
          final done = withTarget.where((r) => asInt(r['value']) >= asInt(r['target'])).length;
          final all = withTarget.isNotEmpty && done == withTarget.length;
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: all ? const Color(0xFFE7F6EC) : Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: all ? EvColors.green : EvColors.line)),
            child: Row(children: [
              Icon(all ? Icons.emoji_events_rounded : Icons.flag_rounded, color: all ? EvColors.green : EvColors.ember2),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  withTarget.isEmpty
                      ? 'No targets have been set for this month yet.'
                      : all
                          ? 'Well done! You have met all $done targets this month.${asBool(d['salary_paid']) ? ' Your base salary has been paid.' : ''}'
                          : '$done of ${withTarget.length} targets met this month',
                  style: TextStyle(fontWeight: FontWeight.w700, color: all ? EvColors.green : EvColors.ink),
                ),
              ),
            ]),
          );
        }),
      for (final r in rows)
        Builder(builder: (_) {
          final v = asInt(r['value']), t = asInt(r['target']);
          final met = t > 0 && v >= t;
          final pct = t > 0 ? ((v / t) * 100).clamp(0, 100).round() : 0;
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: met ? EvColors.green : EvColors.line)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(str(r, 'label'), style: const TextStyle(fontWeight: FontWeight.w700))),
                Text(t > 0 ? '$v / $t' : '$v', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: met ? EvColors.green : EvColors.ink)),
              ]),
              if (str(r, 'note').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 2), child: Text(str(r, 'note'), style: const TextStyle(color: EvColors.muted, fontSize: 12))),
              const SizedBox(height: 8),
              ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: t == 0 ? 0 : (v / t).clamp(0, 1).toDouble(), minHeight: 7, backgroundColor: EvColors.sand2, color: met ? EvColors.green : EvColors.ember1)),
              const SizedBox(height: 6),
              Row(children: [
                Expanded(
                  child: Text(
                    t == 0 ? 'No target set' : (met ? 'Target met' : 'Target: $t · ${t - v} to go'),
                    style: TextStyle(color: met ? EvColors.green : EvColors.muted, fontSize: 12, fontWeight: met ? FontWeight.w700 : FontWeight.w500),
                  ),
                ),
                if (met) const Icon(Icons.check_circle_rounded, color: EvColors.green, size: 18) else if (t > 0) Text('$pct%', style: const TextStyle(color: EvColors.muted, fontSize: 12, fontWeight: FontWeight.w700)),
              ]),
            ]),
          );
        }),
      const SizedBox(height: 6),
      const _StaffLog(),
    ]);
  }
}


/// OssnInvite: invite friends by email from the app.
class _EmailInvite extends StatefulWidget {
  const _EmailInvite();
  @override
  State<_EmailInvite> createState() => _EmailInviteState();
}

class _EmailInviteState extends State<_EmailInvite> {
  final _emails = TextEditingController(), _msg = TextEditingController();
  bool _busy = false;

  @override
  void dispose() {
    _emails.dispose();
    _msg.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final list = _emails.text.split(RegExp(r'[,\s;]+')).where((e) => e.contains('@')).toList();
    if (list.isEmpty) return showMessage(context, 'Add at least one email address.');
    setState(() => _busy = true);
    try {
      final r = mapOf(await ApiClient.instance.post('invite/email', {'emails': list.join(','), 'message': _msg.text.trim()}));
      final sent = listOf(r['sent']).length + (r['sent'] is List ? (r['sent'] as List).whereType<String>().length : 0);
      final failed = r['failed'] is List ? (r['failed'] as List).join(', ') : '';
      if (!mounted) return;
      showMessage(context, failed.isEmpty ? 'Invitations sent.' : 'Sent ${sent > 0 ? sent : ''}. Could not send to: $failed');
      if (failed.isEmpty) _emails.clear();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => EvCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Invite by email', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          const Text('Separate addresses with commas (up to 20).', style: TextStyle(color: EvColors.muted, fontSize: 12)),
          const SizedBox(height: 8),
          TextField(controller: _emails, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'friend@email.com, another@email.com')),
          const SizedBox(height: 8),
          TextField(controller: _msg, maxLines: 2, decoration: const InputDecoration(hintText: 'Add a personal message (optional)')),
          const SizedBox(height: 10),
          EmberButton('Send invites', icon: Icons.mail_outline_rounded, loading: _busy, onPressed: _send),
        ]),
      );
}


/// Invite on WhatsApp: pick contacts in WhatsApp, or send to one number.
class _WhatsAppInvite extends StatefulWidget {
  final String link;
  const _WhatsAppInvite({required this.link});
  @override
  State<_WhatsAppInvite> createState() => _WhatsAppInviteState();
}

class _WhatsAppInviteState extends State<_WhatsAppInvite> {
  final _phone = TextEditingController();

  @override
  void dispose() {
    _phone.dispose();
    super.dispose();
  }

  String get _text => 'Join me on Evinie, the place to connect, share and earn. Sign up with my link: ${widget.link}';

  /// 0803… → 234803…; +234… → 234…
  String _normalize(String raw) {
    var d = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (d.startsWith('0') && d.length == 11) d = '234${d.substring(1)}';
    return d;
  }

  Future<void> _open({String number = ''}) async {
    final enc = Uri.encodeComponent(_text);
    final app = Uri.parse(number.isEmpty ? 'whatsapp://send?text=$enc' : 'whatsapp://send?phone=$number&text=$enc');
    final web = Uri.parse(number.isEmpty ? 'https://wa.me/?text=$enc' : 'https://wa.me/$number?text=$enc');
    try {
      if (!await launchUrl(app, mode: LaunchMode.externalApplication)) {
        await launchUrl(web, mode: LaunchMode.externalApplication);
      }
    } catch (_) {
      try {
        await launchUrl(web, mode: LaunchMode.externalApplication);
      } catch (_) {
        if (mounted) showMessage(context, 'WhatsApp is not installed on this phone.');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF25D366);
    return EvCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.chat_rounded, color: green), SizedBox(width: 8), Text('Invite on WhatsApp', style: TextStyle(fontWeight: FontWeight.w700))]),
        const SizedBox(height: 4),
        const Text('Your referral link is added to the message automatically.', style: TextStyle(color: EvColors.muted, fontSize: 12)),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: FilledButton.icon(
            onPressed: widget.link.isEmpty ? null : () => _open(),
            icon: const Icon(Icons.send_rounded, size: 18),
            label: const Text('Choose contacts in WhatsApp'),
            style: FilledButton.styleFrom(backgroundColor: green, minimumSize: const Size.fromHeight(46)),
          ),
        ),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: 'Or send to a number, e.g. 0803 000 0000'))),
          const SizedBox(width: 8),
          IconButton.filled(
            onPressed: () {
              final n = _normalize(_phone.text);
              if (n.length < 10) return showMessage(context, 'Enter a full phone number.');
              _open(number: n);
            },
            icon: const Icon(Icons.arrow_forward_rounded),
            style: IconButton.styleFrom(backgroundColor: green),
          ),
        ]),
      ]),
    );
  }
}
