import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../api/api_client.dart';
import '../api/money_api.dart';
import '../config.dart';
import '../models/money.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'discover_screens.dart';
import 'business_screens.dart';
import 'create_screens.dart';
import 'settings_screens.dart';
import 'egift_screens.dart';
import 'grow_screens.dart';
import 'health_screens.dart';
import 'market_screens.dart';
import '../api/more_api.dart';
import '../widgets/feed_extras.dart';
import '../models/models.dart';

void push(BuildContext context, Widget page) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));

/// The side menu: Activity, Finance, Explore (Phase 2 fills Finance).
class MenuScreen extends StatefulWidget {
  final bool inDrawer;
  const MenuScreen({super.key, this.inDrawer = false});
  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  double? _balance;
  int? _points;
  bool _isCreator = false, _isStaff = false, _isEarner = false;

  @override
  void initState() {
    super.initState();
    MoneyApi.instance.balance().then((b) {
      if (mounted) setState(() => _balance = b);
    }).catchError((_) {});
    MoneyApi.instance.points().then((p) {
      if (mounted) setState(() => _points = p);
    }).catchError((_) {});
    // Creator and staff tools are only shown to creators/EviEarners and staff.
    MoneyApi.instance.myTier().then((t) {
      if (mounted) setState(() => _isEarner = t.canMonetize);
    }).catchError((_) {});
    MoreApi.instance.creatorStatus().then((s) {
      if (mounted) setState(() => _isCreator = asBool(s['is_creator']));
    }).catchError((_) {});
    final now = DateTime.now();
    MoreApi.instance.staffSummary('${now.year}-${now.month.toString().padLeft(2, '0')}').then((s) {
      if (mounted) setState(() => _isStaff = s.isNotEmpty);
    }).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Scaffold(
      backgroundColor: widget.inDrawer ? Colors.white : null,
      appBar: widget.inDrawer ? null : AppBar(backgroundColor: const Color(0xFFFFF1E7)),
      body: ListView(padding: EdgeInsets.only(top: widget.inDrawer ? MediaQuery.of(context).padding.top : 0), children: [
        Container(
          color: const Color(0xFFFFF1E7),
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
          child: Row(children: [Avatar(me, size: 56), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [NameLine(me, size: 17), Text('@${me.username}', style: const TextStyle(color: EvColors.muted))]))]),
        ),
        const _Section('Activity'),
        _Group([
          _MenuRow(Icons.visibility_outlined, 'Profile views', null, EvColors.ember2, () => push(context, const ProfileViewsScreen())),
          _MenuRow(Icons.person_add_alt_1_rounded, 'People you may know', null, EvColors.blue, () => push(context, const PeopleScreen())),
          _MenuRow(Icons.bookmark_rounded, 'Saved', null, EvColors.ember2, () => push(context, const SavedScreen())),
        ]),
        const _Section('Finance'),
        _Group([
          _MenuRow(Icons.account_balance_wallet_outlined, 'Wallet', _balance == null ? null : '${naira(_balance!)} balance', EvColors.green, () => push(context, const WalletScreen())),
          _MenuRow(Icons.stars_rounded, 'UserPoints', _points == null ? null : '$_points pts', EvColors.gold, () => push(context, const PointsScreen())),
          _MenuRow(Icons.card_giftcard_rounded, 'eGifts', null, EvColors.red, () => push(context, const GiftsScreen())),
        ]),
        const _Section('Explore'),
        _Group([
          _MenuRow(Icons.groups_rounded, 'Groups', null, const Color(0xFF7C4DFF), () => push(context, const GroupsScreen())),
          _MenuRow(Icons.event_rounded, 'Events', null, EvColors.blue, () => push(context, const EventsScreen())),
          _MenuRow(Icons.bar_chart_rounded, 'Polls', null, EvColors.green, () => push(context, const PollsScreen())),
          _MenuRow(Icons.flag_rounded, 'Business pages', null, EvColors.red, () => push(context, const PagesScreen())),
          _MenuRow(Icons.campaign_outlined, 'Ads', 'Sponsored on Evinie', EvColors.ember2, () => push(context, const AdsScreen())),
          _MenuRow(Icons.sell_outlined, 'My products', 'Your Marketplace listings', EvColors.gold, () => push(context, const MyProductsScreen())),
          _MenuRow(Icons.receipt_long_rounded, 'My orders', 'Marketplace purchases and sales', EvColors.ember2, () => push(context, const OrdersScreen())),
        ]),
        const _Section('Business & health'),
        _Group([
          _MenuRow(Icons.health_and_safety_rounded, 'iHealth Assist', 'AI health help and doctors', const Color(0xFFC9960C), () => push(context, const HealthHome())),
          _MenuRow(Icons.card_giftcard_rounded, 'Refer & win', 'Invite friends and earn', EvColors.green, () => push(context, const ReferralScreen())),
        ]),
        if (_isCreator || _isEarner || _isStaff) ...[
          const _Section('Grow'),
          _Group([
            if (_isCreator || _isEarner) _MenuRow(Icons.auto_graph_rounded, 'Creator dashboard', null, const Color(0xFF7C4DFF), () => push(context, const CreatorsScreen())),
            if (_isStaff) _MenuRow(Icons.badge_outlined, 'Staff scorecard', 'For Evinie staff', EvColors.blue, () => push(context, const StaffScreen())),
          ]),
        ],
        const _Section('Account'),
        _Group([
          _MenuRow(Icons.verified_rounded, 'Get verified', null, EvColors.blue, () => push(context, const GetVerifiedScreen())),
          _MenuRow(Icons.workspace_premium_rounded, 'Membership', 'EviMember or EviEarner', EvColors.ember2, () => push(context, const MembershipScreen())),
          _MenuRow(Icons.settings_outlined, 'Settings', 'Profile, devices and sign out', EvColors.muted, () => push(context, const SettingsScreen())),
        ]),
        const SizedBox(height: 24),
      ]),
    );
  }
}

class _Section extends StatelessWidget {
  final String t;
  const _Section(this.t);
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 8), child: Text(t, style: const TextStyle(color: EvColors.muted, fontSize: 11.5, fontWeight: FontWeight.w500)));
}

class _Group extends StatelessWidget {
  final List<Widget> rows;
  const _Group(this.rows);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: EvCard(padding: EdgeInsets.zero, child: Column(children: [for (var i = 0; i < rows.length; i++) ...[if (i > 0) const Divider(height: 1, indent: 60), rows[i]]])),
      );
}

class _MenuRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? sub;
  final Color color;
  final VoidCallback onTap;
  const _MenuRow(this.icon, this.title, this.sub, this.color, this.onTap);
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
          child: Row(children: [
            Tile(icon, color, size: 30),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                if (sub != null && (title == 'Wallet' || title == 'UserPoints')) Text(sub!.replaceAll(' balance', ''), style: const TextStyle(color: EvColors.ember2, fontSize: 11.5, fontWeight: FontWeight.w600)),
              ]),
            ),
            const Icon(Icons.chevron_right_rounded, color: EvColors.muted, size: 18),
          ]),
        ),
      );
}

/// Soft coloured icon tile used across the money screens.
class Tile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;
  const Tile(this.icon, this.color, {super.key, this.size = 40});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(size * 0.32)),
        child: Icon(icon, color: color, size: size * 0.5),
      );
}

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  double? _balance;
  int? _points;
  final _rows = <WalletEntry>[];
  int _page = 1, _count = 0;
  String? _error;
  bool _moreLoading = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final b = await MoneyApi.instance.balance();
      final (rows, count) = await MoneyApi.instance.history(1);
      if (!mounted) return;
      setState(() {
        _balance = b;
        _rows
          ..clear()
          ..addAll(rows);
        _count = count;
        _page = 1;
      });
      MoneyApi.instance.points().then((p) {
        if (mounted) setState(() => _points = p);
      }).catchError((_) {});
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  Future<void> _more() async {
    setState(() => _moreLoading = true);
    try {
      final (rows, _) = await MoneyApi.instance.history(_page + 1);
      if (mounted) {
        setState(() {
          _page++;
          _rows.addAll(rows);
        });
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _moreLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Wallet')),
        body: _error != null && _balance == null
            ? StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load your Wallet", body: _error!, action: 'Try again', onAction: _load)
            : RefreshIndicator(
                color: EvColors.ember2,
                onRefresh: _load,
                child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(26), boxShadow: [BoxShadow(color: EvColors.ember2.withValues(alpha: 0.4), blurRadius: 24, offset: const Offset(0, 12))]),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('Current balance', style: TextStyle(color: Colors.white70, fontSize: 13)),
                      const SizedBox(height: 4),
                      _balance == null
                          ? const Skeleton(height: 36, width: 180)
                          : Text(naira(_balance!), style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w700, letterSpacing: -0.8)),
                      const SizedBox(height: 4),
                      const Row(children: [Icon(Icons.shield_outlined, color: Colors.white70, size: 14), SizedBox(width: 4), Text('Secured wallet · Naira', style: TextStyle(color: Colors.white70, fontSize: 11.5))]),
                      const SizedBox(height: 16),
                      Row(children: [
                        if (!AppConfig.storeSafe) ...[
                          Expanded(child: _whiteButton(Icons.add_rounded, 'Add money', true, () async {
                            final changed = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const AddMoneyScreen()));
                            if (changed == true) _load();
                          })),
                          const SizedBox(width: 10),
                        ],
                        Expanded(child: _whiteButton(Icons.upload_rounded, 'Cash out', false, () async {
                          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => CashoutScreen(balance: _balance ?? 0)));
                          _load();
                        })),
                      ]),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  GestureDetector(onTap: () => push(context, const PointsScreen()), child: PointsCard(points: _points)),
                  const SizedBox(height: 18),
                  const Text('History', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 8),
                  if (_balance == null) ...List.generate(3, (_) => const Padding(padding: EdgeInsets.only(bottom: 10), child: Skeleton(height: 54, radius: 14))),
                  if (_balance != null && _rows.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Text('No transactions yet. Money you add, spend or receive shows here.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))),
                  if (_rows.isNotEmpty)
                    EvCard(
                      padding: EdgeInsets.zero,
                      child: Column(children: [
                        for (var i = 0; i < _rows.length; i++) ...[
                          if (i > 0) const Divider(height: 1, indent: 64),
                          ListTile(
                            leading: Tile(_rows[i].credit ? Icons.south_west_rounded : Icons.north_east_rounded, _rows[i].credit ? EvColors.green : EvColors.red),
                            title: Text(_rows[i].title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                            subtitle: Text(timeAgo(_rows[i].time), style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
                            trailing: Text('${_rows[i].credit ? '+' : '−'}${naira(_rows[i].amount)}', style: TextStyle(fontWeight: FontWeight.w700, color: _rows[i].credit ? EvColors.green : EvColors.red)),
                          ),
                        ],
                      ]),
                    ),
                  if (_rows.length < _count)
                    Padding(
                      padding: const EdgeInsets.only(top: 12),
                      child: Center(child: _moreLoading ? const CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4) : TextButton(onPressed: _more, child: const Text('Show more'))),
                    ),
                ]),
              ),
      );

  Widget _whiteButton(IconData icon, String label, bool filled, VoidCallback onTap) => Material(
        color: filled ? Colors.white : Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: filled ? BorderSide.none : const BorderSide(color: Colors.white70, width: 1.5)),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: SizedBox(height: 44, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 18, color: filled ? EvColors.ember2 : Colors.white), const SizedBox(width: 6), Text(label, style: TextStyle(fontWeight: FontWeight.w700, color: filled ? EvColors.ember2 : Colors.white))])),
        ),
      );
}

/// 3,000 points = ₦1,000.
const kPointsPerUnit = 3000;
const kNairaPerUnit = 1000;

class PointsCard extends StatelessWidget {
  final int? points;
  const PointsCard({super.key, required this.points});
  @override
  Widget build(BuildContext context) {
    final p = points ?? 0;
    final progress = (p % kPointsPerUnit) / kPointsPerUnit;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: EvColors.ink, borderRadius: BorderRadius.circular(22)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.star_rounded, color: EvColors.gold, size: 17), SizedBox(width: 5), Text('UserPoints', style: TextStyle(color: Colors.white70, fontSize: 12.5)), Spacer(), Icon(Icons.chevron_right_rounded, color: Colors.white38)]),
        const SizedBox(height: 4),
        points == null ? const Skeleton(height: 24, width: 90) : Text('$p pts', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: progress, minHeight: 8, backgroundColor: Colors.white12, color: EvColors.ember1)),
        const SizedBox(height: 6),
        Row(children: [
          Text('${p % kPointsPerUnit} / $kPointsPerUnit to the next ${naira(kNairaPerUnit)}', style: const TextStyle(color: Colors.white60, fontSize: 11)),
          const Spacer(),
          Text('Worth ${naira((p / kPointsPerUnit * kNairaPerUnit).floor())}', style: const TextStyle(color: EvColors.gold, fontSize: 11.5, fontWeight: FontWeight.w700)),
        ]),
      ]),
    );
  }
}

class AddMoneyScreen extends StatefulWidget {
  const AddMoneyScreen({super.key});
  @override
  State<AddMoneyScreen> createState() => _AddMoneyScreenState();
}

class _AddMoneyScreenState extends State<AddMoneyScreen> {
  final _amount = TextEditingController(text: '5000');
  bool _busy = false;

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  Future<void> _pay() async {
    final amount = int.tryParse(_amount.text.replaceAll(',', '').trim()) ?? 0;
    if (amount < 100) return showMessage(context, 'The minimum top-up is ₦100.');
    setState(() => _busy = true);
    try {
      final (link, txRef) = await MoneyApi.instance.startTopUp(amount);
      if (!mounted) return;
      final ret = await Navigator.of(context).push<Map<String, String>>(MaterialPageRoute(builder: (_) => PaymentWebView(url: link), fullscreenDialog: true));
      if (ret == null || ret['status'] == 'cancelled') {
        if (mounted) showMessage(context, 'Payment cancelled. You were not charged.');
        return;
      }
      final (credited, reason, balance) = await MoneyApi.instance.verifyTopUp(ret['tx_ref'] ?? txRef, ret['transaction_id'] ?? '');
      if (!mounted) return;
      if (credited || reason == 'already_processed') {
        await showDialog<void>(
          context: context,
          builder: (_) => AlertDialog(
            icon: const Icon(Icons.check_circle_rounded, color: EvColors.green, size: 48),
            title: const Text('Money added'),
            content: Text('${naira(amount)} was added. Your balance is ${naira(balance)}.', textAlign: TextAlign.center),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
          ),
        );
        if (mounted) Navigator.of(context).pop(true);
      } else {
        showMessage(context, "The payment wasn't confirmed. If you were charged, it will be checked and added.");
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Add money')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('How much do you want to add?', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          EvCard(
            child: TextField(
              controller: _amount,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w700),
              decoration: const InputDecoration(prefixText: '₦ ', border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, filled: false),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(alignment: WrapAlignment.center, spacing: 8, children: [
            for (final a in [2000, 5000, 10000, 20000])
              ChoiceChip(label: Text(naira(a)), selected: _amount.text == '$a', onSelected: (_) => setState(() => _amount.text = '$a'), selectedColor: EvColors.ink, labelStyle: TextStyle(color: _amount.text == '$a' ? Colors.white : EvColors.ink)),
          ]),
          const SizedBox(height: 20),
          const EvCard(child: Row(children: [Tile(Icons.credit_card_rounded, EvColors.gold), SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Flutterwave', style: TextStyle(fontWeight: FontWeight.w700)), Text('Card, bank transfer & USSD', style: TextStyle(color: EvColors.muted, fontSize: 12))]))])),
          const SizedBox(height: 24),
          EmberButton('Continue to payment', loading: _busy, onPressed: _pay),
          const SizedBox(height: 10),
          const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.lock_outline_rounded, size: 14, color: EvColors.muted), SizedBox(width: 4), Text('Secure payment by Flutterwave', style: TextStyle(color: EvColors.muted, fontSize: 12))]),
        ]),
      );
}

/// Shows the Flutterwave page and catches its return BEFORE the website
/// page loads, so only the app confirms the payment (once).
class PaymentWebView extends StatefulWidget {
  final String url;
  const PaymentWebView({super.key, required this.url});
  @override
  State<PaymentWebView> createState() => _PaymentWebViewState();
}

class _PaymentWebViewState extends State<PaymentWebView> {
  late final WebViewController _web;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (_) {
          if (mounted) setState(() => _loading = false);
        },
        onNavigationRequest: (req) {
          final uri = Uri.parse(req.url);
          if (uri.path.contains('wallet/charge/flutterwave')) {
            Navigator.of(context).pop(Map<String, String>.from(uri.queryParameters));
            return NavigationDecision.prevent;
          }
          return NavigationDecision.navigate;
        },
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Secure payment'), leading: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.of(context).pop({'status': 'cancelled'}))),
        body: Stack(children: [WebViewWidget(controller: _web), if (_loading) const LinearProgressIndicator(color: EvColors.ember2, minHeight: 3)]),
      );
}

/// Shows a website page inside the app (for things the API can't do yet).
class WebPage extends StatelessWidget {
  final String title;
  final String path;
  const WebPage({super.key, required this.title, required this.path});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: WebViewWidget(controller: WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted)..loadRequest(Uri.parse('${AppConfig.siteUrl}/$path'))),
      );
}

class CashoutScreen extends StatefulWidget {
  final double balance;
  const CashoutScreen({super.key, required this.balance});
  @override
  State<CashoutScreen> createState() => _CashoutScreenState();
}

class _CashoutScreenState extends State<CashoutScreen> {
  final _form = GlobalKey<FormState>();
  final _bank = TextEditingController();
  final _number = TextEditingController();
  final _name = TextEditingController();
  final _amount = TextEditingController();
  bool? _allowed;
  List<Cashout>? _requests;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [_bank, _number, _name, _amount]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final t = await MoneyApi.instance.myTier();
      if (mounted) setState(() => _allowed = t.canMonetize);
      if (t.canMonetize) {
        final r = await MoneyApi.instance.cashouts();
        if (mounted) setState(() => _requests = r);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _allowed = false);
        showMessage(context, '$e');
      }
    }
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      await MoneyApi.instance.requestCashout(amount: int.parse(_amount.text.trim()), bank: _bank.text.trim(), accountNumber: _number.text.trim(), accountName: _name.text.trim());
      if (!mounted) return;
      showMessage(context, 'Request sent. It reaches your bank in 1–3 business days.');
      _amount.clear();
      _load();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_allowed == null) return Scaffold(appBar: AppBar(title: const Text('Cash out')), body: const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)));
    if (_allowed == false) {
      return Scaffold(
        appBar: AppBar(title: const Text('Cash out')),
        body: ListView(padding: const EdgeInsets.all(24), children: [
          const SizedBox(height: 12),
          const Center(child: Tile(Icons.account_balance_rounded, EvColors.ember2, size: 84)),
          const SizedBox(height: 18),
          const Text('Cash out is for EviEarners', textAlign: TextAlign.center, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('Withdrawing your earnings to a bank account is an EviEarner feature. Become an EviEarner to move your money out.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, height: 1.5)),
          const SizedBox(height: 24),
          if (!AppConfig.storeSafe) EmberButton('Become an EviEarner', onPressed: () => push(context, const MembershipScreen())),
        ]),
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Cash out')),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          EvCard(child: Row(children: [const Expanded(child: Text('Available to withdraw', style: TextStyle(color: EvColors.muted))), Text(naira(widget.balance), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18))])),
          const SizedBox(height: 14),
          TextFormField(controller: _bank, decoration: const InputDecoration(hintText: 'Bank name', prefixIcon: Icon(Icons.account_balance_outlined)), validator: (v) => (v ?? '').trim().isEmpty ? 'Enter your bank' : null),
          const SizedBox(height: 10),
          TextFormField(controller: _number, keyboardType: TextInputType.number, maxLength: 10, decoration: const InputDecoration(hintText: 'Account number (10 digits)', counterText: ''), validator: (v) => RegExp(r'^\d{10}$').hasMatch((v ?? '').trim()) ? null : 'Enter a 10-digit account number'),
          const SizedBox(height: 10),
          TextFormField(controller: _name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'Account name'), validator: (v) => (v ?? '').trim().isEmpty ? 'Enter the account name' : null),
          const SizedBox(height: 10),
          TextFormField(
            controller: _amount,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(hintText: 'Amount', prefixText: '₦ '),
            validator: (v) {
              final a = int.tryParse((v ?? '').trim()) ?? 0;
              if (a <= 0) return 'Enter an amount';
              if (a > widget.balance) return 'More than your balance';
              return null;
            },
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: EvColors.peach, borderRadius: BorderRadius.circular(14)),
            child: const Row(children: [Icon(Icons.info_outline_rounded, color: EvColors.ember2, size: 18), SizedBox(width: 8), Expanded(child: Text('Requests are reviewed and paid within 1–3 business days. Any fee is shown on the request.', style: TextStyle(fontSize: 12, height: 1.45)))]),
          ),
          const SizedBox(height: 16),
          EmberButton('Request cash out', loading: _busy, onPressed: _submit),
          if ((_requests ?? []).isNotEmpty) ...[
            const SizedBox(height: 22),
            const Text('Your requests', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            const SizedBox(height: 8),
            for (final r in _requests!)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: EvCard(
                  child: Row(children: [
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(naira(r.amount), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                        Text('${r.bank} ••${r.accountNumber.length > 4 ? r.accountNumber.substring(r.accountNumber.length - 4) : r.accountNumber} · ${timeAgo(r.time)}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                        if (r.fee > 0) Text('Fee ${naira(r.fee)} · you receive ${naira(r.net)}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                        if (r.note.isNotEmpty) Text(r.note, style: const TextStyle(fontSize: 12)),
                      ]),
                    ),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      StatusChip(r.status),
                      if (r.status == 'pending')
                        TextButton(
                          onPressed: () async {
                            try {
                              await MoneyApi.instance.cancelCashout(r.guid);
                              _load();
                            } catch (e) {
                              if (mounted) showMessage(this.context, '$e');
                            }
                          },
                          child: const Text('Cancel'),
                        ),
                    ]),
                  ]),
                ),
              ),
          ],
        ]),
      ),
    );
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) {
    final s = status.toLowerCase();
    final (bg, fg) = s.contains('approv') || s.contains('paid') || s.contains('complete')
        ? (EvColors.greenBg, EvColors.green)
        : s.contains('reject') || s.contains('cancel') || s.contains('fail')
            ? (EvColors.redBg, EvColors.red)
            : (const Color(0xFFFFF4DF), const Color(0xFFB36F00));
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
      child: Text(s.isEmpty ? 'Pending' : s[0].toUpperCase() + s.substring(1), style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w700)),
    );
  }
}

class PointsScreen extends StatefulWidget {
  const PointsScreen({super.key});
  @override
  State<PointsScreen> createState() => _PointsScreenState();
}

class _PointsScreenState extends State<PointsScreen> {
  int? _points;
  List<PointsActivity>? _acts;

  @override
  void initState() {
    super.initState();
    MoneyApi.instance.points().then((p) {
      if (mounted) setState(() => _points = p);
    }).catchError((e) {
      if (mounted) showMessage(context, '$e');
    });
    MoneyApi.instance.pointsActivity().then((a) {
      if (mounted) setState(() => _acts = a);
    }).catchError((_) {
      if (mounted) setState(() => _acts = []);
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('UserPoints')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          PointsCard(points: _points),
          const SizedBox(height: 12),
          EvCard(child: Row(children: [const Tile(Icons.sync_rounded, EvColors.ember2), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$kPointsPerUnit pts = ${naira(kNairaPerUnit)}', style: const TextStyle(fontWeight: FontWeight.w700)), const Text('Every 3,000 points you earn is worth ₦1,000 in your Wallet.', style: TextStyle(color: EvColors.muted, fontSize: 12))]))])),
          const SizedBox(height: 18),
          const Text('Earning activity', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 8),
          if (_acts == null) const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))),
          if (_acts != null && _acts!.isEmpty) const Text('No points yet. Post, comment and invite friends to start earning.', style: TextStyle(color: EvColors.muted)),
          if ((_acts ?? []).isNotEmpty)
            EvCard(
              padding: EdgeInsets.zero,
              child: Column(children: [
                for (var i = 0; i < _acts!.length; i++) ...[
                  if (i > 0) const Divider(height: 1, indent: 64),
                  ListTile(
                    leading: const Tile(Icons.star_rounded, EvColors.gold),
                    title: Text(_acts![i].label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                    subtitle: Text(timeAgo(_acts![i].time), style: const TextStyle(color: EvColors.muted, fontSize: 11.5)),
                    trailing: Text('${_acts![i].delta >= 0 ? '+' : ''}${_acts![i].delta} pts', style: TextStyle(fontWeight: FontWeight.w700, color: _acts![i].delta >= 0 ? EvColors.green : EvColors.red)),
                  ),
                ],
              ]),
            ),
        ]),
      );
}

class GetVerifiedScreen extends StatefulWidget {
  const GetVerifiedScreen({super.key});
  @override
  State<GetVerifiedScreen> createState() => _GetVerifiedScreenState();
}

class _GetVerifiedScreenState extends State<GetVerifiedScreen> {
  VerifyStatus? _status;
  String _plan = 'yearly';
  File? _id;
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _error = null);
    try {
      final s = await MoneyApi.instance.verifyStatus();
      if (mounted) setState(() => _status = s);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  bool get _idIsPdf => _id != null && _id!.path.toLowerCase().endsWith('.pdf');
  String get _idName => _id == null ? '' : _id!.path.split(RegExp(r'[\\/]')).last;

  /// Photo from the gallery, a new photo, or a PDF.
  Future<void> _pickId() async {
    final pick = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.white,
      builder: (s) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.photo_library_outlined, color: EvColors.blue), title: const Text('Photo from gallery'), onTap: () => Navigator.pop(s, 'gallery')),
          ListTile(leading: const Icon(Icons.photo_camera_outlined, color: EvColors.ember2), title: const Text('Take a photo'), onTap: () => Navigator.pop(s, 'camera')),
          ListTile(leading: const Icon(Icons.picture_as_pdf_outlined, color: EvColors.red), title: const Text('PDF document'), onTap: () => Navigator.pop(s, 'pdf')),
        ]),
      ),
    );
    File? f;
    if (pick == 'gallery' || pick == 'camera') {
      final x = await ImagePicker().pickImage(source: pick == 'camera' ? ImageSource.camera : ImageSource.gallery, maxWidth: 2000, imageQuality: 85);
      if (x != null) f = File(x.path);
    } else if (pick == 'pdf') {
      final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png']);
      final path = r?.files.single.path;
      if (path != null) f = File(path);
    }
    if (f == null || !mounted) return;
    setState(() => _id = f);
    showMessage(context, 'ID attached: $_idName');
  }

  /// Sends the attached ID for review. Returns true when it was received.
  Future<bool> _sendId() async {
    if (_id == null) return false;
    await ApiClient.instance.upload('paidverify/uploadid', {}, 'id_photo', _id!);
    if (mounted) setState(() => _id = null);
    return true;
  }

  Future<void> _done(String msg) async {
    await _load();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (d) => AlertDialog(
        icon: const Icon(Icons.schedule_rounded, color: EvColors.gold, size: 46),
        title: const Text('Request received'),
        content: Text('$msg\n\nYour request is pending. The badge only appears after the Evinie team approves your ID (usually within 24–48 hours). If it is not approved, the fee goes back to your Wallet.', textAlign: TextAlign.center),
        actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('OK'))],
      ),
    );
  }

  /// Not paid yet: pay, then send the attached ID - one step for the member.
  Future<void> _pay() async {
    if (_id == null) return showMessage(context, 'Attach your government ID first (photo or PDF).');
    setState(() => _busy = true);
    try {
      final msg = await MoneyApi.instance.payVerification(_plan);
      try {
        await _sendId();
      } catch (e) {
        // Paid, but the ID didn't arrive: keep it attached so they can resend.
        await _load();
        if (mounted) showMessage(context, 'Payment received, but your ID did not upload: $e Tap "Submit ID for review" to try again.');
        return;
      }
      await _done(msg);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  /// Already paid (first upload failed, or the last ID was rejected).
  Future<void> _submitId() async {
    if (_id == null) return showMessage(context, 'Attach your government ID first (photo or PDF).');
    setState(() => _busy = true);
    try {
      await _sendId();
      await _done('Your ID has been sent for review.');
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _centered(IconData icon, Color color, String title, String body, {Widget? action}) => ListView(padding: const EdgeInsets.all(24), children: [
        const SizedBox(height: 30),
        Icon(icon, color: color, size: 72),
        const SizedBox(height: 12),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Text(body, textAlign: TextAlign.center, style: const TextStyle(color: EvColors.muted, height: 1.5)),
        if (action != null) ...[const SizedBox(height: 20), action],
      ]);

  Widget _attachedId() {
    if (_id == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: const Color(0xFFEAF7EE), borderRadius: BorderRadius.circular(14), border: Border.all(color: EvColors.green)),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              width: 56,
              height: 56,
              child: _idIsPdf ? const ColoredBox(color: Colors.white, child: Icon(Icons.picture_as_pdf_rounded, color: EvColors.red, size: 32)) : Image.file(_id!, fit: BoxFit.cover),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [Icon(Icons.check_circle_rounded, color: EvColors.green, size: 16), SizedBox(width: 4), Text('ID attached', style: TextStyle(fontWeight: FontWeight.w700, color: EvColors.green))]),
              Text(_idName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: EvColors.muted, fontSize: 12)),
              const Text('It is sent when you submit below.', style: TextStyle(color: EvColors.muted, fontSize: 11.5)),
            ]),
          ),
          IconButton(tooltip: 'Remove', onPressed: _busy ? null : () => setState(() => _id = null), icon: const Icon(Icons.close_rounded)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    final s = _status;
    final plan = s?.plans.where((p) => p.plan == _plan).firstOrNull;
    final monthly = s?.plans.where((p) => p.plan == 'monthly').firstOrNull;
    final Widget body;
    if (_error != null) {
      body = StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load verification", body: _error!, action: 'Try again', onAction: _load);
    } else if (s == null) {
      body = const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
    } else if (s.verified) {
      body = _centered(Icons.verified_rounded, EvColors.blue, "You're verified", s.renews == null ? 'Your blue badge is active.' : 'Your badge is active. Next review and renewal: ${s.renews!.day}/${s.renews!.month}/${s.renews!.year}.');
    } else if (me.verified && s.status == 'not_subscribed') {
      // Verified directly by an admin, without a paid request.
      body = _centered(Icons.verified_rounded, EvColors.blue, "You're verified", 'Your blue badge shows on your profile and posts.');
    } else if (s.pending) {
      body = _centered(Icons.schedule_rounded, EvColors.gold, 'Request pending', 'Your ID has been received and is waiting for the Evinie team to review it (usually 24–48 hours). Your badge appears only after it is approved.', action: OutlinedButton(onPressed: _load, child: const Text('Check status')));
    } else {
      final idText = switch (s.idStatus) {
        'approved' => 'Approved',
        'pending' => 'Under review by the Evinie team',
        'rejected' => 'Not approved${s.idNote.isEmpty ? '' : ': ${s.idNote}'}. Attach a new one.',
        _ => "NIN slip, passport or driver's licence (photo or PDF)",
      };
      body = ListView(padding: const EdgeInsets.all(16), children: [
        if (s.rejected)
          Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFFFDECEC), borderRadius: BorderRadius.circular(14), border: Border.all(color: EvColors.red)),
            child: Text('Your last request was not approved${s.idNote.isEmpty ? '.' : ': ${s.idNote}'} You are not verified. Attach a clearer ID and submit again - no new payment needed while your plan is active.', style: const TextStyle(height: 1.4)),
          ),
        const EvCard(
          child: Column(children: [
            Icon(Icons.verified_rounded, color: EvColors.blue, size: 56),
            SizedBox(height: 8),
            Text('Get verified', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            Text('Stand out with a blue badge and build trust with your audience.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted)),
          ]),
        ),
        const SizedBox(height: 12),
        if (s.needsPayment)
          Row(children: [
            for (final p in s.plans)
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _plan = p.plan),
                  child: Container(
                    margin: EdgeInsets.only(right: p == s.plans.last ? 0 : 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: _plan == p.plan ? EvColors.peach : Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: _plan == p.plan ? EvColors.ember1 : EvColors.line, width: _plan == p.plan ? 1.5 : 1)),
                    child: Column(children: [
                      Text(p.plan == 'yearly' ? 'Yearly' : 'Monthly', style: TextStyle(fontWeight: FontWeight.w700, color: _plan == p.plan ? EvColors.ember2 : EvColors.ink)),
                      Text('${naira(p.price)} / ${p.period}', style: const TextStyle(color: EvColors.muted, fontSize: 12)),
                      if (p.plan == 'yearly' && monthly != null && monthly.price * 12 > p.price)
                        Text('Save ${((1 - p.price / (monthly.price * 12)) * 100).round()}%', style: const TextStyle(color: EvColors.green, fontSize: 11.5, fontWeight: FontWeight.w700)),
                    ]),
                  ),
                ),
              ),
          ]),
        if (s.needsPayment) const SizedBox(height: 12),
        EvCard(
          child: Column(children: [
            Row(children: [
              Tile(s.idStatus == 'rejected' ? Icons.error_outline_rounded : Icons.badge_outlined, s.idStatus == 'rejected' ? EvColors.red : EvColors.blue),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Government ID', style: TextStyle(fontWeight: FontWeight.w700)), Text(idText, style: const TextStyle(color: EvColors.muted, fontSize: 12))])),
              TextButton(onPressed: _busy ? null : _pickId, child: Text(_id != null ? 'Change' : 'Attach')),
            ]),
            _attachedId(),
          ]),
        ),
        if (s.needsPayment) ...[
          const SizedBox(height: 12),
          EvCard(child: Row(children: [const Expanded(child: Text('Your wallet balance', style: TextStyle(color: EvColors.muted))), Text(naira(s.walletBalance), style: const TextStyle(fontWeight: FontWeight.w700))])),
        ],
        const SizedBox(height: 20),
        if (AppConfig.storeSafe && s.needsPayment)
          const Text('Verification can be requested on the Evinie website.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted))
        else if (s.needsPayment)
          EmberButton(plan == null ? 'Pay and submit for review' : 'Pay ${naira(plan.price)} and submit for review', loading: _busy, onPressed: _pay)
        else
          EmberButton('Submit ID for review', loading: _busy, onPressed: _submitId),
        const SizedBox(height: 8),
        const Text('Your request stays pending until the Evinie team approves your ID. Refunded if not approved.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontSize: 12)),
      ]);
    }
    return Scaffold(appBar: AppBar(title: const Text('Get verified')), body: RefreshIndicator(onRefresh: _load, child: body));
  }
}

class MembershipScreen extends StatefulWidget {
  const MembershipScreen({super.key});
  @override
  State<MembershipScreen> createState() => _MembershipScreenState();
}

class _MembershipScreenState extends State<MembershipScreen> {
  MyTier? _tier;

  @override
  void initState() {
    super.initState();
    MoneyApi.instance.myTier().then((t) {
      if (mounted) setState(() => _tier = t);
    }).catchError((e) {
      if (mounted) showMessage(context, '$e');
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = _tier;
    final earner = t?.canMonetize ?? false;
    const rows = [('Post, comment and share', true), ('Groups and events', true), ('Marketplace selling', false), ('Cash out points and eGifts', false), ('Monthly EviEarner payouts', false)];
    return Scaffold(
      appBar: AppBar(title: const Text('Membership')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: EvColors.ink, borderRadius: BorderRadius.circular(22)),
          child: Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Your plan', style: TextStyle(color: Colors.white60, fontSize: 12)),
                t == null ? const Skeleton(height: 24, width: 120) : Text(earner ? (t.name.isEmpty ? 'EviEarner' : t.name) : 'EviMember', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700)),
                if (t?.expiry != null) Text('Renews ${t!.expiry!.day}/${t.expiry!.month}/${t.expiry!.year}', style: const TextStyle(color: Colors.white60, fontSize: 12)),
              ]),
            ),
            Icon(earner ? Icons.workspace_premium_rounded : Icons.favorite_rounded, color: EvColors.gold, size: 36),
          ]),
        ),
        const SizedBox(height: 12),
        EvCard(
          child: Column(children: [
            const Row(children: [Expanded(child: Text('What you get', style: TextStyle(color: EvColors.muted, fontSize: 12))), SizedBox(width: 60, child: Text('Member', textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700))), SizedBox(width: 60, child: Text('Earner', textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: EvColors.ember2)))]),
            for (final r in rows) ...[
              const Divider(height: 18),
              Row(children: [
                Expanded(child: Text(r.$1, style: const TextStyle(fontSize: 13))),
                SizedBox(width: 60, child: Icon(r.$2 ? Icons.check_rounded : Icons.remove_rounded, color: r.$2 ? EvColors.green : EvColors.muted, size: 18)),
                const SizedBox(width: 60, child: Icon(Icons.check_rounded, color: EvColors.green, size: 18)),
              ]),
            ],
          ]),
        ),
        const SizedBox(height: 16),
        if (!earner && !AppConfig.storeSafe) ...[
          EmberButton('Become an EviEarner', onPressed: () => startEviEarnerUpgrade(context)),
          const SizedBox(height: 8),
          const Text('Opens the Evinie website. You may need to sign in there once.', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted, fontSize: 12)),
        ],
      ]),
    );
  }
}


/// Become an EviEarner inside the app: price, Wallet deduction, confirm.
Future<void> startEviEarnerUpgrade(BuildContext context) async {
  final api = ApiClient.instance;
  try {
    final tiers = listOf(mapOf(await api.post('membershiptier/list'))['tiers']);
    final t = tiers.firstWhere((x) => asBool(x['monetization_enabled']), orElse: () => const {});
    if (t.isEmpty) throw ApiException('none', 'The EviEarner plan is not available right now.');
    final q = mapOf(await api.post('membership/quote', {'tier': asInt(t['guid'])}));
    if (!context.mounted) return;
    final cost = asDouble(q['cost']), bal = asDouble(q['balance']);
    final enough = bal >= cost;
    final go = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.white,
      builder: (s) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Become ${str(q, 'title', 'an EviEarner')}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            EvCard(child: Column(children: [
              Row(children: [const Expanded(child: Text('Price')), Text(naira(cost), style: const TextStyle(fontWeight: FontWeight.w700, color: EvColors.ember2, fontSize: 16))]),
              if (str(q, 'duration').isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Row(children: [const Expanded(child: Text('Duration')), Text(str(q, 'duration'))])),
              const SizedBox(height: 6),
              Row(children: [const Expanded(child: Text('Wallet balance')), Text(naira(bal), style: TextStyle(color: enough ? EvColors.green : EvColors.red, fontWeight: FontWeight.w600))]),
            ])),
            const SizedBox(height: 10),
            Text(enough ? '${naira(cost)} will be deducted from your Wallet. Do you want to proceed?' : 'Your Wallet balance is too low for this upgrade. Top up first.', style: const TextStyle(height: 1.45)),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: OutlineEmberButton('Cancel', onPressed: () => Navigator.pop(s, false))),
              const SizedBox(width: 8),
              Expanded(child: enough ? EmberButton('Confirm & pay', onPressed: () => Navigator.pop(s, true)) : EmberButton('Top up Wallet', onPressed: () {
                Navigator.pop(s, false);
                push(context, const AddMoneyScreen());
              })),
            ]),
          ]),
        ),
      ),
    );
    if (go != true || !context.mounted) return;
    await api.post('membership/subscribe', {'tier': asInt(t['guid'])});
    if (!context.mounted) return;
    await showDialog<void>(context: context, builder: (d) => AlertDialog(icon: const Icon(Icons.verified_rounded, color: EvColors.green, size: 46), title: const Text('You are now an EviEarner'), content: Text('${naira(cost)} was paid from your Wallet.', textAlign: TextAlign.center), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('OK'))]));
  } catch (e) {
    if (context.mounted) showMessage(context, '$e');
  }
}
