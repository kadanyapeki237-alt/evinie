import 'package:flutter/material.dart';
import '../api/evinie_api.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'check_screen.dart';

/// Shared warm glow at the top of the sign-in screens.
class _AuthBackground extends StatelessWidget {
  final Widget child;
  const _AuthBackground({required this.child});
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(center: Alignment(0, -1.1), radius: 1.2, colors: [Color(0xFFFFE2D0), EvColors.sand], stops: [0, 0.55]),
        ),
        child: SafeArea(child: child),
      );
}

class Wordmark extends StatelessWidget {
  final double size;
  const Wordmark({super.key, this.size = 46});
  @override
  Widget build(BuildContext context) => ShaderMask(
        shaderCallback: (r) => EvColors.emberGradient.createShader(r),
        child: Text('evinie', style: TextStyle(fontSize: size, fontWeight: FontWeight.w700, letterSpacing: -size * 0.04, color: Colors.white)),
      );
}

class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});
  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final _form = GlobalKey<FormState>();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _hide = true;
  bool _busy = false;

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    final session = Scope.read(context);
    try {
      await session.signIn(_user.text.trim(), _pass.text);
    } on TwoFactorRequired catch (t) {
      // Two-step sign-in: the code was emailed; ask for it and finish.
      if (!mounted) return;
      final code = await _askCode(t.message);
      if (code == null || !mounted) return;
      try {
        await session.signIn(_user.text.trim(), _pass.text, challenge: t.challenge, code: code);
      } catch (e) {
        if (mounted) showMessage(context, '$e');
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<String?> _askCode(String message) {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (d) => AlertDialog(
        title: const Text('Check your email'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(message),
          const SizedBox(height: 12),
          TextField(controller: ctrl, autofocus: true, keyboardType: TextInputType.number, maxLength: 6, textAlign: TextAlign.center, style: const TextStyle(fontSize: 22, letterSpacing: 6, fontWeight: FontWeight.w700), decoration: const InputDecoration(hintText: '000000', counterText: '')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(d, ctrl.text.trim()), child: const Text('Verify')),
        ],
      ),
    ).whenComplete(ctrl.dispose);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: _AuthBackground(
          child: Form(
            key: _form,
            child: ListView(padding: const EdgeInsets.fromLTRB(24, 48, 24, 24), children: [
              const Center(child: Wordmark()),
              const SizedBox(height: 28),
              const Text('Welcome back', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: -0.5)),
              const SizedBox(height: 4),
              const Text('Sign in to continue to Evinie', textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted)),
              const SizedBox(height: 28),
              const _Label('Username, email or phone number'),
              TextFormField(
                controller: _user,
                keyboardType: TextInputType.emailAddress,
                autocorrect: false,
                autofillHints: const [AutofillHints.username],
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(hintText: 'username, you@example.com or 0803...', prefixIcon: Icon(Icons.person_outline_rounded)),
                validator: (v) => (v ?? '').trim().isEmpty ? 'Enter your username, email or phone number' : null,
              ),
              const SizedBox(height: 14),
              const _Label('Password'),
              TextFormField(
                controller: _pass,
                obscureText: _hide,
                autofillHints: const [AutofillHints.password],
                onFieldSubmitted: (_) => _submit(),
                decoration: InputDecoration(
                  hintText: 'Enter your password',
                  prefixIcon: const Icon(Icons.lock_outline_rounded),
                  suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility_off_outlined : Icons.visibility_outlined), onPressed: () => setState(() => _hide = !_hide)),
                ),
                validator: (v) => (v ?? '').isEmpty ? 'Enter your password' : null,
              ),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(onPressed: () => showForgotPassword(context, prefill: _user.text.trim()), child: const Text('Forgot password?', style: TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w600))),
              ),
              const SizedBox(height: 8),
              EmberButton('Sign in', loading: _busy, onPressed: _submit),
              const SizedBox(height: 24),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Text('New here? ', style: TextStyle(color: EvColors.muted)),
                GestureDetector(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SignUpScreen())),
                  child: const Text('Create account', style: TextStyle(color: EvColors.ember2, fontWeight: FontWeight.w700)),
                ),
              ]),
              const SizedBox(height: 10),
              Center(
                child: TextButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CheckScreen())),
                  icon: const Icon(Icons.wifi_tethering_rounded, size: 16, color: EvColors.muted),
                  label: const Text('Trouble signing in? Check connection', style: TextStyle(color: EvColors.muted, fontSize: 12.5)),
                ),
              ),
            ]),
          ),
        ),
      );
}

class _Label extends StatelessWidget {
  final String text;
  const _Label(this.text);
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 6, left: 2), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)));
}

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _form = GlobalKey<FormState>();
  final _first = TextEditingController();
  final _last = TextEditingController();
  final _username = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  DateTime? _birth;
  String? _gender;
  bool _agree = false;
  bool _busy = false;

  @override
  void dispose() {
    for (final c in [_first, _last, _username, _email, _pass]) {
      c.dispose();
    }
    super.dispose();
  }

  String get _birthText => _birth == null
      ? ''
      : '${_birth!.day.toString().padLeft(2, '0')}/${_birth!.month.toString().padLeft(2, '0')}/${_birth!.year}';

  Future<void> _pickBirth() async {
    final now = DateTime.now();
    final d = await showDatePicker(context: context, initialDate: DateTime(now.year - 20), firstDate: DateTime(now.year - 100), lastDate: DateTime(now.year - 13));
    if (d != null) setState(() => _birth = d);
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (_birth == null || _gender == null) return showMessage(context, 'Add your date of birth and gender.');
    if (!_agree) return showMessage(context, 'Please agree to the Terms & Conditions.');
    setState(() => _busy = true);
    try {
      await EvinieApi.instance.signUp(
        firstName: _first.text.trim(),
        lastName: _last.text.trim(),
        email: _email.text.trim(),
        gender: _gender!,
        birthdate: _birthText,
        username: _username.text.trim(),
        password: _pass.text,
      );
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Check your email'),
          content: Text('We sent a link to ${_email.text.trim()}. Confirm your email, then sign in.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
        ),
      );
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: _AuthBackground(
          child: Form(
            key: _form,
            child: ListView(padding: const EdgeInsets.fromLTRB(24, 8, 24, 24), children: [
              Align(alignment: Alignment.centerLeft, child: IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.pop(context))),
              const Text('Create account', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: -0.5)),
              const Text("It's free and always will be", textAlign: TextAlign.center, style: TextStyle(color: EvColors.muted)),
              const SizedBox(height: 20),
              Row(children: [
                Expanded(child: TextFormField(controller: _first, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'First name'), validator: (v) => (v ?? '').trim().isEmpty ? 'Required' : null)),
                const SizedBox(width: 10),
                Expanded(child: TextFormField(controller: _last, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'Last name'), validator: (v) => (v ?? '').trim().isEmpty ? 'Required' : null)),
              ]),
              const SizedBox(height: 12),
              TextFormField(
                controller: _username,
                decoration: const InputDecoration(hintText: 'Username', prefixIcon: Icon(Icons.alternate_email_rounded)),
                validator: (v) => RegExp(r'^[a-zA-Z0-9_]{6,}$').hasMatch((v ?? '').trim()) ? null : 'At least 6 letters or numbers',
              ),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(
                  child: InkWell(
                    onTap: _pickBirth,
                    borderRadius: BorderRadius.circular(14),
                    child: InputDecorator(
                      decoration: const InputDecoration(prefixIcon: Icon(Icons.calendar_today_outlined, size: 18)),
                      child: Text(_birth == null ? 'Date of birth' : _birthText, style: TextStyle(color: _birth == null ? EvColors.muted : EvColors.ink, fontSize: 13)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _gender,
                    hint: const Text('Gender', style: TextStyle(fontSize: 13)),
                    items: const [DropdownMenuItem(value: 'male', child: Text('Male')), DropdownMenuItem(value: 'female', child: Text('Female'))],
                    onChanged: (v) => setState(() => _gender = v),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              TextFormField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(hintText: 'Email', prefixIcon: Icon(Icons.mail_outline_rounded)),
                validator: (v) => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch((v ?? '').trim()) ? null : 'Enter a valid email',
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _pass,
                obscureText: true,
                decoration: const InputDecoration(hintText: 'Password: 8+ characters, A–Z, a–z and 0–9', prefixIcon: Icon(Icons.lock_outline_rounded)),
                validator: (v) => passwordProblem(v ?? ''),
              ),
              const SizedBox(height: 8),
              CheckboxListTile(
                value: _agree,
                onChanged: (v) => setState(() => _agree = v ?? false),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                activeColor: EvColors.ember2,
                title: const Text('I agree to the Terms & Conditions', style: TextStyle(fontSize: 13)),
              ),
              const SizedBox(height: 8),
              EmberButton('Create account', loading: _busy, onPressed: _submit),
            ]),
          ),
        ),
      );
}

/// The same rules as the website (PasswordValidation): at least 8
/// characters with a capital letter, a lower case letter and a number.
String? passwordProblem(String p) {
  if (p.length < 8) return 'Use at least 8 characters.';
  if (!RegExp(r'[A-Z]').hasMatch(p)) return 'Add a capital letter.';
  if (!RegExp(r'[a-z]').hasMatch(p)) return 'Add a lower case letter.';
  if (!RegExp(r'[0-9]').hasMatch(p)) return 'Add a number.';
  return null;
}

/// "Forgot password": emails the website's reset link (the same email as
/// "Reset password" on the website). Used on sign-in and in Settings.
Future<void> showForgotPassword(BuildContext context, {String prefill = ''}) async {
  final ctrl = TextEditingController(text: prefill);
  final login = await showDialog<String>(
    context: context,
    builder: (d) => AlertDialog(
      title: const Text('Reset your password'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text("Enter your username, email or phone number. We'll email you a link to choose a new password."),
        const SizedBox(height: 12),
        TextField(controller: ctrl, autofocus: prefill.isEmpty, keyboardType: TextInputType.emailAddress, autocorrect: false, decoration: const InputDecoration(hintText: 'Username, email or phone')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')),
        TextButton(onPressed: () => Navigator.pop(d, ctrl.text.trim()), child: const Text('Send link')),
      ],
    ),
  );
  ctrl.dispose();
  if (login == null || login.isEmpty || !context.mounted) return;
  try {
    final msg = await EvinieApi.instance.forgotPassword(login);
    if (!context.mounted) return;
    await showDialog<void>(context: context, builder: (d) => AlertDialog(icon: const Icon(Icons.mark_email_read_outlined, color: EvColors.green, size: 40), title: const Text('Check your email'), content: Text(msg), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('OK'))]));
  } catch (e) {
    if (context.mounted) showMessage(context, '$e');
  }
}
