import '../widgets/post_extras.dart';
import 'package:video_player/video_player.dart';
import '../state/media_cache.dart';
import '../state/notifier.dart';
import '../api/more_api.dart';
import '../config.dart';
import 'dart:async';
import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../api/api_client.dart';
import '../api/evinie_api.dart';
import '../models/models.dart';
import '../state/session.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import '../widgets/post_card.dart';
import 'auth_screens.dart';
import 'create_screens.dart';
import 'discover_screens.dart';
import 'grow_screens.dart';
import 'market_screens.dart';
import 'money_screens.dart';
import '../widgets/feed_extras.dart';
import 'social_screens.dart';
import 'settings_screens.dart' show defaultPostAudience;

void openProfile(BuildContext context, EvUser user) =>
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProfileScreen(user: user)));
void openPost(BuildContext context, EvPost post) =>
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => PostScreen(post: post)));

/// Bottom navigation: Home, Discover, create, Marketplace, Profile.
class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _tab = 0;
  final _feedKey = GlobalKey<_FeedScreenState>();

  Future<void> _create() async {
    await showCreateSheet(context);
    if (!mounted) return;
    setState(() => _tab = 0);
    _feedKey.currentState?.refresh();
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    final pages = [
      FeedScreen(key: _feedKey),
      const DiscoverScreen(),
      const SizedBox.shrink(),
      const MarketplaceScreen(),
      ProfileScreen(user: me, isTab: true),
    ];
    return Scaffold(
      body: IndexedStack(index: _tab, children: pages),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: EvColors.line))),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 60,
            child: Row(children: [
              _navItem(0, Icons.home_rounded, Icons.home_outlined, 'Home'),
              _navItem(1, Icons.explore_rounded, Icons.explore_outlined, 'Discover'),
              Expanded(
                child: Center(
                  child: GestureDetector(
                    onTap: _create,
                    child: Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(gradient: EvColors.emberGradient, borderRadius: BorderRadius.circular(18), boxShadow: [BoxShadow(color: EvColors.ember2.withValues(alpha: 0.45), blurRadius: 14, offset: const Offset(0, 6))]),
                      child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
                    ),
                  ),
                ),
              ),
              _navItem(3, Icons.storefront_rounded, Icons.storefront_outlined, 'Marketplace'),
              _navItem(4, Icons.person_rounded, Icons.person_outline_rounded, 'Profile'),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _navItem(int i, IconData on, IconData off, String label) {
    final active = _tab == i;
    final c = active ? EvColors.ember2 : EvColors.muted;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _tab = i),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(active ? on : off, color: c, size: 24),
          const SizedBox(height: 2),
          FittedBox(fit: BoxFit.scaleDown, child: Text(label, maxLines: 1, softWrap: false, style: TextStyle(fontSize: 10.5, color: c, fontWeight: active ? FontWeight.w700 : FontWeight.w500))),
        ]),
      ),
    );
  }
}

class ComingSoon extends StatelessWidget {
  final String title;
  final IconData icon;
  final String body;
  const ComingSoon({super.key, required this.title, required this.icon, required this.body});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: StateMessage(icon: icon, title: '$title is on its way', body: body));
}

class FeedScreen extends StatefulWidget {
  const FeedScreen({super.key});
  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  final _posts = <EvPost>[];
  var _stories = <EvStory>[];
  int _page = 1;
  bool _loading = true;
  bool _more = true;
  bool _fetching = false;
  String? _error;
  int _unread = 0;
  final _scroll = ScrollController();
  final _refresher = GlobalKey<RefreshIndicatorState>();

  /// "New posts" → View: jump to the top and load them with the spinner.
  /// Before, the posts were replaced while the list stayed where you had
  /// scrolled to, so tapping it looked like it did nothing.
  Future<void> _showNewPosts() async {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    if (_scroll.hasClients) {
      await _scroll.animateTo(0, duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
    }
    if (!mounted) return;
    final shown = _refresher.currentState?.show();
    if (shown == null) await refresh();
  }

  @override
  void initState() {
    super.initState();
    // Show the saved feed at once, then refresh from the server.
    final saved = ApiClient.instance.peek('wall_list_home', {'guid': Scope.read(context).current.guid, 'offset': 1, 'count': 10});
    if (saved is Map && saved['posts'] is List) {
      _posts.addAll((saved['posts'] as List).whereType<Map>().map(EvPost.fromJson).where((p) => p.guid > 0));
      _loading = false;
    }
    refresh();
    _watchNewPosts();
    _watchNotifications();
    // Load friends for @mentions in the background, so they appear at once.
    warmMentions(Scope.read(context).current.guid);
    // Tapping a phone notification opens Notifications, or Messages for a chat.
    final nav = Navigator.of(context, rootNavigator: true);
    Notifier.onTap = (payload) => nav.push(MaterialPageRoute(builder: (_) => payload.startsWith('chat:') ? const InboxScreen() : const NotificationsScreen()));
    WidgetsBinding.instance.addPostFrameCallback((_) => Notifier.askPermission());
  }

  @override
  void dispose() {
    _newPostsTimer?.cancel();
    _notifTimer?.cancel();
    _scroll.dispose();
    super.dispose();
  }

  Timer? _newPostsTimer;
  int _lastNotif = -1;
  int _lastMessage = -1;
  Timer? _notifTimer;

  /// Every 20 seconds, while the app is open or running in the background:
  /// new notifications and chat messages appear as phone notifications,
  /// with the notification tone and vibration.
  void _watchNotifications() {
    _notifTimer?.cancel();
    _checkNotifications();
    _notifTimer = Timer.periodic(const Duration(seconds: 20), (_) => _checkNotifications());
  }

  Future<void> _checkNotifications() async {
    if (!mounted) return;
    try {
      final n = mapOf(await ApiClient.instance.post('notifications_count', {'owner_guid': _me}));
      final count = asInt(n['notifications'] ?? n['count'] ?? n['total']);
      if (_lastNotif >= 0 && count > _lastNotif) {
        var text = count - _lastNotif == 1 ? 'You have a new notification' : 'You have ${count - _lastNotif} new notifications';
        try {
          final list = await EvinieApi.instance.notifications(_me, 1);
          if (list.isNotEmpty) {
            final t = list.first.type.toLowerCase();
            final what = t.contains('like') ? 'liked your post' : t.contains('comment') ? 'commented on your post' : t.contains('friend') ? 'sent you a friend request' : t.contains('mention') ? 'mentioned you' : t.contains('gift') ? 'sent you an eGift' : t.contains('share') ? 'shared your post' : 'has new activity for you';
            text = '${list.first.poster.fullname} $what';
          }
        } catch (_) {}
        Notifier.show('Evinie', text);
      }
      _lastNotif = count;
    } catch (_) {}
    await _checkMessages();
  }

  /// New chat messages from other people (not the chat you have open).
  Future<void> _checkMessages() async {
    try {
      final chats = await EvinieApi.instance.recentChats(_me);
      final incoming = chats.where((m) => m.from.guid != _me && !m.viewed && m.id > 0).toList()..sort((a, b) => b.id.compareTo(a.id));
      final newest = incoming.isEmpty ? 0 : incoming.first.id;
      if (_lastMessage >= 0) {
        for (final m in incoming.where((m) => m.id > _lastMessage).take(3)) {
          if (m.from.guid == ChatScreen.openWith) continue;
          Notifier.show(m.from.fullname, m.text.isEmpty ? 'Sent you a message' : m.text, payload: 'chat:${m.from.guid}');
        }
      }
      if (newest > _lastMessage) _lastMessage = newest;
      if (_lastMessage < 0) _lastMessage = 0;
    } catch (_) {}
  }

  /// FeedRefresh: every minute, see if newer posts exist and offer them.
  void _watchNewPosts() {
    _newPostsTimer?.cancel();
    ApiClient.instance.post('user/ping').catchError((_) => null);
    _newPostsTimer = Timer.periodic(const Duration(seconds: 60), (_) async {
      if (!mounted) return;
      // Online while the app is open and connected.
      ApiClient.instance.post('user/ping').catchError((_) => null);
      if (_posts.isEmpty) return;
      try {
        final fresh = await EvinieApi.instance.homeFeed(_me, 1);
        if (!mounted || fresh.isEmpty || fresh.first.guid == _posts.first.guid) return;
        if (_posts.any((p) => p.guid == fresh.first.guid)) return;
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(behavior: SnackBarBehavior.floating, content: const Text('New posts'), action: SnackBarAction(label: 'View', onPressed: _showNewPosts), duration: const Duration(seconds: 8)));
      } catch (_) {}
    });
  }

  int get _me => Scope.read(context).current.guid;

  Future<void> refresh() async {
    setState(() {
      _loading = _posts.isEmpty;
      _error = null;
    });
    try {
      final first = await EvinieApi.instance.homeFeed(_me, 1);
      if (!mounted) return;
      setState(() {
        _posts
          ..clear()
          ..addAll(first);
        _page = 1;
        _more = first.length >= 10;
      });
      EvinieApi.instance.stories(_me).then((s) {
        if (mounted) setState(() => _stories = s);
      }).catchError((_) {});
      EvinieApi.instance.notificationCount(_me).then((n) {
        if (mounted) setState(() => _unread = n);
      }).catchError((_) {});
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMore() async {
    if (_fetching || !_more) return;
    _fetching = true;
    try {
      final next = await EvinieApi.instance.homeFeed(_me, _page + 1);
      if (!mounted) return;
      final known = _posts.map((p) => p.guid).toSet();
      setState(() {
        _page++;
        _posts.addAll(next.where((p) => !known.contains(p.guid)));
        _more = next.length >= 10;
      });
    } catch (_) {
      // A failed page simply stops; pulling to refresh tries again.
    } finally {
      _fetching = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Scaffold(
      drawer: Drawer(width: MediaQuery.of(context).size.width * 0.74, backgroundColor: Colors.white, child: const SafeArea(child: MenuScreen(inDrawer: true))),
      body: RefreshIndicator(
        key: _refresher,
        color: EvColors.ember2,
        onRefresh: refresh,
        child: NotificationListener<ScrollNotification>(
          onNotification: (n) {
            if (n.metrics.pixels > n.metrics.maxScrollExtent - 600) _loadMore();
            return false;
          },
          child: CustomScrollView(controller: _scroll, slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: const Color(0xFFFFF1E7),
              leading: Builder(builder: (c) => IconButton(icon: const Icon(Icons.menu_rounded), tooltip: 'Menu', onPressed: () => Scaffold.of(c).openDrawer())),
              title: const Wordmark(size: 26),
              actions: [
                _badgeButton(Icons.search_rounded, 0, () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen()))),
                _badgeButton(Icons.chat_bubble_outline_rounded, 0, () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const InboxScreen()))),
                _badgeButton(Icons.notifications_none_rounded, _unread, () async {
                  await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen()));
                  if (mounted) setState(() => _unread = 0);
                }),
                const SizedBox(width: 8),
              ],
            ),
            SliverToBoxAdapter(child: _storiesRow(me)),
            SliverToBoxAdapter(child: _composer(me)),
            SliverToBoxAdapter(
              child: DailyPromptCard(onAnswer: (prompt) async {
                final posted = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => CreatePostScreen(initialText: '$prompt\n\n'), fullscreenDialog: true));
                if (posted == true) refresh();
              }),
            ),
            if (_loading)
              SliverList.builder(itemCount: 3, itemBuilder: (_, __) => const PostSkeleton())
            else if (_error != null && _posts.isEmpty)
              SliverFillRemaining(hasScrollBody: false, child: StateMessage(icon: Icons.wifi_off_rounded, title: "Couldn't load your feed", body: _error!, action: 'Try again', onAction: refresh))
            else if (_posts.isEmpty)
              SliverFillRemaining(hasScrollBody: false, child: StateMessage(icon: Icons.dynamic_feed_rounded, title: 'Your feed is quiet', body: 'Add friends or write your first post to get things going.', action: 'Write a post', onAction: () => _openCreate()))
            else
              SliverList.builder(
                itemCount: _posts.length + (_more ? 1 : 0),
                itemBuilder: (_, i) => i >= _posts.length
                    ? const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4)))
                    : _withExtras(i, PostCard(_posts[i], onOpen: () => openPost(context, _posts[i]), onOpenUser: (u) => openProfile(context, u))),
              ),
          ]),
        ),
      ),
    );
  }

  /// Sections between posts, like the website: birthdays after the 3rd
  /// post, an ad after the 6th, groups after the 9th, pages after the
  /// 12th, then another ad every 8 posts.
  Widget _withExtras(int i, Widget post) {
    // People you may know after the 2nd post; a sponsored ad after every
    // 4th post (picked at random by the server, newer ads more often); and
    // between them, after the 6th, 10th, 14th... post, a section cycling:
    // birthdays, reels, groups, pages, products.
    if (i == 1) return Column(children: [post, const PeopleSection()]);
    final n = i + 1;
    final Widget? extra = n % 4 == 0
        ? AdSection(key: ValueKey('ad$n'), offset: n ~/ 4)
        : (n % 4 == 2 && n > 2)
            ? switch (((n - 6) ~/ 4) % 5) {
                0 => const BirthdaysSection(),
                1 => const ReelsSection(),
                2 => const GroupsSection(),
                3 => const PagesSection(),
                _ => const ProductsSection(),
              }
            : null;
    return extra == null ? post : Column(children: [post, extra]);
  }

  Future<void> _openCreate() async {
    final posted = await Navigator.of(context).push<bool>(MaterialPageRoute(builder: (_) => const CreatePostScreen(), fullscreenDialog: true));
    if (posted == true) refresh();
  }

  Widget _badgeButton(IconData icon, int count, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(left: 6),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
            child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
              Icon(icon, size: 22),
              if (count > 0)
                Positioned(
                  top: -4,
                  right: -4,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    constraints: const BoxConstraints(minWidth: 18),
                    decoration: BoxDecoration(color: EvColors.ember2, borderRadius: BorderRadius.circular(10), border: Border.all(color: Colors.white, width: 2)),
                    child: Text(count > 99 ? '99+' : '$count', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 9.5, fontWeight: FontWeight.w700)),
                  ),
                ),
            ]),
          ),
        ),
      );

  Widget _addStoryTile(EvUser me) => GestureDetector(
        onTap: () async {
          await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const StoryUploadScreen(), fullscreenDialog: true));
          refresh();
        },
        child: Container(
          width: 110,
          decoration: BoxDecoration(color: EvColors.ink, borderRadius: BorderRadius.circular(16)),
          clipBehavior: Clip.antiAlias,
          child: Column(children: [
            Expanded(child: SizedBox(width: double.infinity, child: me.icon.isEmpty ? const ColoredBox(color: EvColors.sand2) : CachedNetworkImage(cacheManager: evCache, imageUrl: me.icon, fit: BoxFit.cover, errorWidget: (_, __, ___) => const ColoredBox(color: EvColors.sand2)))),
            const Padding(padding: EdgeInsets.symmetric(vertical: 6), child: Column(children: [CircleAvatar(radius: 11, backgroundColor: EvColors.ember2, child: Icon(Icons.add_rounded, color: Colors.white, size: 16)), SizedBox(height: 2), Text('Add story', style: TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700))])),
          ]),
        ),
      );

  Widget _storiesRow(EvUser me) {
    return SizedBox(
      height: 184,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
        itemCount: _stories.length + 1,
        separatorBuilder: (_, __) => const SizedBox(width: 9),
        itemBuilder: (_, j) {
          if (j == 0) return _addStoryTile(me);
          final i = j - 1;
          final s = _stories[i];
          return GestureDetector(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => StoryViewer(story: s, queue: _stories.skipWhile((x) => !identical(x, s)).skip(1).toList()), fullscreenDialog: true)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: SizedBox(
                width: 110,
                child: Stack(fit: StackFit.expand, children: [
                  s.covers.first.startsWith('text:') ? Container(decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFFF7A33), Color(0xFFB0127A)], begin: Alignment.topLeft, end: Alignment.bottomRight)), alignment: Alignment.center, padding: const EdgeInsets.all(8), child: Text(cleanText(s.covers.first.substring(5)), maxLines: 5, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 11.5))) : s.covers.first.isEmpty
                      // A video story with no cover picture: dark tile with a play sign.
                      ? Container(color: const Color(0xFF2A211D), alignment: Alignment.center, child: const Icon(Icons.play_circle_outline_rounded, color: Colors.white70, size: 34))
                      : CachedNetworkImage(cacheManager: evCache, imageUrl: s.covers.first, fit: BoxFit.cover, errorWidget: (_, __, ___) => Container(color: EvColors.sand2)),
                  const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.center, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black54]))),
                  Positioned(top: 6, left: 6, child: Avatar(s.user, size: 30, ring: true)),
                  Positioned(left: 8, right: 6, bottom: 7, child: Text(s.user.firstName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700))),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _composer(EvUser me) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 2, 16, 12),
        child: GestureDetector(
          onTap: _openCreate,
          child: Row(children: [
            Avatar(me, size: 38),
            const SizedBox(width: 10),
            Expanded(
              child: Container(
                height: 44,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22)),
                child: const Row(children: [
                  Expanded(child: Text("What's on your mind?", style: TextStyle(color: EvColors.muted, fontSize: 13.5))),
                  Icon(Icons.image_outlined, color: EvColors.ember2),
                ]),
              ),
            ),
          ]),
        ),
      );
}

/// A post with its comments.
class PostScreen extends StatefulWidget {
  final EvPost post;
  const PostScreen({super.key, required this.post});
  @override
  State<PostScreen> createState() => _PostScreenState();
}

class _PostScreenState extends State<PostScreen> {
  final _text = TextEditingController();
  List<EvComment>? _comments;
  String? _error;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final c = await EvinieApi.instance.comments(Scope.read(context).current.guid, widget.post.guid);
      if (mounted) setState(() => _comments = c);
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  Future<void> _send() async {
    final text = _text.text.trim();
    if (text.isEmpty || _sending) return;
    setState(() => _sending = true);
    try {
      final me = Scope.read(context).current;
      final c = await EvinieApi.instance.addComment(me.guid, widget.post.guid, text);
      _text.clear();
      if (mounted) setState(() => (_comments ??= []).add(c ?? EvComment(id: 0, text: text, time: DateTime.now(), user: me)));
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Scaffold(
      appBar: AppBar(title: const Text('Post')),
      body: Column(children: [
        Expanded(
          child: ListView(children: [
            PostCard(widget.post, showComments: false, onOpenUser: (u) => openProfile(context, u)),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Text('Comments${_comments == null ? '' : ' · ${_comments!.length}'}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
            ),
            if (_comments == null && _error == null) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))),
            if (_error != null) Padding(padding: const EdgeInsets.all(16), child: Text(_error!, style: const TextStyle(color: EvColors.red))),
            if (_comments != null && _comments!.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('No comments yet. Be the first.', style: TextStyle(color: EvColors.muted))),
            for (final c in _comments ?? <EvComment>[])
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  GestureDetector(onTap: () => openProfile(context, c.user), child: Avatar(c.user, size: 34)),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
                        decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.only(topRight: Radius.circular(16), bottomLeft: Radius.circular(16), bottomRight: Radius.circular(16), topLeft: Radius.circular(4))),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [NameLine(c.user, size: 12.5), const SizedBox(height: 2), Text(c.text, style: const TextStyle(fontSize: 13.5, height: 1.45))]),
                      ),
                      Padding(padding: const EdgeInsets.only(left: 6, top: 3), child: Text(timeAgo(c.time), style: const TextStyle(color: EvColors.muted, fontSize: 11))),
                    ]),
                  ),
                ]),
              ),
            const SizedBox(height: 12),
          ]),
        ),
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(12, 8, 12, 8 + MediaQuery.of(context).padding.bottom),
          child: Row(children: [
            Avatar(me, size: 34),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _text,
                minLines: 1,
                maxLines: 4,
                textCapitalization: TextCapitalization.sentences,
                decoration: InputDecoration(hintText: 'Write a comment…', filled: true, fillColor: EvColors.sand, contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none), enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none)),
              ),
            ),
            const SizedBox(width: 8),
            _SendButton(busy: _sending, onTap: _send),
          ]),
        ),
      ]),
    );
  }
}

class _SendButton extends StatelessWidget {
  final bool busy;
  final VoidCallback onTap;
  const _SendButton({required this.busy, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: busy ? null : onTap,
        child: Container(
          width: 42,
          height: 42,
          decoration: const BoxDecoration(shape: BoxShape.circle, gradient: EvColors.emberGradient),
          child: busy ? const Padding(padding: EdgeInsets.all(11), child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.send_rounded, color: Colors.white, size: 19),
        ),
      );
}

class CreatePostScreen extends StatefulWidget {
  final String initialText;
  final bool pickPhoto;
  const CreatePostScreen({super.key, this.initialText = '', this.pickPhoto = false});
  @override
  State<CreatePostScreen> createState() => _CreatePostScreenState();
}

class _CreatePostScreenState extends State<CreatePostScreen> {
  String _bg = '', _location = '';
  bool _showBgs = false, _showEmoji = false;
  List<Map> _mentions = [];
  Timer? _mentionTimer;

  String _bgUrl(String name) => '${AppConfig.siteUrl}/components/OssnPostBackground/images/${name.replaceFirst('pbg', '')}.jpg';

  void _insert(String t) {
    final sel = _text.selection;
    final pos = sel.isValid ? sel.start : _text.text.length;
    _text.text = _text.text.replaceRange(pos, sel.isValid ? sel.end : pos, t);
    _text.selection = TextSelection.collapsed(offset: pos + t.length);
  }

  /// "@na" while typing: suggest people; tapping inserts @username.
  String _beforeCursor() {
    final v = _text.text;
    final pos = _text.selection.isValid ? _text.selection.start : v.length;
    return v.substring(0, pos.clamp(0, v.length));
  }

  void _onType(String v) {
    final q = mentionQuery(_beforeCursor());
    _mentionTimer?.cancel();
    if (q == null) {
      if (_mentions.isNotEmpty) setState(() => _mentions = []);
      return;
    }
    List<Map> asMaps(List<EvUser> l) => [for (final u in l) {'guid': u.guid, 'fullname': u.fullname, 'username': u.username, 'icon': u.icon}];
    final me = Scope.read(context).current.guid;
    // Friends at once, then other members after a short pause in typing.
    setState(() => _mentions = asMaps(mentionLocal(me, q)));
    _mentionTimer = Timer(const Duration(milliseconds: 250), () async {
      try {
        final found = await mentionMatches(me, q);
        if (mounted && mentionQuery(_beforeCursor()) == q) setState(() => _mentions = asMaps(found));
      } catch (_) {}
    });
  }

  void _insertMention(String username) {
    final v = _text.text;
    final pos = _text.selection.isValid ? _text.selection.start : v.length;
    final start = v.substring(0, pos).lastIndexOf('@');
    if (start < 0) return;
    _text.text = v.replaceRange(start, pos, '@$username ');
    _text.selection = TextSelection.collapsed(offset: start + username.length + 2);
    setState(() => _mentions = []);
  }

  Future<void> _askLocation() async {
    final c = TextEditingController(text: _location);
    final r = await showDialog<String>(context: context, builder: (d) => AlertDialog(title: const Text('Add location'), content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(hintText: 'e.g. Lagos, Nigeria')), actions: [TextButton(onPressed: () => Navigator.pop(d), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(d, c.text.trim()), child: const Text('Add'))]));
    c.dispose();
    if (r != null && mounted) setState(() => _location = r);
  }

  late final _text = TextEditingController(text: widget.initialText);
  File? _photo;
  // Starts at your default audience (Settings → Privacy).
  int _privacy = defaultPostAudience();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    if (widget.pickPhoto) WidgetsBinding.instance.addPostFrameCallback((_) => _pick(ImageSource.gallery));
  }

  @override
  void dispose() {
    _mentionTimer?.cancel();
    _text.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource source) async {
    final x = await ImagePicker().pickImage(source: source, maxWidth: 2000, imageQuality: 85);
    if (x != null && mounted) setState(() => _photo = File(x.path));
  }

  Future<void> _post() async {
    if (_text.text.trim().isEmpty && _photo == null) return showMessage(context, 'Write something or add a photo.');
    setState(() => _busy = true);
    try {
      await EvinieApi.instance.createPost(Scope.read(context).current.guid, _text.text.trim(), photo: _photo, privacy: _privacy, background: _photo == null ? _bg : '', location: _location);
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Scaffold(
      appBar: AppBar(
        title: const Text('New post'),
        actions: [
          PopupMenuButton<int>(
            initialValue: _privacy,
            onSelected: (v) => setState(() => _privacy = v),
            itemBuilder: (_) => const [PopupMenuItem(value: 2, child: Text('Everyone')), PopupMenuItem(value: 3, child: Text('Friends'))],
            child: Container(
              margin: const EdgeInsets.only(right: 14),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: EvColors.line)),
              child: Row(children: [Icon(_privacy == 2 ? Icons.public_rounded : Icons.people_outline_rounded, size: 16), const SizedBox(width: 5), Text(_privacy == 2 ? 'Everyone' : 'Friends', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600))]),
            ),
          ),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [Avatar(me, size: 44), const SizedBox(width: 10), Expanded(child: NameLine(me, size: 14.5))]),
            if (_location.isNotEmpty)
              Padding(padding: const EdgeInsets.only(top: 8), child: Row(children: [const Icon(Icons.place_rounded, size: 16, color: EvColors.red), const SizedBox(width: 4), Expanded(child: Text('at $_location', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600))), GestureDetector(onTap: () => setState(() => _location = ''), child: const Icon(Icons.close_rounded, size: 16, color: EvColors.muted))])),
            Container(
              margin: const EdgeInsets.only(top: 8),
              padding: _bg.isEmpty || _photo != null ? EdgeInsets.zero : const EdgeInsets.all(18),
              constraints: BoxConstraints(minHeight: _bg.isEmpty || _photo != null ? 0 : 200),
              alignment: Alignment.center,
              decoration: _bg.isEmpty || _photo != null ? null : BoxDecoration(borderRadius: BorderRadius.circular(18), image: DecorationImage(image: CachedNetworkImageProvider(_bgUrl(_bg), cacheManager: evCache), fit: BoxFit.cover)),
              child: TextField(
              controller: _text,
              onChanged: _onType,
              autofocus: true,
              maxLines: null,
              minLines: 4,
              textAlign: _bg.isEmpty || _photo != null ? TextAlign.start : TextAlign.center,
              textCapitalization: TextCapitalization.sentences,
              style: TextStyle(fontSize: _bg.isEmpty || _photo != null ? 16 : 21, color: _bg.isEmpty || _photo != null ? EvColors.ink : Colors.white, fontWeight: _bg.isEmpty || _photo != null ? FontWeight.w400 : FontWeight.w700),
              decoration: InputDecoration(hintText: "What's on your mind, ${me.firstName}?", filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, hintStyle: const TextStyle(fontSize: 17, color: EvColors.muted)),
            ),
            ),
            if (_mentions.isNotEmpty)
              Container(
                margin: const EdgeInsets.only(top: 6),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: EvColors.line)),
                child: Column(children: [
                  for (final u in _mentions)
                    ListTile(dense: true, leading: Avatar(EvUser.fromJson(u), size: 30), title: Text(EvUser.fromJson(u).fullname), subtitle: Text('@${str(u, 'username')}'), onTap: () => _insertMention(str(u, 'username'))),
                ]),
              ),
            if (_photo != null)
              Stack(children: [
                ClipRRect(borderRadius: BorderRadius.circular(18), child: Image.file(_photo!, fit: BoxFit.cover, width: double.infinity)),
                Positioned(top: 8, right: 8, child: GestureDetector(onTap: () => setState(() => _photo = null), child: const CircleAvatar(radius: 15, backgroundColor: Colors.black54, child: Icon(Icons.close_rounded, color: Colors.white, size: 17)))),
              ]),
          ]),
        ),
        Container(
          color: Colors.white,
          padding: EdgeInsets.fromLTRB(16, 10, 16, 10 + MediaQuery.of(context).padding.bottom),
          child: Column(children: [
            if (_showBgs)
              SizedBox(
                height: 46,
                child: ListView(scrollDirection: Axis.horizontal, children: [
                  GestureDetector(onTap: () => setState(() => _bg = ''), child: Container(width: 40, margin: const EdgeInsets.only(right: 6), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: _bg.isEmpty ? EvColors.ember2 : EvColors.line, width: 2)), child: const Icon(Icons.block_rounded, size: 18, color: EvColors.muted))),
                  for (var i = 1; i <= 13; i++)
                    GestureDetector(
                      onTap: () => setState(() => _bg = 'pbg$i'),
                      child: Container(width: 40, margin: const EdgeInsets.only(right: 6), decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: _bg == 'pbg$i' ? EvColors.ember2 : Colors.transparent, width: 2), image: DecorationImage(image: CachedNetworkImageProvider(_bgUrl('pbg$i'), cacheManager: evCache), fit: BoxFit.cover))),
                    ),
                ]),
              ),
            if (_showEmoji)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Wrap(spacing: 4, children: [for (final e in const ['😀', '😂', '😍', '🥰', '😎', '🙏', '👍', '🔥', '🎉', '❤️', '😢', '😮', '👏', '💯', '🤝', '🎂']) GestureDetector(onTap: () => _insert(e), child: Padding(padding: const EdgeInsets.all(4), child: Text(e, style: const TextStyle(fontSize: 22))))]),
              ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              _tool(Icons.photo_library_outlined, 'Photo', EvColors.green, () => _pick(ImageSource.gallery)),
              _tool(Icons.photo_camera_outlined, 'Camera', EvColors.blue, () => _pick(ImageSource.camera)),
              _tool(Icons.palette_outlined, 'Background', EvColors.ember2, () => setState(() => _showBgs = !_showBgs)),
              _tool(Icons.emoji_emotions_outlined, 'Emoji', EvColors.gold, () => setState(() => _showEmoji = !_showEmoji)),
              _tool(Icons.place_outlined, 'Location', EvColors.red, _askLocation),
            ]),
            const SizedBox(height: 10),
            EmberButton('Post', loading: _busy, onPressed: _post),
          ]),
        ),
      ]),
    );
  }

  Widget _tool(IconData icon, String label, Color c, VoidCallback onTap) => Tooltip(
        message: label,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Container(width: 50, height: 44, decoration: BoxDecoration(color: c.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: c, size: 22)),
        ),
      );
}

/// Full-screen story with tap-to-advance and a progress bar per item.
class StoryViewer extends StatefulWidget {
  final EvStory story;
  /// The people whose stories play next.
  final List<EvStory> queue;
  const StoryViewer({super.key, required this.story, this.queue = const []});
  @override
  State<StoryViewer> createState() => _StoryViewerState();
}

class _StoryViewerState extends State<StoryViewer> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 10), animationBehavior: AnimationBehavior.preserve)
    ..addStatusListener((s) {
      if (s == AnimationStatus.completed) _next();
    });
  int _i = 0;
  int _startedFor = -1;


  /// The timer starts only once the story is actually on screen (picture
  /// loaded, or video ready), so slow connections don't eat the time.
  void _start({Duration? length}) {
    if (_startedFor == _i) return;
    _startedFor = _i;
    _c.duration = length ?? const Duration(seconds: 10);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _c.forward(from: 0);
    });
  }

  void _reset() {
    _c.stop();
    _c.value = 0;
    _startedFor = -1;
  }

  void _next() {
    if (_i < widget.story.items.length - 1) {
      _reset();
      setState(() => _i++);
    } else {
      if (widget.queue.isNotEmpty) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => StoryViewer(story: widget.queue.first, queue: widget.queue.sublist(1)), fullscreenDialog: true));
      } else {
        Navigator.of(context).pop();
      }
    }
  }

  void _prev() {
    _reset();
    setState(() {
      if (_i > 0) _i--;
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        body: GestureDetector(
          onTapUp: (d) => d.globalPosition.dx < MediaQuery.of(context).size.width / 3 ? _prev() : _next(),
          onLongPressStart: (_) => _c.stop(),
          onLongPressEnd: (_) {
            if (_startedFor == _i) _c.forward();
          },
          child: Stack(fit: StackFit.expand, children: [
            if (widget.story.items[_i].startsWith('text:'))
              Builder(builder: (_) {
                _start();
                return Container(
                  decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFFF7A33), Color(0xFFB0127A)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
                  alignment: Alignment.center,
                  padding: const EdgeInsets.all(28),
                  child: Text(cleanText(widget.story.items[_i].substring(5)), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800, height: 1.35)),
                );
              })
            else if (widget.story.isVideoAt(_i))
              _StoryVideo(key: ValueKey(widget.story.items[_i]), url: widget.story.items[_i], onReady: (d) => _start(length: d))
            else
              CachedNetworkImage(
                cacheManager: evCache,
                imageUrl: widget.story.items[_i],
                fit: BoxFit.cover,
                placeholder: (_, __) => const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4)),
                imageBuilder: (_, img) {
                  _start();
                  return Image(image: img, fit: BoxFit.cover);
                },
                errorWidget: (_, __, ___) {
                  _start();
                  return const Center(child: Icon(Icons.broken_image_outlined, color: Colors.white54, size: 48));
                },
              ),
            const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.center, colors: [Colors.black54, Colors.transparent]))),
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Column(children: [
                  AnimatedBuilder(
                    animation: _c,
                    builder: (_, __) => Row(children: [
                      for (var k = 0; k < widget.story.items.length; k++)
                        Expanded(
                          child: Container(
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            height: 3,
                            decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(3)),
                            alignment: Alignment.centerLeft,
                            child: FractionallySizedBox(widthFactor: k < _i ? 1 : (k == _i ? _c.value : 0), child: Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(3)))),
                          ),
                        ),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    Avatar(widget.story.user, size: 34),
                    const SizedBox(width: 8),
                    Expanded(child: Text(widget.story.user.fullname, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700))),
                    IconButton(icon: const Icon(Icons.close_rounded, color: Colors.white), onPressed: () => Navigator.of(context).pop()),
                  ]),
                ]),
              ),
            ),
          ]),
        ),
      );
}


/// A video story: plays once; reports its real length so the timer matches.
class _StoryVideo extends StatefulWidget {
  final String url;
  final void Function(Duration length) onReady;
  const _StoryVideo({super.key, required this.url, required this.onReady});
  @override
  State<_StoryVideo> createState() => _StoryVideoState();
}

class _StoryVideoState extends State<_StoryVideo> {
  late final VideoPlayerController _v = VideoPlayerController.networkUrl(Uri.parse(widget.url));
  bool _holding = true;
  void _release() {
    if (_holding) {
      _holding = false;
      releaseDownloads();
    }
  }

  @override
  void initState() {
    super.initState();
    // Background downloads wait while this story video loads.
    holdDownloads();
    _v.initialize().then((_) {
      _release();
      if (!mounted) return;
      setState(() {});
      _v.play();
      final d = _v.value.duration;
      widget.onReady(d.inMilliseconds > 500 ? d : const Duration(seconds: 10));
    }).catchError((_) {
      _release();
      widget.onReady(const Duration(seconds: 10));
    });
  }

  @override
  void dispose() {
    _release();
    _v.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => _v.value.isInitialized
      ? Center(child: AspectRatio(aspectRatio: _v.value.aspectRatio, child: VideoPlayer(_v)))
      : const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.4));
}
