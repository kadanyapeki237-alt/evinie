import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../api/api_client.dart';
import '../api/more_api.dart';
import '../models/models.dart';
import '../state/session.dart';
import '../state/cache.dart';
import '../theme/colors.dart';
import '../widgets/common.dart';
import 'money_screens.dart';
import 'auth_screens.dart' show passwordProblem, showForgotPassword;

final _api = ApiClient.instance;

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});
  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _first = TextEditingController(), _last = TextEditingController(), _email = TextEditingController(), _current = TextEditingController(), _new = TextEditingController();
  final _phone = TextEditingController();
  String _username = '', _savedPhone = '';
  String _gender = 'male';
  bool _busy = false, _loaded = false;

  @override
  void initState() {
    super.initState();
    final me = Scope.read(context).current;
    _api.post('user_details', {'guid': me.guid}).then((p) {
      final u = mapOf(mapOf(p)['user'] is Map ? mapOf(p)['user'] : p);
      if (!mounted) return;
      setState(() {
        _first.text = str(u, 'first_name');
        _last.text = str(u, 'last_name');
        _email.text = str(u, 'email');
        _gender = str(u, 'gender', 'male');
        _username = str(u, 'username', me.username);
        _loaded = true;
      });
    }).catchError((_) {
      if (mounted) setState(() => _loaded = true);
    });
    _api.post('user/phone').then((p) {
      if (!mounted) return;
      setState(() {
        _savedPhone = _phone.text = str(mapOf(p), 'phone');
        if (_username.isEmpty) _username = str(mapOf(p), 'username');
      });
    }).catchError((_) {});
  }

  @override
  void dispose() {
    for (final c in [_first, _last, _email, _current, _new, _phone]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _photo() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, maxWidth: 1200, imageQuality: 85);
    if (x == null) return;
    setState(() => _busy = true);
    try {
      await _api.upload('photos_profile_add', {'guid': Scope.read(context).current.guid}, 'userphoto', File(x.path));
      if (mounted) showMessage(context, 'Profile photo updated.');
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    final phoneChanged = _phone.text.trim() != _savedPhone;
    final rest = _first.text.trim().isNotEmpty || _new.text.isNotEmpty;
    // A phone-only change doesn't need the password.
    if (_current.text.isEmpty && !phoneChanged) return showMessage(context, 'Enter your current password to save changes.');
    if (_new.text.isNotEmpty && passwordProblem(_new.text) != null) return showMessage(context, 'New password: ${passwordProblem(_new.text)}');
    setState(() => _busy = true);
    try {
      if (phoneChanged) {
        final r = mapOf(await _api.post('user/phone', {'phone': _phone.text.trim()}));
        _savedPhone = _phone.text = str(r, 'phone');
      }
      if (_current.text.isEmpty) {
        if (mounted) showMessage(context, 'Phone number saved.');
        return;
      }
      if (!rest) return;
      await _api.post('user_edit', {
        'guid': Scope.read(context).current.guid,
        'new_first_name': _first.text.trim(),
        'new_last_name': _last.text.trim(),
        'new_email': _email.text.trim(),
        'new_gender': _gender,
        'current_password': _current.text,
        if (_new.text.isNotEmpty) 'new_password': _new.text,
      });
      if (mounted) {
        showMessage(context, 'Saved.');
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) showMessage(context, '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final me = Scope.of(context).current;
    return Scaffold(
      appBar: AppBar(title: const Text('Edit profile')),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
          : ListView(padding: const EdgeInsets.all(16), children: [
              Row(children: [Avatar(me, size: 64), const SizedBox(width: 12), TextButton.icon(onPressed: _busy ? null : _photo, icon: const Icon(Icons.photo_camera_outlined), label: const Text('Change photo'))]),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: TextField(controller: _first, decoration: const InputDecoration(hintText: 'First name'))), const SizedBox(width: 8), Expanded(child: TextField(controller: _last, decoration: const InputDecoration(hintText: 'Last name')))]),
              const SizedBox(height: 10),
              TextFormField(
                key: ValueKey('username:$_username'),
                initialValue: _username.isEmpty ? me.username : _username,
                readOnly: true,
                enabled: false,
                decoration: const InputDecoration(hintText: 'Username', prefixIcon: Icon(Icons.alternate_email_rounded), helperText: "Your username can't be changed."),
              ),
              const SizedBox(height: 10),
              TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(hintText: 'Email', prefixIcon: Icon(Icons.mail_outline_rounded))),
              const SizedBox(height: 10),
              TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: 'Phone number, e.g. 08031234567', prefixIcon: Icon(Icons.phone_outlined), helperText: 'You can also sign in with this number.')),
              const SizedBox(height: 10),
              SegmentedButton<String>(segments: const [ButtonSegment(value: 'male', label: Text('Male')), ButtonSegment(value: 'female', label: Text('Female'))], selected: {_gender}, onSelectionChanged: (v) => setState(() => _gender = v.first)),
              const SizedBox(height: 18),
              const Text('Password', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              TextField(controller: _current, obscureText: true, decoration: const InputDecoration(hintText: 'Current password (required to save)', prefixIcon: Icon(Icons.lock_outline_rounded))),
              const SizedBox(height: 10),
              TextField(controller: _new, obscureText: true, decoration: const InputDecoration(hintText: 'New password (optional)', prefixIcon: Icon(Icons.lock_reset_rounded), helperText: '8+ characters with a capital letter, a lower case letter and a number')),
              Align(alignment: Alignment.centerLeft, child: TextButton(onPressed: () => showForgotPassword(context, prefill: _email.text.trim()), child: const Text("Forgot your current password? Reset it by email", style: TextStyle(color: EvColors.ember2)))),
              const SizedBox(height: 12),
              EmberButton('Save changes', loading: _busy, onPressed: _save),
            ]),
    );
  }
}

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({super.key});
  @override
  State<NotificationSettingsScreen> createState() => _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState extends State<NotificationSettingsScreen> {
  bool? _muted;
  @override
  void initState() {
    super.initState();
    _api.post('notificationmute/status').then((p) {
      if (mounted) setState(() => _muted = asBool(mapOf(p)['muted']));
    }).catchError((e) {
      if (mounted) showMessage(context, '$e');
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Notifications')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          EvCard(
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              activeColor: EvColors.ember2,
              title: const Text('Notifications', style: TextStyle(fontWeight: FontWeight.w600)),
              subtitle: const Text('Likes, comments, messages, friend requests and gifts', style: TextStyle(fontSize: 12)),
              value: _muted == null ? true : !_muted!,
              onChanged: _muted == null
                  ? null
                  : (on) async {
                      final before = _muted;
                      setState(() => _muted = !on);
                      try {
                        await _api.post('notificationmute/set', {'muted': on ? 0 : 1});
                      } catch (e) {
                        if (mounted) {
                          setState(() => _muted = before);
                          showMessage(context, '$e');
                        }
                      }
                    },
            ),
          ),
          const Padding(padding: EdgeInsets.all(8), child: Text('When off, you will not be notified about activity. You can still see everything in the app.', style: TextStyle(color: EvColors.muted, fontSize: 12))),
        ]),
      );
}

class BlockedScreen extends StatefulWidget {
  const BlockedScreen({super.key});
  @override
  State<BlockedScreen> createState() => _BlockedScreenState();
}

class _BlockedScreenState extends State<BlockedScreen> {
  List<Map>? _list;
  String? _error;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await _api.post('block/list');
      if (mounted) setState(() => _list = listOf(mapOf(p)['list']));
    } catch (e) {
      if (mounted) setState(() => _error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Blocked accounts')),
        body: _error != null
            ? StateMessage(icon: Icons.block_rounded, title: 'Not available', body: _error!)
            : _list == null
                ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
                : _list!.isEmpty
                    ? const StateMessage(icon: Icons.block_rounded, title: 'No one is blocked', body: "Blocked people can't see your profile or message you.")
                    : ListView(padding: const EdgeInsets.all(16), children: [
                        const Text("Blocked accounts can't find your profile, see your posts or message you. They aren't told you blocked them.", style: TextStyle(color: EvColors.muted, fontSize: 12.5, height: 1.45)),
                        const SizedBox(height: 10),
                        for (final m in _list!)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: EvCard(
                              padding: EdgeInsets.zero,
                              child: ListTile(
                                leading: Avatar(EvUser.fromJson(m), size: 42),
                                title: Text(EvUser.fromJson(m).fullname),
                                subtitle: Text('@${str(m, 'username')}', style: const TextStyle(fontSize: 12)),
                                trailing: TextButton(
                                  onPressed: () async {
                                    try {
                                      await _api.post('block/remove', {'user': asInt(m['guid'])});
                                      _load();
                                    } catch (e) {
                                      if (mounted) showMessage(this.context, '$e');
                                    }
                                  },
                                  child: const Text('Unblock'),
                                ),
                              ),
                            ),
                          ),
                      ]),
      );
}

/// Block someone from their profile.
Future<void> blockUser(BuildContext context, EvUser user) async {
  final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(title: Text('Block ${user.firstName}?'), content: const Text("They won't be able to see your profile or message you. They won't be told."), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Block', style: TextStyle(color: EvColors.red)))]));
  if (ok != true) return;
  try {
    await _api.post('block/add', {'user': user.guid});
    if (context.mounted) showMessage(context, '${user.firstName} is blocked.');
  } catch (e) {
    if (context.mounted) showMessage(context, '$e');
  }
}

class TiersScreen extends StatefulWidget {
  const TiersScreen({super.key});
  @override
  State<TiersScreen> createState() => _TiersScreenState();
}

class _TiersScreenState extends State<TiersScreen> {
  List<Map>? _tiers;
  @override
  void initState() {
    super.initState();
    _api.post('membershiptier/list').then((p) {
      if (mounted) setState(() => _tiers = listOf(mapOf(p)['tiers']));
    }).catchError((_) {
      if (mounted) setState(() => _tiers = []);
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Membership plans')),
        body: _tiers == null
            ? const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4))
            : ListView(padding: const EdgeInsets.all(16), children: [
                for (final t in _tiers!)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: EvCard(
                      child: Row(children: [
                        Tile(asBool(t['monetization_enabled']) ? Icons.workspace_premium_rounded : Icons.favorite_rounded, asBool(t['monetization_enabled']) ? EvColors.ember2 : EvColors.muted),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(str(t, 'title'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)), Text(asBool(t['monetization_enabled']) ? 'Earn from your activity, sell, and cash out' : 'Post, comment, join groups and events', style: const TextStyle(color: EvColors.muted, fontSize: 12))])),
                      ]),
                    ),
                  ),
                const SizedBox(height: 6),
                OutlineEmberButton('See prices and upgrade', onPressed: () => startEviEarnerUpgrade(context)),
              ]),
      );
}

/// iHealth Assist: partner hospitals and pharmacies.
class PartnersScreen extends StatefulWidget {
  const PartnersScreen({super.key});
  @override
  State<PartnersScreen> createState() => _PartnersScreenState();
}

class _PartnersScreenState extends State<PartnersScreen> {
  String _kind = '';
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Hospitals & pharmacies')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: SegmentedButton<String>(segments: const [ButtonSegment(value: '', label: Text('All')), ButtonSegment(value: 'hospital', label: Text('Hospitals')), ButtonSegment(value: 'pharmacy', label: Text('Pharmacies'))], selected: {_kind}, onSelectionChanged: (v) => setState(() => _kind = v.first)),
          ),
          Container(margin: const EdgeInsets.symmetric(horizontal: 12), padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: EvColors.redBg, borderRadius: BorderRadius.circular(12)), child: const Text('In an emergency, call 112 or go to the nearest hospital, partner or not.', style: TextStyle(fontSize: 12.5))),
          Expanded(
            child: FutureBuilder<Map>(
              key: ValueKey(_kind),
              future: MoreApi.instance.partners(kind: _kind),
              builder: (_, snap) {
                if (snap.hasError) return StateMessage(icon: Icons.local_hospital_outlined, title: 'Not available', body: '${snap.error}');
                if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: EvColors.ember2, strokeWidth: 2.4));
                final list = listOf(snap.data!['list']);
                if (list.isEmpty) return const StateMessage(icon: Icons.local_hospital_outlined, title: 'No partners yet', body: 'Partner hospitals and pharmacies will be listed here.');
                return ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) {
                    final p = list[i];
                    final pharmacy = str(p, 'kind', str(p, 'type')).startsWith('ph');
                    return EvCard(
                      child: Row(children: [
                        Tile(pharmacy ? Icons.medication_outlined : Icons.local_hospital_outlined, pharmacy ? EvColors.green : EvColors.red),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(str(p, 'name', str(p, 'title')), style: const TextStyle(fontWeight: FontWeight.w700)), Text([str(p, 'city'), str(p, 'address')].where((s) => s.isNotEmpty).join(' · '), style: const TextStyle(color: EvColors.muted, fontSize: 12)), const Text('Evinie Partner', style: TextStyle(color: EvColors.ember2, fontSize: 11, fontWeight: FontWeight.w700))])),
                      ]),
                    );
                  },
                );
              },
            ),
          ),
        ]),
      );
}

/// From a completed consultation: send the prescription to a partner pharmacy.
Future<void> sendPrescription(BuildContext context, int booking) async {
  List<Map> pharmacies = [];
  try {
    pharmacies = listOf((await MoreApi.instance.partners(kind: 'pharmacy'))['list']);
  } catch (_) {}
  if (!context.mounted) return;
  if (pharmacies.isEmpty) return showMessage(context, 'No partner pharmacies yet.');
  int pharmacy = asInt(pharmacies.first['guid']);
  String method = 'pickup';
  final phone = TextEditingController(), address = TextEditingController();
  final ok = await showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.white,
    builder: (s) => StatefulBuilder(
      builder: (s, set) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(s).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Send to a pharmacy', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          for (final p in pharmacies) RadioListTile<int>(value: asInt(p['guid']), groupValue: pharmacy, onChanged: (v) => set(() => pharmacy = v ?? pharmacy), title: Text(str(p, 'name', str(p, 'title'))), subtitle: Text(str(p, 'city'))),
          SegmentedButton<String>(segments: const [ButtonSegment(value: 'pickup', label: Text('Pickup')), ButtonSegment(value: 'delivery', label: Text('Delivery'))], selected: {method}, onSelectionChanged: (v) => set(() => method = v.first)),
          const SizedBox(height: 8),
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: 'Phone number')),
          if (method == 'delivery') ...[const SizedBox(height: 8), TextField(controller: address, decoration: const InputDecoration(hintText: 'Delivery address'))],
          const SizedBox(height: 12),
          EmberButton('Send prescription', onPressed: () => Navigator.pop(s, true)),
          const SizedBox(height: 6),
          const Text('The pharmacy replies with the price and availability. You pay the pharmacy directly.', style: TextStyle(color: EvColors.muted, fontSize: 12)),
        ]),
      ),
    ),
  );
  if (ok != true) return;
  try {
    await _api.post('ihealth/sendprescription', {'booking': booking, 'pharmacy': pharmacy, 'method': method, 'phone': phone.text.trim(), 'address': address.text.trim()});
    if (context.mounted) showMessage(context, 'Sent. The pharmacy will reply with a price.');
  } catch (e) {
    if (context.mounted) showMessage(context, '$e');
  } finally {
    phone.dispose();
    address.dispose();
  }
}

/// Who sees new posts by default: 2 = everyone, 3 = friends only.
int defaultPostAudience() {
  final v = LocalCache.get('pref:post_audience');
  return asInt(v?.$1) == 3 ? 3 : 2;
}

/// Settings → Privacy: who can see your posts, and what else controls who
/// reaches you.
class PrivacyScreen extends StatefulWidget {
  const PrivacyScreen({super.key});
  @override
  State<PrivacyScreen> createState() => _PrivacyScreenState();
}

class _PrivacyScreenState extends State<PrivacyScreen> {
  int _audience = defaultPostAudience();

  Future<void> _set(int v) async {
    setState(() => _audience = v);
    await LocalCache.put('pref:post_audience', v);
    if (mounted) showMessage(context, v == 3 ? 'New posts will be for friends only.' : 'New posts will be for everyone.');
  }

  @override
  Widget build(BuildContext context) {
    Widget option(int v, IconData icon, String title, String sub) => ListTile(
          onTap: () => _set(v),
          leading: Icon(icon, color: _audience == v ? EvColors.ember2 : EvColors.muted),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(sub, style: const TextStyle(fontSize: 12)),
          trailing: Icon(_audience == v ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: _audience == v ? EvColors.ember2 : EvColors.muted),
        );
    Widget info(IconData icon, String title, String body) => ListTile(leading: Icon(icon, color: EvColors.blue), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)), subtitle: Text(body, style: const TextStyle(fontSize: 12, height: 1.4)));
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('WHO CAN SEE YOUR NEW POSTS', style: TextStyle(color: EvColors.muted, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        EvCard(padding: EdgeInsets.zero, child: Column(children: [
          option(2, Icons.public_rounded, 'Everyone', 'Anyone on Evinie can see them'),
          option(3, Icons.people_outline_rounded, 'Friends only', 'Only your friends can see them'),
        ])),
        const Padding(padding: EdgeInsets.fromLTRB(4, 8, 4, 0), child: Text('This is the starting choice when you write a post; you can still change it on each post before sharing.', style: TextStyle(color: EvColors.muted, fontSize: 12))),
        const SizedBox(height: 20),
        const Text('MORE CONTROLS', style: TextStyle(color: EvColors.muted, fontSize: 12, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        EvCard(padding: EdgeInsets.zero, child: Column(children: [
          ListTile(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BlockedScreen())),
            leading: const Icon(Icons.block_rounded, color: EvColors.red),
            title: const Text('Blocked accounts', style: TextStyle(fontWeight: FontWeight.w600)),
            subtitle: const Text("Blocked people can't see your profile or message you. To block someone, open their profile and tap ⋯ next to Message.", style: TextStyle(fontSize: 12, height: 1.4)),
            trailing: const Icon(Icons.chevron_right_rounded),
          ),
          info(Icons.cake_outlined, 'Birthday', 'Only you see your birthday on your profile.'),
          info(Icons.phone_outlined, 'Phone number', 'Used for signing in. It is not shown on your profile.'),
        ])),
      ]),
    );
  }
}
