/// Build-time settings. Nothing secret is written in the code:
///
///   flutter run --dart-define=EVINIE_URL=https://evinie.com \
///               --dart-define=EVINIE_API_KEY=your-api-key
class AppConfig {
  static const String siteUrl =
      String.fromEnvironment('EVINIE_URL', defaultValue: 'https://evinie.com');
  static const String apiKey = String.fromEnvironment('EVINIE_API_KEY');
  /// Empty = detect automatically (v6.0, v2.0, v1.0). To force one:
  ///   --dart-define=EVINIE_API_VERSION=v1.0
  static const String apiVersion = String.fromEnvironment('EVINIE_API_VERSION');
  /// GIPHY key for the GIF picker in comments.
  static const String giphyKey = String.fromEnvironment('EVINIE_GIPHY_KEY', defaultValue: '4drApYDmIwppGqGeX4Twahs8aHcWQ4LF');

  static const List<String> apiVersions = ['v6.0', 'v2.0', 'v1.0'];

  static bool get isConfigured => apiKey.isNotEmpty;

  /// Store-safe build: hides buying or sending DIGITAL items (top-ups,
  /// Get verified, EviEarner, sending eGifts), which the App Store and
  /// Google Play require to go through their own in-app purchases.
  /// Balances, history, received gifts, points and cash-out still work.
  ///   --dart-define=EVINIE_STORE_SAFE=true
  static const bool storeSafe = bool.fromEnvironment('EVINIE_STORE_SAFE');
}
