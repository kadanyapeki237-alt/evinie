import 'package:flutter_test/flutter_test.dart';
import 'package:evinie_app/screens/business_screens.dart';

void main() {
  test('server keys become readable labels', () {
    expect(humanize('paid_this_month'), 'Paid this month');
    expect(humanize('verified-businesses'), 'Verified businesses');
  });

  test('money figures show in naira, counts stay plain', () {
    expect(figure('unpaid', 184000), '₦184,000');
    expect(figure('profit_this_month', '96300'), '₦96,300');
    expect(figure('new_users', 62), '62');
  });
}
