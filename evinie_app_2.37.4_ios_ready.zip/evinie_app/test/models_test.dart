import 'package:flutter_test/flutter_test.dart';
import 'package:evinie_app/models/models.dart';

// Shapes copied from the EndPoints API documentation.
void main() {
  test('feed post from wall_list_home', () {
    final p = EvPost.fromJson({
      'post': {'guid': '110', 'time_created': '1569189230', 'description': '{"post":"OK"}', 'poster_guid': '1', 'total_likes': 1, 'is_liked_by_user': true},
      'text': 'OK',
      'location': '',
      'user': {'guid': '1', 'first_name': 'System', 'last_name': 'Administrator'},
      'image': '',
    });
    expect(p.guid, 110);
    expect(p.text, 'OK');
    expect(p.likes, 1);
    expect(p.liked, isTrue);
    expect(p.poster.fullname, 'System Administrator');
  });

  test('post text falls back to the description JSON', () {
    final p = EvPost.fromJson({'post': {'guid': 5, 'description': '{"post":"Hello"}'}, 'user': {}});
    expect(p.text, 'Hello');
  });

  test('comment from comments_list', () {
    final c = EvComment.fromJson({'id': 10, 'time_created': 1601773807, 'type': 'comments:post', 'comments:post': 'ABC', 'user': {'guid': 2, 'first_name': 'Leonard'}, 'total_likes': 0});
    expect(c.text, 'ABC');
    expect(c.user.guid, 2);
  });

  test('message with icon as a map of sizes', () {
    final m = EvMessage.fromJson({'id': '7', 'message_from': {'guid': '1', 'fullname': 'A B', 'icon': {'small': 'https://x/s.jpg'}}, 'message_to': {'guid': '2', 'fullname': 'C D'}, 'message': 'Hi', 'viewed': '0', 'time': '1600000000'});
    expect(m.from.icon, 'https://x/s.jpg');
    expect(m.viewed, isFalse);
  });

  test('notification wording', () {
    final n = EvNotification.fromJson({'notification': {'guid': 1, 'type': 'like:post', 'viewed': null, 'time_created': 1}, 'poster': {'guid': 3, 'fullname': 'Nusrat Jahan'}});
    expect(n.action, 'liked your post');
    expect(n.viewed, isFalse);
  });

  test('HTML codes from the server become real characters', () {
    expect(decodeHtml('&#x1f4f8; Welcome &amp; enjoy'), '📸 Welcome & enjoy');
    expect(decodeHtml('It&#039;s &#127881;'), "It's 🎉");
    expect(asStr('plain text'), 'plain text');
  });
}
