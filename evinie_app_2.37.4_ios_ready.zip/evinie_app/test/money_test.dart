import 'package:flutter_test/flutter_test.dart';
import 'package:evinie_app/models/money.dart';

void main() {
  test('naira formatting', () {
    expect(naira(184500), '₦184,500');
    expect(naira(1000), '₦1,000');
    expect(naira(99.5), '₦99.50');
    expect(naira(-4500), '−₦4,500');
    expect(naira(0), '₦0');
  });

  test('wallet rows: credit or debit', () {
    expect(WalletEntry.fromJson({'amount': '5000', 'type': 'credit', 'description': 'Wallet top-up'}).credit, isTrue);
    expect(WalletEntry.fromJson({'amount': 4500, 'type': 'debit', 'description': 'Purchase'}).credit, isFalse);
    expect(WalletEntry.fromJson({'amount': -1000, 'description': 'eGift'}).credit, isFalse);
    expect(WalletEntry.fromJson({'amount': -1000}).amount, 1000);
  });

  test('verification plans come from the server', () {
    final s = VerifyStatus.fromJson({
      'plans': [
        {'plan': 'monthly', 'price': 1000, 'period': 'month'},
        {'plan': 'yearly', 'price': 8000, 'period': 'year'},
      ],
      'plan': '',
      'wallet_balance': 184500,
    });
    expect(s.plans.length, 2);
    expect(s.plans.last.price, 8000);
    expect(s.verified, isFalse);
  });

  test('cash-out request', () {
    final c = Cashout.fromJson({'guid': '9', 'amount': '50000', 'fee_amount': '500', 'net_amount': '49500', 'status': 'pending', 'bank_name': 'GTBank', 'account_number': '0123454821', 'time': '1750000000'});
    expect(c.net, 49500);
    expect(c.status, 'pending');
  });
}
