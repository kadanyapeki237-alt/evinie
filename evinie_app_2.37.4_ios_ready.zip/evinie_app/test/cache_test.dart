import 'package:flutter_test/flutter_test.dart';
import 'package:evinie_app/api/api_client.dart';

void main() {
  test('saved-copy keys do not depend on field order', () {
    expect(ApiClient.cacheKey('wall_list_home', {'guid': 5, 'offset': 1, 'count': 10}),
        ApiClient.cacheKey('wall_list_home', {'count': 10, 'offset': 1, 'guid': 5}));
  });

  test('empty fields are ignored in the key', () {
    expect(ApiClient.cacheKey('egifts/list', {'x': null}), ApiClient.cacheKey('egifts/list', {}));
  });

  test('health, sign-in and actions are never saved', () {
    for (final m in ['ihealth/ask', 'ihealth/chat', 'ihealth/consultation', 'auth/login', 'wall_add', 'walletadd/init', 'marketescrow/buy', 'egifts/send', 'paidverify/pay']) {
      expect(kSavedReads.contains(m), isFalse, reason: m);
    }
    expect(kSavedReads.any((m) => m.startsWith('ihealth')), isFalse);
  });

  test('common reads are saved', () {
    for (final m in ['wall_list_home', 'message_list', 'wallet/history', 'marketplace/list', 'businesshub/summary']) {
      expect(kSavedReads.contains(m), isTrue, reason: m);
    }
  });
}
