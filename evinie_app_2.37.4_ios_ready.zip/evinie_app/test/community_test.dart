import 'package:flutter_test/flutter_test.dart';
import 'package:evinie_app/models/community.dart';

void main() {
  test('poll options as a list of maps', () {
    final p = Poll.fromJson({'guid': 5, 'title': 'Best tool?', 'options': [{'title': 'Figma', 'votes': 3}, {'title': 'Sketch', 'votes': 1}], 'is_ended': 0});
    expect(p.options.length, 2);
    expect(p.options.first.key, '0');
    expect(p.totalVotes, 4);
    expect(p.ended, isFalse);
  });

  test('poll options as a map of text', () {
    final p = Poll.fromJson({'guid': 6, 'title': 'Jollof?', 'options': {'a': 'Party', 'b': 'Home'}});
    expect(p.options.map((o) => o.key), ['a', 'b']);
    expect(p.options.last.title, 'Home');
  });

  test('event date badge from either date format', () {
    expect(EventItem.fromJson({'date': '07/12/2026'}).badge, ('12', 'Jul'));
    expect(EventItem.fromJson({'date': '2026-06-28'}).badge, ('28', 'Jun'));
    expect(EventItem.fromJson({'date': ''}).badge, ('', ''));
  });

  test('raw product record with fields under data', () {
    final p = Product.fromJson({'guid': '77', 'owner_guid': '3', 'title': 'Wireless Headphones', 'data': {'price': '18500', 'currency': 'NGN', 'location': 'Lagos'}, 'category_title': 'Electronics', 'cover': 'https://x/c.jpg'});
    expect(p.price, 18500);
    expect(p.priceText, '₦18,500');
    expect(p.location, 'Lagos');
    expect(p.category, 'Electronics');
  });
}
