#!/usr/bin/env bash
# Evinie app: iOS setup (Mac or Codemagic). Run inside the evinie_app folder:
#   bash ios_setup.sh                      # bundle ID com.evinie.app
#   bash ios_setup.sh com.yourcompany.app  # or your own bundle ID
# Safe to run more than once. Creates the ios folder, sets the app name,
# bundle ID, icon, permissions and minimum iOS version, then installs pods.
set -euo pipefail

BUNDLE_ID="${1:-${BUNDLE_ID:-com.evinie.app}}"
PLIST="ios/Runner/Info.plist"

if ! command -v flutter >/dev/null; then
  echo "Flutter is not installed or not on PATH." >&2; exit 1
fi

echo "1/6 Creating the iOS project files..."
if [ ! -d ios/Runner ]; then
  flutter create --platforms=ios --org com.evinie --project-name evinie_app .
fi

echo "2/6 Bundle ID: $BUNDLE_ID"
PBX="ios/Runner.xcodeproj/project.pbxproj"
# Main app target, then the test target (keeps it unique).
perl -pi -e 's/PRODUCT_BUNDLE_IDENTIFIER = [^;]*\.RunnerTests;/PRODUCT_BUNDLE_IDENTIFIER = '"$BUNDLE_ID"'.RunnerTests;/g; s/PRODUCT_BUNDLE_IDENTIFIER = (?![^;]*RunnerTests)[^;]*;/PRODUCT_BUNDLE_IDENTIFIER = '"$BUNDLE_ID"';/g' "$PBX"
perl -pi -e 's/IPHONEOS_DEPLOYMENT_TARGET = [0-9.]+;/IPHONEOS_DEPLOYMENT_TARGET = 13.0;/g' "$PBX"

echo "3/6 App name and permissions..."
plutil -replace CFBundleDisplayName -string "Evinie" "$PLIST"
plutil -replace NSCameraUsageDescription -string "Evinie uses the camera so you can take photos and record videos for posts, stories and video consultations." "$PLIST"
plutil -replace NSMicrophoneUsageDescription -string "Evinie uses the microphone to record videos and voice notes, and for video consultations." "$PLIST"
plutil -replace NSPhotoLibraryUsageDescription -string "Evinie uses your photos so you can add them to posts, stories and products." "$PLIST"
plutil -replace NSPhotoLibraryAddUsageDescription -string "Evinie can save photos and videos to your library." "$PLIST"
plutil -replace ITSAppUsesNonExemptEncryption -bool NO "$PLIST"
plutil -replace LSApplicationQueriesSchemes -json '["whatsapp","https","tel","mailto"]' "$PLIST"
# The app never reads contacts; an unused permission text can get it rejected.
plutil -remove NSContactsUsageDescription "$PLIST" 2>/dev/null || true

echo "4/6 App icon..."
ICON_DIR="ios/Runner/Assets.xcassets/AppIcon.appiconset"
rm -rf "$ICON_DIR"
cp -R platform_setup/ios/AppIcon.appiconset "$ICON_DIR"

echo "5/6 Minimum iOS version 13.0..."
if [ -f ios/Podfile ]; then
  perl -pi -e "s/^#?\s*platform :ios, '[0-9.]+'/platform :ios, '13.0'/" ios/Podfile
fi

echo "6/6 Libraries..."
flutter pub get
if command -v pod >/dev/null; then (cd ios && pod install --repo-update); fi

echo "Done. Open ios/Runner.xcworkspace in Xcode, choose your Team under Signing & Capabilities,"
echo "then build: flutter build ipa --release --dart-define=EVINIE_URL=https://evinie.com --dart-define=EVINIE_API_KEY=YOUR_KEY --dart-define=EVINIE_STORE_SAFE=true"
