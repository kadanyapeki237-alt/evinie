# Evinie app: one-time setup (Windows PowerShell). Run inside the evinie_app folder:
#   powershell -ExecutionPolicy Bypass -File .\setup.ps1
# Optional: use your existing Play Store app ID organisation, e.g.  -Org com.yourcompany
param([string]$Org = "com.evinie")
$ErrorActionPreference = "Stop"
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Host "Flutter is not on PATH. Install Flutter and add its bin folder to PATH first (see README)." -ForegroundColor Red
  exit 1
}
Write-Host "1/4 Creating the Android and iOS project files..."
flutter create --platforms=android,ios --org $Org --project-name evinie_app .

Write-Host "2/4 Adding permissions (internet, camera, microphone, photos, notifications)..."
Copy-Item "platform_setup\android\AndroidManifest.xml" "android\app\src\main\AndroidManifest.xml" -Force

Write-Host "    Adding the Evinie app icon..."
Get-ChildItem "platform_setup\android\res" -Directory | ForEach-Object {
  $to = Join-Path "android\app\src\main\res" $_.Name
  New-Item -ItemType Directory -Path $to -Force | Out-Null
  Copy-Item (Join-Path $_.FullName "*") $to -Force
}

Write-Host "3/4 Setting minimum Android version to 23..."
foreach ($f in @("android\app\build.gradle.kts", "android\app\build.gradle")) {
  if (Test-Path $f) {
    $t = Get-Content $f -Raw
    $t = $t -replace 'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 23'
    $t = $t -replace 'minSdkVersion\s+flutter\.minSdkVersion', 'minSdkVersion 23'
    Set-Content $f $t -NoNewline
  }
}
$plist = "ios\Runner\Info.plist"
if ((Test-Path $plist) -and -not ((Get-Content $plist -Raw) -match "NSCameraUsageDescription")) {
  $keys = Get-Content "platform_setup\ios\Info.plist.keys.xml" -Raw
  $p = Get-Content $plist -Raw
  $i = $p.LastIndexOf("</dict>")
  Set-Content $plist ($p.Substring(0, $i) + $keys + $p.Substring($i)) -NoNewline
}

Write-Host "4/4 Downloading libraries..."
flutter pub get
Write-Host "Done. Next: put your evinie.com API key in lib\config.dart, then Run in Android Studio." -ForegroundColor Green
