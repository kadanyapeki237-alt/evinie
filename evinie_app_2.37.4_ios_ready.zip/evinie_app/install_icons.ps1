# Replaced by update_android.ps1 (icons, notifications and app settings).
powershell -ExecutionPolicy Bypass -File "$PSScriptRoot\update_android.ps1"
