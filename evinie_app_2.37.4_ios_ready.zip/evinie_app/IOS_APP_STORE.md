# Evinie on the Apple App Store (version 2.37.4)

The `lib/` code already runs on iOS. An `.ipa` can only be built and signed on a
Mac with Xcode, using **your** Apple Developer account. Pick one of these two paths.

## What you need first (both paths)

1. **Apple Developer Program** membership ($99/year): developer.apple.com/programs.
   Enrol as an organisation (needs a D-U-N-S number) so the store shows "Evinie"
   as the seller rather than your personal name.
2. **Bundle ID:** this project uses `com.evinie.app`. If Evinie is already on the
   App Store, use that app's existing bundle ID instead (change it in
   `codemagic.yaml`, both places, or pass it to `ios_setup.sh`).
3. In **App Store Connect** > Apps > **+ New App**: platform iOS, name Evinie,
   that bundle ID, SKU `evinie-ios`.

## Path A: no Mac (Codemagic cloud build, recommended for Windows)

1. Put this folder in a private GitHub/GitLab/Bitbucket repository.
2. Sign up at codemagic.io and add the repository.
3. App Store Connect > Users and Access > Integrations > **App Store Connect API**:
   create a key with **App Manager** access, download the `.p8` file.
4. In Codemagic, Team settings:
   - Integrations > Developer Portal: add the key, name it **Evinie ASC**.
   - Code signing identities: generate an iOS Distribution certificate and
     fetch an App Store profile for the bundle ID.
   - Environment variables: group **evinie**, variable `EVINIE_API_KEY`
     (your evinie.com key, marked Secret).
5. In `codemagic.yaml`, set `APP_STORE_APPLE_ID` (the number under App Store
   Connect > your app > App Information).
6. Start the **Evinie iOS (App Store)** workflow. It sets up iOS, runs the tests,
   builds and signs the `.ipa`, and uploads it to **TestFlight**. The `.ipa` is
   also downloadable from the build page.

## Path B: with a Mac

1. Install Xcode (App Store), Flutter 3.27+, and CocoaPods (`brew install cocoapods`).
2. In Terminal, inside `evinie_app`: `bash ios_setup.sh` (or `bash ios_setup.sh your.bundle.id`).
3. `open ios/Runner.xcworkspace` > Runner target > Signing & Capabilities >
   choose your **Team**, keep "Automatically manage signing" on.
4. Build:
   ```bash
   flutter build ipa --release \
     --dart-define=EVINIE_URL=https://evinie.com \
     --dart-define=EVINIE_API_KEY=YOUR_KEY \
     --dart-define=EVINIE_STORE_SAFE=true
   ```
5. Upload `build/ios/ipa/*.ipa` with Apple's **Transporter** app, or open
   `build/ios/archive/Runner.xcarchive` in Xcode > Distribute App.

## Before you press "Submit for Review"

- **Store-safe build is on** (`EVINIE_STORE_SAFE=true`). Apple requires its own
  in-app purchase for digital items (verification, memberships, eGifts, wallet
  top-ups used for them). Without this flag the app is very likely rejected
  under guideline 3.1.1. Marketplace goods and doctor consultations are real-world
  and may use Flutterwave.
- **Test account for the reviewer:** in App Review Information give a working
  username and password with some content in the feed.
- **Privacy:** a Privacy Policy URL (e.g. evinie.com/privacy) and the App Privacy
  questionnaire (account info, photos/videos, messages, health data from
  iHealth Assist, payment info). Account deletion is already in Settings >
  Security & login, which Apple requires.
- **User content (guideline 1.2):** Apple asks social apps for report and block
  tools and a way to act on reports. Blocking exists; make sure posts and users
  can be reported and that your terms forbid abusive content.
- **iHealth Assist:** the reviewer may ask that doctors are verified and that the
  AI is not presented as a diagnosis. Keep the emergency notice visible.
- **Screenshots:** 6.9" iPhone (1320 x 2868) required; take them from the iOS
  Simulator or a TestFlight install. Add 13" iPad shots only if you enable iPad.
- **Icon:** `platform_setup/ios/AppIcon.appiconset/AppIcon-1024.png` was enlarged
  from the 512 px Play icon. If you have the original logo file, export a sharp
  1024 x 1024 PNG with no transparency and replace it.
- **Export compliance:** set to "no non-exempt encryption" already
  (`ITSAppUsesNonExemptEncryption = NO`; the app uses only HTTPS and standard
  on-device encryption).

## What changed for iOS in this package

- `ios_setup.sh`: one-step iOS setup (bundle ID, name "Evinie", icon,
  permissions, iOS 13 minimum, pods).
- `codemagic.yaml`: cloud Mac build, signing and TestFlight upload.
- `platform_setup/ios/`: App Store icon and the permission texts. The contacts
  permission was removed (the app never reads contacts; Apple rejects
  unused permission requests), and the microphone text now mentions voice notes.
