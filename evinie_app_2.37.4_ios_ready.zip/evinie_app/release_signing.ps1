# Evinie app: set up Google Play release signing (run ONCE, in the evinie_app folder):
#   powershell -ExecutionPolicy Bypass -File .\release_signing.ps1
#
# Google Play refuses apps signed with Flutter's debug key, which is what
# release builds use until this is set up. This script:
#   1. creates your upload key (or uses one you already have),
#   2. writes android\key.properties with its passwords,
#   3. makes release builds in android\app\build.gradle.kts use that key.
#
# KEEP THE KEY FILE AND PASSWORDS SAFE AND BACKED UP. Every future update
# of the app on Google Play must be signed with this same key.
#
# Already have an Evinie key from a previous developer? Run:
#   powershell -ExecutionPolicy Bypass -File .\release_signing.ps1 -KeyFile "C:\path\to\their-key.jks" -Alias their_alias
param(
  [string]$KeyFile = "$env:USERPROFILE\evinie-upload-key.jks",
  [string]$Alias = "upload"
)
$ErrorActionPreference = "Stop"

$gradle = "android\app\build.gradle.kts"
if (-not (Test-Path $gradle)) {
  Write-Host "Can't find $gradle. Run this inside the evinie_app folder, after setup.ps1." -ForegroundColor Red
  exit 1
}

# keytool comes with Android Studio's Java.
$keytool = (Get-Command keytool -ErrorAction SilentlyContinue).Source
if (-not $keytool) {
  foreach ($p in @("C:\Program Files\Android\Android Studio\jbr\bin\keytool.exe", "C:\Program Files\Android\Android Studio\jre\bin\keytool.exe")) {
    if (Test-Path $p) { $keytool = $p; break }
  }
}

$secure = Read-Host "Choose (or enter) the key password - at least 6 characters" -AsSecureString
$password = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
if ($password.Length -lt 6) {
  Write-Host "The password must be at least 6 characters." -ForegroundColor Red
  exit 1
}

if (Test-Path $KeyFile) {
  Write-Host "1/3 Using the existing key: $KeyFile"
} else {
  if (-not $keytool) {
    Write-Host "keytool was not found. Install Android Studio, or add its jbr\bin folder to PATH." -ForegroundColor Red
    exit 1
  }
  Write-Host "1/3 Creating your upload key: $KeyFile"
  & $keytool -genkeypair -v -keystore $KeyFile -storetype JKS -keyalg RSA -keysize 2048 -validity 10000 -alias $Alias -storepass $password -keypass $password -dname "CN=Evinie, O=Evinie, C=NG"
  if ($LASTEXITCODE -ne 0) { Write-Host "Creating the key failed." -ForegroundColor Red; exit 1 }
}

Write-Host "2/3 Writing android\key.properties"
$storeFile = $KeyFile.Replace('\', '/')
Set-Content "android\key.properties" "storePassword=$password`nkeyPassword=$password`nkeyAlias=$Alias`nstoreFile=$storeFile" -NoNewline

Write-Host "3/3 Making release builds use your key"
$t = Get-Content $gradle -Raw
if ($t -match 'keystoreProperties') {
  Write-Host "    (already set up)"
} else {
  $header = "import java.util.Properties`nimport java.io.FileInputStream`n`n"
  $load = "val keystoreProperties = Properties()`nval keystorePropertiesFile = rootProject.file(`"key.properties`")`nif (keystorePropertiesFile.exists()) {`n    keystoreProperties.load(FileInputStream(keystorePropertiesFile))`n}`n`nandroid {"
  $signing = "    signingConfigs {`n        create(`"release`") {`n            keyAlias = keystoreProperties[`"keyAlias`"] as String?`n            keyPassword = keystoreProperties[`"keyPassword`"] as String?`n            storeFile = keystoreProperties[`"storeFile`"]?.let { file(it) }`n            storePassword = keystoreProperties[`"storePassword`"] as String?`n        }`n    }`n`n    buildTypes {"
  $t = $header + $t
  $t = [regex]::Replace($t, '(?m)^android\s*\{', $load, 1)
  $t = [regex]::Replace($t, '(?m)^\s*buildTypes\s*\{', $signing, 1)
  $t = $t.Replace('signingConfig = signingConfigs.getByName("debug")', 'signingConfig = signingConfigs.getByName("release")')
  if ($t -notmatch 'getByName\("release"\)') {
    Write-Host "Could not find the release signing line in $gradle. Send this file to your developer." -ForegroundColor Red
    exit 1
  }
  Set-Content $gradle $t -NoNewline
}

# Never upload the passwords anywhere.
if (Test-Path ".gitignore") {
  if (-not ((Get-Content ".gitignore" -Raw) -match 'key\.properties')) { Add-Content ".gitignore" "`nandroid/key.properties`n*.jks" }
}

Write-Host ""
Write-Host "Done. Back up these two things somewhere safe (not only on this computer):" -ForegroundColor Green
Write-Host "  - the key file: $KeyFile"
Write-Host "  - its password"
Write-Host "Then build for Google Play with flutter build appbundle (see README)." -ForegroundColor Green
